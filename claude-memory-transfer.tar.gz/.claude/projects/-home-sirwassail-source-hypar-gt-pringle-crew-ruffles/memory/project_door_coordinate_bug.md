---
name: Door/window offset coordinate mismatch — root cause and fix
description: Root cause confirmed and fixed — edgeFollowsWinding compared centerline against boundary vertices (always failed), causing reversed=true always in get1DLayoutContext
type: project
---

## Root Cause (confirmed 2026-03-31)

`get1DLayoutContext` computed `reversed` using `edgeFollowsWinding(polyVerts2D, clStart2D, clEnd2D)` which compared wall **centerline** endpoints against polygon **boundary** vertices using EPSILON=0.00001 (0.01mm). The centerline is offset from the boundary by ~67mm (half wall thickness), so the match **always failed**, making `reversed=true` for ALL walls.

Meanwhile `#resolveWallByEdge` used a distance comparison that correctly determined direction. The disagreement meant ~50% of walls had flipped adjacency data.

## Fix Applied

Extracted `wallFollowsEdgeDirection()` into `wallSchema.ts` — a shared helper using distance comparison (robust to centerline offset). Both `get1DLayoutContext` and `#resolveWallByEdge` now use it.

**Why:** Single source of truth for wall↔edge direction. Foundation for future tools.

Branch: fix-door-window-wall-collision, PR #4582
