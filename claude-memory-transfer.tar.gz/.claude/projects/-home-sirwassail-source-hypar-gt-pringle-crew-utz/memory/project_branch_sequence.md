---
name: batch-tools-branch-sequence
description: feat/ai-batch-tools-and-eval-setup follows after PR #4477 (feat/ai-eval-initial-elements) merges
type: project
---

Branch dependency chain:
1. PR #4477 `feat/ai-eval-initial-elements` — adds initialElements support to eval panel + doors eval scaffold. Lays flagged it needs rebase to avoid reverting #4468 unit conversion prompting.
2. `feat/ai-batch-tools-and-eval-setup` — adds batch createDoors, createWindows, moveElementsByVector to DesignApi + tool definitions. Builds on top of #4477.

Lays (pringle/crew/lays) is reviewing/approving #4477. Once it merges, batch tools branch should rebase onto main and continue.
