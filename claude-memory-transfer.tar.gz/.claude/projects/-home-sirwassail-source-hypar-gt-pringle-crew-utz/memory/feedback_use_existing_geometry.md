---
name: Use existing geometry constructs for graph representations
description: Coworker feedback to use EdgeGeometry/PointGeometry/MeshGeometry instead of custom graph types in pringle
type: feedback
---

When building graph-like structures (e.g. space adjacency graphs), use the existing EdgeGeometry, PointGeometry, and MeshGeometry constructs rather than creating new custom graph representations.

**Why:** Coworker recommendation — the codebase already has established geometry primitives that handle rendering, serialization, and integration with the rest of the system. Custom graph types duplicate effort and don't integrate as smoothly.

**How to apply:** Before designing new data structures for spatial/topological representations, check if EdgeGeometry, PointGeometry, or MeshGeometry can represent the same information. Refactor SpaceAdjacencyGraph to use these existing constructs.
