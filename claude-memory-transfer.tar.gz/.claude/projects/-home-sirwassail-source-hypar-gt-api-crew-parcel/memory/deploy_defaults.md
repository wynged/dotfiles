---
name: deploy-defaults
description: Default SAM deploy stack name is eric-api-prod, always use this without asking
type: feedback
---

Always use stack name `eric-api-prod` for SAM deployments — don't ask.

**Why:** User explicitly said to always assume this stack name.
**How to apply:** When running /build-n-deploy, default to `eric-api-prod` without prompting.
