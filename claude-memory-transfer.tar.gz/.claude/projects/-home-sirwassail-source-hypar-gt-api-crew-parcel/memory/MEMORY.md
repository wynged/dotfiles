# Parcel Crew Memory

## Git Workflow
- **NEVER push directly to master** — always create a feature branch and push there
- Override the Gas Town default of pushing to main; the overseer prefers PRs

## Deploy
- [deploy_defaults.md](deploy_defaults.md) — Always use stack name `eric-api-prod`
