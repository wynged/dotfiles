---
name: no-crew-in-repo-artifacts
description: "Avoid naming \"crew\" / \"gascity\" / agent-orchestration tooling in repo-committed content"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 12d8cd29-5030-400c-ae2a-e25e53997bb7
---

# No crew / gascity references in repo-committed content

When committing files into a shared repo (e.g. `.gitignore` comments, README
content, CI config), do NOT reference "crew", "gascity", or other
agent-orchestration concepts by name.

**Reason:** this repo is shared with people who don't use gascity/crew —
those terms leak Eric's local tooling vocabulary into the project history.

**Preferred phrasing:** neutral terms like "Local agent / tooling artifacts".

**Patterns are fine, names are not:** ignoring `.gc/` or `CLAUDE.md` is
perfectly OK; just don't NAME the system in the comment.

## How to apply

Any time you author repo-committed content that references the local
agent-orchestration setup, find a neutral phrasing. Examples:

- `.gitignore`: `# Local agent / tooling artifacts` — not `# crew worktrees`
- README sections: describe the file's purpose, not the orchestration system
- CI configs: refer to ignored paths neutrally
