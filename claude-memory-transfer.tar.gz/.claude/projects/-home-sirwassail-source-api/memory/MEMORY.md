# Memory Index

- [No crew/gascity in repo content](feedback_no_crew_in_repo_artifacts.md) — comments/docs in shared repos must use neutral phrasing
