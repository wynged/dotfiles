---
name: wscity-personal-gas-city
description: "What wsCity is — Eric's personal Gas City running the Gas Town pack"
metadata: 
  node_type: memory
  type: project
  originSessionId: f45f38cd-0bf5-41f4-a292-a1a039190030
---

`wsCity` (`/home/sirwassail/source/wsCity`) is Eric's **personal** Gas City,
created 2026-05-25 via `gc init --from ../gascity/examples/gastown` (provider
`claude`). It runs basically **just the Gas Town pack** (gastown + its
maintenance dependency, vendored under `packs/`). It has its own rules and is
expected to diverge from [[city-hy-work-reference]].

The tool is `gc` (Gas City CLI, on PATH, v1.1.1); source in `../gascity`. The
city is registered with the machine-wide supervisor and runs under systemd
alongside city_hy. A living `wsCity/CLAUDE.md` documents layout, agents, commands,
and operational gotchas — keep it updated.

First (and so far only) rig: `workout-coach` (`../workout-coach`, cloned from
`github.com/wynged/workout-coach`, currently an empty repo), prefix `woc`
(default `wc` collides with HQ), default branch `main`, imports gastown.
