---
name: city-hy-work-reference
description: "city_hy is Eric's work Gas City, used as a config reference for wsCity"
metadata: 
  node_type: memory
  type: reference
  originSessionId: f45f38cd-0bf5-41f4-a292-a1a039190030
---

`city_hy` (`/home/sirwassail/source/city_hy`) is Eric's heavily-developed **work**
Gas City — the one he uses a lot for work. For [[wscity-personal-gas-city]],
treat city_hy as a *reference* for configuration questions, not a template to
copy (wsCity has different rules).

Well-developed knowledgebase lives there:
- `city_hy/_gascity_howto/` — concepts, configuration, packs, formulas/molecules,
  gastown→gascity map, full `gc-config-reference.md`.
- `city_hy/_my_city/` — workflow analysis, crew operating procedure, patterns.
