---
name: Orphan sweep implementation
description: city_hy has an enhanced session-aware orphan-sweep exec order that resets beads assigned to dead agents
type: project
originSessionId: 510e6376-ab00-47bb-b76b-7430dfa57348
---
city_hy now has a session-aware orphan-sweep at `city_hy/scripts/orphan-sweep.sh` + `city_hy/formulas/orders/orphan-sweep/order.toml` (5m cooldown).

**Why:** Beads were getting orphaned when agents died and the controller didn't restart them. The gastown example's orphan-sweep only checked config (missed agents still in config but not running). The enhanced version checks `gc session list --json` for live sessions.

**How to apply:** This is the first city-level exec order. If more orders are needed, follow the same pattern: script in `scripts/`, order.toml in `formulas/orders/<name>/`. Use `$GC_CITY_PATH` (not `$PACK_DIR`) for city-level orders.
