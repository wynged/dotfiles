---
name: Cross-rig pool pattern (ants)
description: city_hy uses per-rig ant pools that share cross-rig routed work; the SDK default scale_check/work_query is single-rig only, so custom scripts are required.
type: project
originSessionId: b1661980-39f2-4cc5-90d3-7bc5b79a8c32
---
city_hy includes `packs/investigation` on every rig (9 rigs as of 2026-04-16), giving each rig its own `<rig>/ant` pool. Formulas like `sw-investigate` cook into one rig's bead store but route step beads across rigs via `gc.routed_to=<target-rig>/ant`.

**Why:** `molecule.Cook` takes a single `beads.Store`, so all step beads of a poured molecule live in the source rig's `.beads/` regardless of their routing metadata. Gascity's default `EffectiveScaleCheck` (config.go:1662) runs under `BEADS_DIR=<this-rig>` via `prefixControllerQueryEnv` — it physically cannot see beads in other rigs' stores. Same limitation applies to the agent's default work-query at startup.

**How to apply:**
- Do NOT advise dropping ant's custom `scale_check` in favor of the default — the default is single-rig and blind to cross-rig routed work (bug-sherrif cricket pouring `sw-investigate` routes a deep-dive bead to pringle/ant; bead lives in bug-sherrif/.beads; pringle's pool never sees it).
- `scripts/cross-rig-scale-check.sh` and `scripts/cross-rig-find-work.sh` must walk every rig's `.beads/` dir — keep in sync with `city.toml` rigs list.
- The scale_check query shape should mirror the default's (ready+unassigned + in_progress+no-assignee + molecules+no-assignee), not just ready+unassigned — catches stale-assignee drain leftovers (gascity #482) and formula-dispatched molecule beads (#681).
- ant-worker prompt calls `cross-rig-find-work.sh` then `export BEADS_DIR=<foreign-dir>` so all subsequent `bd` commands hit the right store — don't break this convention.
- Pool labels (`pool:<name>`) are a legacy fallback in gascity (cmd_sling.go:1501); the modern path is `gc.routed_to` metadata. Don't recommend pool-label plumbing.
