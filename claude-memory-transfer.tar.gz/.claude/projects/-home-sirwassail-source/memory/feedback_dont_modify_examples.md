---
name: Don't modify gastown examples
description: Create new files in city_hy rather than modifying gascity/examples/gastown files
type: feedback
originSessionId: 510e6376-ab00-47bb-b76b-7430dfa57348
---
Don't modify files in `gascity/examples/gastown/` — create new versions in `city_hy/` instead.

**Why:** The gastown examples are upstream reference material. The user's city_hy is the active instance with its own scripts, formulas, and orders. Packs in `city_hy/packs/` are copies that aren't actively wired via `includes`.

**How to apply:** When building new infrastructure (scripts, orders, formulas), place them at the city level in `city_hy/scripts/`, `city_hy/formulas/`, etc. Use the gastown examples as reference templates but don't edit them.
