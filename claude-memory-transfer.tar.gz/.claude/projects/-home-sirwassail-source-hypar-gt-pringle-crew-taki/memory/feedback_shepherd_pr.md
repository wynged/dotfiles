---
name: Shepherd PRs through merge
description: Crew should stay on branch and shepherd open PRs through merge instead of resetting to main
type: feedback
---

Don't reset to main while a PR is still open and unmerged. Stay on the branch and shepherd the PR through review and merge.

**Why:** The user expects crew workers to be responsible for the full lifecycle of their work, not just code + PR creation. Abandoning an open PR leaves it unattended.

**How to apply:** After PR creation, remain on the branch. Monitor CI, respond to review feedback, and only reset after the PR is merged.
