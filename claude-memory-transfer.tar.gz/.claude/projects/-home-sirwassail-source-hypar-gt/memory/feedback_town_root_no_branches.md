---
name: Town root commits go directly to main
description: Mayor pushes directly to main in the town root repo (wynged/hypar_gt) — no feature branches needed
type: feedback
---

In the town root repo (wynged/hypar_gt), the Mayor commits and pushes directly to main. No feature branches or PRs needed.

Feature branches and PRs are only required when working in rig repos (e.g., gastown, pringle, etc.).

**Why:** The town root is the Mayor's own workspace — branching adds unnecessary ceremony. Rigs have crew members and polecats whose work needs review via PRs.

**How to apply:** When committing to `/home/sirwassail/source/hypar_gt` (town root), commit to main and `git push origin main`. When working in `<rig>/mayor/rig/`, use feature branches and `/pr`.
