---
name: Town root is HQ — source of truth for town-level scripts
description: The town root (/home/sirwassail/source/hypar_gt) is a versioned git repo (wynged/hypar_gt). Town-level scripts/ are the source of truth, NOT gastown rig copies. "Town" = HQ = town root, not the gastown rig.
type: feedback
---

When the user says "town" they mean the town root / HQ (`/home/sirwassail/source/hypar_gt`), NOT the gastown rig.

The town root is a **versioned git repo** (`wynged/hypar_gt`). Town-level directories like `scripts/` are tracked and versioned there.

**Why:** The gastown rig (`gastown/mayor/rig/`) is a clone of the gastown repo — it's for the `gt` CLI and Gas Town infrastructure code. But town-level operational scripts (like `scripts/town-hall`) belong in the HQ repo, not gastown. Having copies in both places causes drift.

**How to apply:**
- Edit town-level scripts directly at `scripts/` (town root), not in `gastown/mayor/rig/scripts/`
- Commit town-level script changes to the HQ repo (`wynged/hypar_gt`), not gastown
- If a script exists in both places, the town-level copy is authoritative
- When the user says "town scripts" they mean `$TOWN_ROOT/scripts/`, not gastown
