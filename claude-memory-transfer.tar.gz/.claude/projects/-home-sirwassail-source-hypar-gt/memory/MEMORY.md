# Memory Index

- [feedback_town_vs_gastown.md](feedback_town_vs_gastown.md) — Town root is HQ and the versioned source of truth for scripts; "town" ≠ gastown rig
- [feedback_town_root_no_branches.md](feedback_town_root_no_branches.md) — Mayor pushes directly to main in town root; feature branches only for rigs
