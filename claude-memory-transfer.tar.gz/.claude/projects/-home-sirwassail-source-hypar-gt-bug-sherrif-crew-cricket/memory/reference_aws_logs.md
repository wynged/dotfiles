---
name: AWS log investigation reference
description: How to investigate Hypar Lambda alarms — profiles, log groups, X-Ray, alarm patterns
type: reference
---

## AWS Access

- **Profile**: `gt-logs` — uses `bug_sherrif_policy_set` permission set (custom, overseer-managed)
- **Account**: 501396736796
- **SSO**: hypar.awsapps.com, user eric@hypar.io, permission set: bug_sherrif_policy_set
- **Note**: Permission set is actively maintained by overseer — capabilities may expand over time

## Prod Lambda Stack (us-west-2)

- Stack prefix: `prod-Realtime-1HLSHIMI8UIYR`
- Log groups follow pattern: `/aws/lambda/prod-Realtime-1HLSHIMI8UIYR-<FunctionName>-<hash>`
- GetFile function: `prod-Realtime-1HLSHIMI8UIYR-GetFileFunction-FT86vunCZczq`

## Alarm Pattern

- Alarms named like `GetFileFailure-prod-Realtime-1HLSHIMI8UIYR`
- Monitor `AWS/Lambda Errors` metric (actual invocation failures — unhandled exceptions, timeouts, OOM — NOT console.log ERROR statements)
- Typical config: Sum >= 1 in 300s period — very sensitive, triggers on a single failure
- SNS topic: `arn:aws:sns:us-west-2:501396736796:HyparStackAlarms`

## Key Code Paths (from log analysis)

- `conversionUtilities.ts:7` — S3 HeadObject checks for file variants (thumbnails)
- `glb.ts:10` — S3 HeadObject checks for optimized GLB files
- These do HeadObject probes that 404 — but if uncaught, they become Lambda Errors

## Investigation Approach

1. Lambda `Errors` metric = uncaught exceptions/timeouts, not log-level errors
2. Use X-Ray traces with `fault = true` filter to see actual crash details
3. CloudWatch Insights query for `Task timed out`, `Runtime.UnhandledPromiseRejection`, `Runtime.ExitError`
4. gt-logs profile can run Insights queries but user must run X-Ray/alarm commands directly
