---
name: Dispatch limit per handoff
description: User wants to cap investigation dispatches at 10 per handoff cycle
type: feedback
---

Stop after just 10 investigation dispatches.

**Why:** User explicitly requested this limit and asked to remember it.

**How to apply:** When dispatching investigations to bugle, cap at 10 per handoff cycle. Don't try to do more than 10 in a single session chain.
