---
name: Skills should be capability-aware, not rigid processes
description: When writing skills/commands, give capabilities and tools but don't overspecify the process
type: feedback
---

Don't write skills as rigid step-by-step procedures tied to one specific scenario. Instead, give the agent awareness of what tools/sources are available and let it use judgment about which to use and in what order.

**Why:** Investigations and debugging come in many forms — sometimes PostHog first, sometimes CloudWatch first, sometimes from a code change or user report. A rigid "Step 1: fetch PostHog, Step 2: query CloudWatch" process breaks when the investigation starts from a different entry point.

**How to apply:** When writing .claude/commands/ skills, structure them as: (1) what capabilities/tools are available, (2) what the output should look like, (3) guiding principles. Let the agent figure out the process.
