---
name: Lambda Errors metric vs log ERROR
description: Don't confuse AWS/Lambda Errors metric (invocation failures) with ERROR-level log lines
type: feedback
---

AWS/Lambda `Errors` metric counts actual invocation failures (unhandled exceptions, timeouts, OOM) — NOT console.log ERROR statements. When investigating Lambda alarms, look at the alarm config first to understand what metric is being monitored before pulling logs.

**Why:** Misinterpreted GetFile alarm by searching for ERROR log lines instead of actual Lambda crash signatures. The logged S3 404 ERRORs were red herrings — they were handled errors logged for observability, not the invocation failure that triggered the alarm.

**How to apply:** When investigating Lambda alarms: (1) check alarm config for metric/threshold, (2) use X-Ray traces for fault analysis, (3) use Insights queries for crash signatures (Task timed out, Runtime.UnhandledPromiseRejection, etc.), (4) don't assume logged ERROR = Lambda failure.
