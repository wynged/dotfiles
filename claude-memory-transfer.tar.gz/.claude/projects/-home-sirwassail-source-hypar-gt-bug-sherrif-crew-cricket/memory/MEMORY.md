# Memory Index

- [reference_aws_logs.md](reference_aws_logs.md) — AWS profiles, log groups, alarm config, and investigation approach for Hypar Lambda stack
- [feedback_lambda_errors_vs_logs.md](feedback_lambda_errors_vs_logs.md) — Don't confuse AWS/Lambda Errors metric with ERROR log lines; check alarm config first
- [reference_highlight_errors.md](reference_highlight_errors.md) — PostHog event links use us.posthog.com/project/51345/events/{uuid}/{encoded-timestamp}
- [feedback_skill_design.md](feedback_skill_design.md) — Skills should give capabilities, not rigid step-by-step processes
- [feedback_pattern_approval.md](feedback_pattern_approval.md) — Always confirm pattern assignments with user before adding to registry
