---
name: PostHog event links
description: Hypar PostHog event links use us.posthog.com with format /project/51345/events/{uuid}/{url-encoded-timestamp}
type: reference
---

PostHog event link format: `https://us.posthog.com/project/51345/events/{uuid}/{url-encoded-timestamp}`

Example: `https://us.posthog.com/project/51345/events/019cfd5b-d1d9-7b54-9a86-5ffc90680a89/2026-03-17T19%3A53%3A00.394Z`

- Host: `us.posthog.com` (NOT `app.posthog.com`)
- Project ID: 51345
- Timestamp is URL-encoded ISO 8601 (colons → `%3A`)
