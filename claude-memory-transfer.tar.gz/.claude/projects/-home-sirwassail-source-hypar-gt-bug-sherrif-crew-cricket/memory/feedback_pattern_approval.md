---
name: Always confirm pattern assignments
description: Never bulk-create triage patterns without asking the user to review/approve each one first
type: feedback
---

Always present proposed patterns to the user for approval before adding them to the registry.

**Why:** User wants to review pattern IDs, regexes, severity, and categorization before they go in. Bulk-adding without asking is unwanted.

**How to apply:** When creating triage patterns from unmatched errors, present them in a table (id, regex, severity, category, description) and wait for approval before running `pattern add`. Do this even if there are many — batch into reviewable groups if needed.
