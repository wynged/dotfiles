---
name: Space type map fragility fix
description: LLM-provided spaceTypeMap was error-prone — now auto-derived from program items with spaceTypeId field
type: feedback
---

Space type mapping should flow through the solver pipeline automatically, not require the LLM to reconstruct it manually at each step.

**Why:** Multiple incidents where spaces were created with wrong types because the LLM had to build a spaceTypeMap from memory of get_program results. The requirementId/spaceTypeId confusion was a recurring failure mode.

**How to apply:** When adding new data that flows through solve→create, prefer stashing it alongside the solution rather than requiring the LLM to relay it. The pattern: add optional field to program items → build derived state at solve time → stash it → use as default downstream.
