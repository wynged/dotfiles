---
name: kettle-comms-preference
description: Kettle doesn't want routine updates on parallel PR work — post on PR or loop in overseer instead
type: feedback
---

Don't send kettle mail updates about Braintrust (#4513) progress. We're on separate PRs (#4512 PostHog, #4513 Braintrust).

**Why:** Kettle treats these as independent workstreams and will review when asked — routine updates are noise.

**How to apply:** For Braintrust analytics work, post updates as PR comments or escalate to the overseer. Only mail kettle if there's a direct dependency or they're explicitly looped in.
