# Memory Index

- [feedback_kettle_comms.md](feedback_kettle_comms.md) — Kettle doesn't want routine updates on parallel PR work
