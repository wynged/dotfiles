---
name: Never commit .beads/ files to project repos
description: .beads/ backup files are Gas Town infrastructure and must never appear in PRs or on project branches
type: feedback
---

Never commit or push `.beads/` files to project repositories. These are Gas Town infrastructure (issue tracking backups) and pollute PRs.

**Why:** `.beads/backup/` files from `bd backup` commands were accidentally committed to a feature branch and showed up in PR #4493, requiring a force push to clean up.

**How to apply:** Before every commit and PR, check `git diff --cached --name-only | grep '\.beads/'` returns empty. The `/pr` skill now has this check built in. If beads files are found tracked, `git rm -r --cached '**/.beads/'` to remove them.
