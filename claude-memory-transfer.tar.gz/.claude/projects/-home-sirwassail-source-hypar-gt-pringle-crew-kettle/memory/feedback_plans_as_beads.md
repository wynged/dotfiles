---
name: Plans should be filed as beads
description: When creating implementation plans, write them into beads (bd new) not just plan files
type: feedback
originSessionId: fceac457-b405-438f-aa6f-cb57750d0cc3
---
Write plans into beads so they're tracked in the work system.

**Why:** The overseer wants plans to be visible in the beads system for tracking and handoff, not just ephemeral plan files.

**How to apply:** When finishing a plan, `bd new --type=task` with the plan content as the description before exiting plan mode.
