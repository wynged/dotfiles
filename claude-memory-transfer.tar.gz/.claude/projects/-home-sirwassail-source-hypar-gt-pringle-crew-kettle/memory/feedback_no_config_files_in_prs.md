---
name: No editor/AI config files in PRs
description: Never include .cursor, .claude, or similar editor/AI config files in pull requests
type: feedback
---

Never submit .cursor, .claude, or similar editor/AI configuration files in PRs.

**Why:** These are local tooling configs that should not be in the repo. User was surprised to find .cursor files included in PR #4493.

**How to apply:** Before creating a PR, check `git diff --name-status origin/main..HEAD` for any .cursor/, .claude/, or similar config directories. Remove them with `git rm -r` before pushing. Do not modify .gitignore — just ensure they aren't committed.
