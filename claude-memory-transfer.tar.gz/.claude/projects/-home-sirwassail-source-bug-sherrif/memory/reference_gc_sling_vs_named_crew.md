---
name: reference_gc_sling_vs_named_crew
description: "gc sling resolves city.toml agent names, not runtime crew session names — dispatch named crew with mail+submit"
metadata: 
  node_type: memory
  type: reference
  originSessionId: ef9db1c3-5ef9-4a8e-b299-3f67247d40e8
---

`gc sling <rig>/<name>` resolves `<name>` against **city.toml agent
definitions** (e.g. `pringle/ant`), NOT runtime crew **session** identities
(`kettle`, `utz`, `combo`, `taki`, `frito`…). Slinging to a session name fails:
`agent "pringle/kettle" not found in city.toml; did you mean "pringle/ant"`.

To dispatch work to a NAMED crew session:
- `gc mail send <rig>/<name> -s "..." -m "<full spec>"` — durable spec
- `gc session submit <rig>/<name> "<msg>"` — wake + deliver (works awake/asleep/suspended)
- `gc session nudge <rig>/<name> "..."` — only for an already-running session

`gc session list` shows runtime session names under the TARGET column; pick a
free one (see [[feedback_crew_dispatch]]). Confirmed 2026-05-21 dispatching the
corrupted-matrix root-cause fix to pringle/kettle.
