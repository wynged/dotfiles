---
name: sw-investigate's deep-dive step is dynamically routed by the investigate ant
description: The sw-investigate formula's middle step has no static gc.routed_to — the investigate (step 1) ant chooses which rig's ant pool gets the deep-dive at runtime based on what it finds.
type: reference
originSessionId: 748fefed-7609-40c1-902f-cc6fbba6226b
---
**Where to find it:** `/home/sirwassail/source/city_hy/formulas/sw-investigate.formula.toml` — the `deep-dive` step has no `gc.routed_to` in its metadata, while `investigate` and `report` are both hardcoded to `bug-sherrif/ant`.

**Why it matters:**
- When extracting batch orchestration helpers (like `scripts/sw-investigate-batch/pour.sh`), **don't add a `--pool` flag** or try to parameterize the routing. `bug-sherrif/ant` is the invariant for the bracketing steps; the middle step intentionally has no baked-in target so the investigate ant can pick `pringle/ant`, `api/ant`, `realtime-stack/ant`, etc. based on what the evidence surfaces.
- When auditing why a deep-dive bead shows up on pringle instead of bug-sherrif, it's not a bug — it's the investigate ant's decision, set via `bd update <deep-dive-id> --set-metadata gc.routed_to=...` during the investigate step.
- The "cross-rig-deps" maintenance order (runs every 5m) is what unblocks the report bead on `bug-sherrif/ant` after the cross-rig deep-dive closes. Known behavior, documented in the formula header comments.

**How to apply:** When working with `sw-investigate` or building tooling around it, treat the pool target as static for investigate+report only. Don't assume all three steps live on the same rig. Any custom batch dispatcher or wrapper script should route step 1 and step 3, and leave step 2 alone.

**Corroborated by:** user direct statement on 2026-04-21 — "the ant is always the first one, and the formula is set up so that the first ant will choose what other rig wants an ant [for] deeper investigation, so this is fine" (in response to my question about whether to parameterize the pool target in the extracted `pour.sh`).
