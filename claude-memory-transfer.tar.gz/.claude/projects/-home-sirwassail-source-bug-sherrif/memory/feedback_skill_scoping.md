---
name: Keep bs-* skills narrowly scoped, don't bundle related-but-distinct concerns
description: CRDT inspection and execution-blob retrieval are separate skills — don't combine them. Let AGENTS.md do high-level disambiguation between them.
type: feedback
originSessionId: b39e02a7-b0da-487a-a6d5-c56acda3afd6
---
When updating bs-* skills, resist the urge to bundle related-but-distinct
workflows into a single skill. Each skill should do one thing well.

**Example from 2026-04-14 (lambda-nullref session)**: I tried to expand
`bs-crdt-inspector.md` to cover both CRDT fetching AND function execution
output blob retrieval. Eric rejected it:

> CRDT data is the more meaningful, let's keep crdtinspector about this,
> execution data only comes up when dealing with executed functions like
> suggestion functions, mostly crdt data is the core source of truth.
> maybe the agents.md file should know about executions vs crdt, but not
> this skill. or maybe we want a different skill about retrieving executions
> and the agents.md just helps disambiguate at a high level

**Why:** CRDT is the primary source of truth for most investigations —
it's what the user sees, it's where most corruption shows up, and bisecting
it is the main diagnostic move. Execution blobs are a specialized topic that
only matters for a minority of investigations (crashes in downstream Lambdas
like classroom/cafe/suggestions). Bundling them makes the common case harder
to find and encourages agents to fetch execution blobs for investigations
where CRDT alone is correct.

**How to apply:**
- Each bs-* skill should own ONE well-defined investigation surface
- When a new surface emerges (like execution blobs), create a new skill,
  don't retrofit an existing one
- Put disambiguation ("which skill should I use for X?") in AGENTS.md or
  CLAUDE.md, not inside any individual skill
- CRDT is the default — steer toward it first. Only reach for execution
  blobs when the investigation specifically involves a Lambda that actually
  executed and a crash that happens inside the Lambda's deserializer
