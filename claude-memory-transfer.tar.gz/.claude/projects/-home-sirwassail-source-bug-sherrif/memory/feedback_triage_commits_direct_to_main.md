---
name: feedback_triage_commits_direct_to_main
description: "bug-sherrif investigation/triage md status changes commit + push straight to main (git push origin HEAD:main), NOT via a PR"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 09b70a4f-3dbb-417e-96d8-973bc7523d3b
---

On the **bug-sherrif** rig, investigation `.md` status-flip changes (and the
regenerated `SHERRIF.md` / `triage/judgement-queue.json`) are committed and
pushed **directly to `main`** — there is no feature-branch PR for triage work.
The worktree branch (`gc-<agent>-<hash>`) currently sits at `origin/main`, its
own remote upstream is gone, so the push is `git push origin HEAD:main`. The
pre-push hook runs `lint:investigations` and blocks on failure. The daily
GitHub Action then projects md → issues; only run `sync-github-issues.ts`
manually if time-sensitive.

**Why:** This overrides the generic crew-worker "all work goes through a
branch and PR" rule, which applies to code rigs (pringle), not the
md-driven triage repo. Prior triage commits (`be5b172`, `3d9dcd6`, the
automated `bs-scan` commits) all landed straight on main, and Eric durably
OK'd "pushing investigations to main."

**How to apply:** After a `/bs-briefing` or triage-sweep judgement pass, edit
frontmatter → `bun run lint:investigations` → `bun scripts/generate-sherrif-md.ts`
→ `git add -u && git commit` → `git fetch && git push origin HEAD:main`
(merge, never rebase, if behind). Do NOT open a PR. The reusable whole-queue
live-PostHog sweep relates to [[reference_instances_jsonl_date_is_unreliable]]
and [[reference_posthog_cli_error_filter]].
