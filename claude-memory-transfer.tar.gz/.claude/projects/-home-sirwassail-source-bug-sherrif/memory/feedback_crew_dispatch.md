---
name: Pick a free crew agent, don't default to one
description: When dispatching work to a pringle crew agent, don't assume a "usual" agent — pick whichever is free. Crew worktree branches are named `<agent>-<hash>`, which reveals identity.
type: feedback
originSessionId: 53648eb7-ebb4-4938-aa1c-b0c7a00aa262
---
When handing work off to a pringle crew agent, do not assume a default or "usual" agent (e.g., don't say "utz is the usual pringle agent"). Instead, pick whichever crew member is currently free.

**Why:** The user corrected this assumption on 2026-04-13 — there's no "default" pringle agent; availability is what matters.

**How to apply:** Before dispatching to a crew agent, check availability (e.g., via `gc status`, `bd list --assignee=<name>`, or branch activity). Crew worker worktree branches are named with the pattern `<agent>-<hash>` (visible via `git branch`), which is a good signal for identifying who's who across rigs.
