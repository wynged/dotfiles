---
name: reference-bun-path
description: "bun isn't on the non-interactive shell PATH — prefix bun commands or the lint/sync scripts fail"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 01871ce4-3a15-4bd9-a154-1cbb88dde021
---

In the agent's non-interactive shell, `bun` is NOT on PATH (`command -v bun`
fails) even though CLAUDE.md tells you to run `bun run lint:investigations`,
`bun scripts/sync-github-issues.ts`, `bun scripts/generate-sherrif-md.ts`, etc.

The binary lives at `~/.bun/bin/bun`. Prefix every bun command:

```bash
export PATH="$HOME/.bun/bin:$PATH"; bun scripts/lint-investigations.ts
```

The pre-push hook finds bun fine on its own (lint ran green on push), so this
only bites direct Bash invocations. Relates to [[feedback_triage_commits_direct_to_main]].
