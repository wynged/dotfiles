---
name: reference_instances_jsonl_date_is_unreliable
description: "triage/data/instances.jsonl is a dedup sample whose `date` mixes event-date and ingest-date — don't read per-day counts as raw volume"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 061dcd18-1a57-43bf-a2c9-827fa1d5b828
---

`triage/data/instances.jsonl` is a DEDUPLICATED triage sample (roughly one
record per user-per-pattern-per-scan), and its `date` field mixes event-date
with **ingest/scan-date**. Confirmed 2026-05-31 on `fetch-fileref-network`:
the Pass-3 cohort (411 raw events / 9 users over 2026-05-08→05-14, per the
investigation doc) was entirely ABSENT under those event dates and instead
backfilled under a single `2026-05-18` scan date (all 9 users, 1 record each).
Early-window dates (Apr) did line up with real event dates, so the field is
event-date *until a backfill scan rewrites a chunk under its own run date*.

Implications for investigate-step volume claims:
- Do NOT cite instances.jsonl per-day counts as raw event volume. It also
  collapses bursts (showed 6 on 04-27 where the doc's live query saw 226).
- The bead's "N last-week / M all-time" trigger numbers are derived from this
  sample, so they undercount raw volume and can cluster on scan dates.
- **The undercount produces FALSE "monitoring-shifted / escalate?" and
  "surging" judgement-queue alerts.** Confirmed 2026-06-01 live-sweep:
  `folder-permissions-denied` showed as "1 new vs 0 prior" (dashboard flagged
  it accelerating) but live PostHog was a single 2-second fan-out burst, 1
  internal user, sandbox-only — the dedup collapsed ~100 raw events to "1".
  `io-read-error` likewise was a single-user session burst, not acceleration.
  Net: before escalating any monitoring-shifted/surging item, re-check live
  PostHog volume + distinct users; a "1 new" or low-N surge is usually a
  dedup artifact of one burst, not a real trend.
- For true recent volume/cohort use LIVE PostHog (`./triage/bin/posthog
  stacktrace '<term>' --since <H>` / `errors`), but note both cap at ~50
  most-recent events (see [[reference_posthog_cli_error_filter]]) — a single
  recent burst can fill the cap and hide the prior-window cohort. Net: trust
  instances.jsonl for *which users/patterns* appeared, not for *how many*.
