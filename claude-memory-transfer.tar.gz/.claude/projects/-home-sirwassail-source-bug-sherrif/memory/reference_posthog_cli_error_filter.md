---
name: reference_posthog_cli_error_filter
description: "triage/bin/posthog — `events --error <pattern>` is a dead flag; use `stacktrace` to filter by message; for breakdowns (URL/day/user) POST HogQL to /query, the CLI can't"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 2ae369d1-2104-4d31-b630-d23846f885ed
---

In `triage/bin/posthog`, `cmd_events` parses `--error <pattern>` into a
variable but **never applies it to the API params** — so
`posthog events --error "foo" --since N` silently returns *all* event
types, looking like a successful filter. Misleading.

To filter `$exception` events by message text, use instead:
- `posthog stacktrace <search_term> --since <hours> --limit <n>` — does a
  real server-side `properties` filter (`$exception_values icontains
  <search>`), groups by stack signature, shows count/users/urls/timestamps.
- Or a direct API call to `events/` with `event=$exception` +
  `properties=[{"key":"$exception_values","value":"<term>","operator":"icontains"}]`
  for a raw event list (then jq a date/user histogram).

`--since` is in **hours** across all subcommands. `errors` only groups a
time-ordered fetch client-side (no message filter) — unreliable for a rare
error buried in high exception volume. Related: [[feedback_aws_profile_discipline]]
(PostHog creds live in `triage/.env`, independent of AWS — usable when
`bs-logs` SSO is expired).

## Dimensional breakdowns: POST HogQL directly (CLI can't)

The CLI gives no way to split a pattern by `$current_url`, day, browser, or
user. For "where/when is this firing" questions, POST HogQL to
`{POSTHOG_HOST}/api/projects/{POSTHOG_PROJECT_ID}/query/` with
`{"query":{"kind":"HogQLQuery","query":"SELECT ..."}}`, `Authorization: Bearer
{POSTHOG_API_KEY}` — all three from `triage/.env`. (Reusable helper lived at
`/tmp/phq.py` on 2026-06-03; re-derive, it's ~30 lines.)

Filter gotchas, verified 2026-06-03 on the resize-observer pattern:
- Filter on **`properties.$exception_values ILIKE '%term%'`** — a string-encoded
  array like `["ResizeObserver loop completed…"]`. Cheap + correct.
- **`$exception_message` is `null`** for browser-level events (window.onerror
  autocapture); don't filter on it. **`toString(properties.$exception_list) ILIKE`
  works but is slow enough to 504** — avoid.
- `properties.$current_url` for the surface split (e.g. `NOT LIKE '%/projects/%'`
  isolates the logged-out landing/auth bucket from in-project).
- `properties.$exception_handled = false` ⇒ window-error autocapture (not the
  `Project.ts` onError path, which is `handled=true` with frames).
- The `/query` gateway frequently returns **502/503/504** under load — wrap the
  POST in retry-with-backoff (handle all three, not just 503).
