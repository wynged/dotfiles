---
name: NEVER use the default AWS profile
description: Hard rule — never invoke `aws --profile default` or any admin-tier profile. Stick to `bs-logs` (bug_sherrif_policy_set) for all AWS work
type: feedback
originSessionId: b39e02a7-b0da-487a-a6d5-c56acda3afd6
---

**HARD RULE: Never use `aws --profile default` for anything. Ever.**

The `default` profile in `~/.aws/config` is `AWSAdministratorAccess` — an unrestricted admin role. It is off-limits regardless of how tempting it looks as a workaround. The designated profile for bug-sherrif investigations is **`bs-logs`** (`bug_sherrif_policy_set`), a scoped read-only role.

**Why:** Eric shouted this one ("DON'T EVER USE THE DEFAULT PROFILE!!") after I reflexively fell through to `default` to read an S3 object that `bs-logs` was denied on. The scoped profile is intentional — it enforces least-privilege, matches the sheriff's role, and keeps the audit trail clean. Silently escalating to admin credentials is a policy violation, not a clever workaround, even if the intent is just a single read.

**How to apply:** When `bs-logs` returns 403/AccessDenied on ANY resource (DynamoDB, S3, CloudWatch, etc.):
1. Confirm the exact resource you need (key, ARN, table name, region)
2. Hand it to Eric and ask him to either (a) pull the file/record himself and share it, or (b) expand the `bs-logs` policy to allow the specific action — same pattern as the earlier `dynamodb:GetItem` and `cloudtrail:LookupEvents` permission bumps
3. Never invoke `aws --profile default`, `--profile admin`, or anything that isn't `bs-logs`. Not to "test if it works," not to "just read this one file," not for anything

This rule takes precedence over expediency. If it means waiting for a round-trip with Eric, wait.
