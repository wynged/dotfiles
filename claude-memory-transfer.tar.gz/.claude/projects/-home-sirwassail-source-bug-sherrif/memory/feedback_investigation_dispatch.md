---
name: Prefer /sw-sling sw-investigate over ad-hoc Agent dispatch
description: For bug investigations, use the sw-investigate formula instead of writing fresh sub-agent prompts. The formula is idempotent and uses a shared ant prompt that's refined over time in-tree.
type: feedback
originSessionId: 53648eb7-ebb4-4938-aa1c-b0c7a00aa262
---
Before dispatching an investigation via the `Agent` tool with a fresh ad-hoc prompt, **check if `/sw-sling sw-investigate` fits**. It almost always does.

```
/sw-sling sw-investigate --var event_summary="<description>" --var event_slug="<slug>"
```

**Why:** The `sw-investigate` formula runs a three-step pipeline on pool ants (bug-sherrif/ant → target rig ant → bug-sherrif/ant) that gathers observability evidence, does code analysis on the implicated rig, and composes the final writeup. It's **idempotent** — re-running appends only new findings. Critically, the ant prompt is versioned in-tree at `/home/sirwassail/source/city_hy/formulas/sw-investigate.formula.toml`, so every refinement we make persists and compounds over time. Ad-hoc `Agent` dispatches don't accumulate that way — each new investigation starts from scratch with a fresh prompt, and improvements we notice go uncaptured.

**How to apply:** When starting a bug investigation (e.g. `/bs-investigate <pattern-id>` or when I'd otherwise spawn an `Agent` tool call), default to the formula. Only fall back to an ad-hoc `Agent` when the work doesn't fit the observability → code → report shape — for example, a pure pattern-matching research task, or a one-off question.

**For batches of ≥2 investigations: use `/sw-investigate-batch`** (added 2026-04-21, replaces retired `/bs-investigate-all`). It documents a 3-in-flight pipeline with `scripts/sw-investigate-batch/pour.sh` + `watch.sh` helpers that: pour each molecule, apply `gc.routed_to` metadata `bd mol pour` doesn't copy, and monitor report-step closures (not epic status — epics don't auto-close). 10-pattern batch on 2026-04-21 ran ~2.5h end-to-end; see tracker `bs-goj`.

**Rough edge (2026-04-13):** the `cross-rig-deps` maintenance order was disabled, so the report bead on bug-sherrif could stall after the deep-dive bead closed on the target rig. **Now enabled** (verified 2026-04-21 batch) — runs every 5m. If report beads stall >10 min after deep-dive closes, check `gc order history cross-rig-deps`.

**Corroborated by:** user feedback on 2026-04-13 — "we should use [ants] instead of just arbitrary sub agents because we're refining their prompt" (in context of the lambda-nullref investigation where I had started to write another ad-hoc dispatch). Confirmed again 2026-04-21 when user explicitly said they don't trust the old in-process `bs-investigate-all` and asked me to replace it with a pool-based batch skill.
