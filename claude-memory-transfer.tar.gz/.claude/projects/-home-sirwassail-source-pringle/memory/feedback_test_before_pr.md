---
name: Test + approve before push/PR
description: After implementation, show the diff and wait for Eric to test and approve before pushing to remote or opening a PR
type: feedback
originSessionId: 794ba7b1-ff5b-4d3b-b9f6-ef273d47780d
---
After completing implementation locally, stop and let Eric verify the change before any shared-state action. Show the diff, offer to start the dev server for a smoke test, and wait for explicit approval. Only then commit-push-PR.

**Why:** On the color-by-legend feature, I edited → committed → pushed → started the PR flow in one autonomous run. Eric pulled back: "wait, did I approve this yet? gotta at least ask me to test and approve before you start PRing." Local commits during agreed work are fine per `CLAUDE.md § Commit Messages — Do Not Ask`, but push and PR creation are shared-state actions that need explicit sign-off — they're visible to reviewers and harder to walk back.

**How to apply:**
- After implementation: present the diff, propose a test path (dev server via /dev, manual repro, or just read), and ask for approval. Do NOT push or invoke /pr until Eric confirms the behavior is correct.
- Local commits during the work are fine — it's the remote/visible actions (`git push`, `gh pr create`, posting comments) that gate on approval.
- If Eric asks for the PR explicitly ("ship it", "go ahead and PR"), that's the green light. Otherwise wait.
