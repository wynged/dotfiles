---
name: Don't reason about space geometry from bbox numbers alone
description: Axis-aligned bboxes overstate spatial extent for non-convex space polygons; verify with area or actual polygon before concluding overlap/coverage
type: feedback
originSessionId: 5ee0e516-9e72-4d4c-ab9f-0a557f993384
---
Space bboxes in Hypar output are axis-aligned rectangles. For non-convex polygons
(pac-man shapes, wraps around corridors, cutouts for other spaces), the bbox can
span a huge region while the actual polygon only occupies a fraction of it.

**Why:** I told Eric "Open Office 1 covers the whole building" based on its bbox
matching the building extents (-20.27..20.27 x -9.14..9.14) — but its area was
278 m² while the building is ~741 m². The polygon just had cutouts for the
other rooms and still reached the building edges at the corners. Eric had to
correct me.

**How to apply:** When reasoning about whether spaces overlap, cover an area,
or fill a region:

1. Always cross-check bbox conclusions against the space's `area` field. If
   `area << bbox_width × bbox_height`, the polygon is non-convex and you
   cannot infer what's inside its bbox.
2. Two overlapping bboxes do NOT mean the polygons overlap — only a
   containment/intersection check on the actual polygons does. Flag bbox
   overlap as "possible, needs verification" not "confirmed overlap."
3. When the model_check or a scorer reports an overlap, that's authoritative
   (runs polygon geometry). Separately-observed bbox coincidences are not.
4. If you need polygon geometry, read it from the API (get_elements, etc.)
   rather than guessing from bbox corners.
