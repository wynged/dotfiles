---
name: reference_unit_factor_diagnostic
description: "When a reported value is a clean fraction/multiple of expected, suspect a m-vs-ft / m²-vs-ft² unit-conversion gap before assuming a geometry bug"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 1bd52173-9e50-4789-bdbe-023ff4a4cb9e
---

When an AI-tool result reports a measurement that looks "collapsed" or "wrong"
but is a clean ratio of the expected value, suspect a unit-reporting gap, not a
geometry/model bug:

- value ≈ **9.29%** of expected (or expected ≈ **10.76×**) → area shown in **m²**
  where **ft²** was expected (1 ft² = 0.092903 m²).
- value ≈ **30.5%** of expected (or expected ≈ **3.28×**) → length shown in **m**
  where **ft** was expected (1 ft = 0.3048 m).

Root cause in pringle: `convertValuesRecursively` (toolInvocationWrappers.ts)
converts result fields by NAME against the tool's `outputUnits`; any field absent
from that map passes through in raw model units (meters). A tool that surfaces a
nested payload (e.g. the space-overlap warning from `#wrapOverlapsAsWarning`,
fields `areaA`/`areaB`/`overlapArea`/`overlapBounds`) must include those field
names in its `outputUnits` or they leak as m²/m. pr-2qxa: the move tools used
`boundingBoxUnits` (x/y/z only) so a 3000 ft² space reported `areaA` ≈ 279.

Diagnostic move: divide reported-by-expected; if it matches a unit factor, audit
the tool's `outputUnits` coverage (see CLAUDE.md "Unit coverage audit") rather
than chasing the geometry. Related: [[reference_eval_flag_pinning]].
