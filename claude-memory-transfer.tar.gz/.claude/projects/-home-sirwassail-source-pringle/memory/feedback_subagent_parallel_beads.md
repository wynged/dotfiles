---
name: subagent-parallel-beads
description: "For parallel-phase beads in a build epic, delegate each bead to a sub-agent in parallel instead of executing inline"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: f4bb9387-52cc-4fc1-b485-ed0fa275c179
---

When a bead-tracked feature epic has a parallel phase (multiple beads with no
inter-dependencies that all depend on the same upstream bead), delegate each
bead to a separate sub-agent (general-purpose Agent) running in parallel rather
than executing them inline in the main conversation.

**Why:** Inline execution serializes parallelizable work AND burns main-
conversation context on per-bead implementation details that the orchestrator
doesn't need to retain. Bead descriptions for swarm-ready plans are already
self-contained (file paths, patterns to mirror, contracts), which is exactly
what sub-agents need.

**How to apply:** After the foundation bead lands, check the dependency graph
for the next set of beads with no inter-dependencies. For each, build a
sub-agent prompt containing: the worktree path, the bead id and full title,
the design contract (what files to create / edit, what existing patterns to
mirror), and any cross-bead interfaces. Launch all of them in parallel via
multiple Agent tool calls in one message. Orchestrator stays focused on
verification and downstream integration. Confirmed by Eric on epic pr-uptz
(2026-05-29) for the T2 / T3 / T4 parallel phase.
