---
name: reference-export-preview-hides-articles
description: pringle export-preview hides all <article>/HCard via _print.scss; new editor cards must be whitelisted
metadata: 
  node_type: memory
  type: reference
  originSessionId: 89a096c0-ba45-4ba3-80b3-d69e455a743f
---

In pringle's PDF export-preview mode, `src/styles/_print.scss` `.export-preview-active article { visibility: hidden }` hides **every `<article>`** except an explicit whitelist (`.page-layout-carousel article`, `dialog article`, `article.view-controls`, `article#zoom-lock-indicator`, and now the custom-PDF editor toolbar/sidebar). Pico **HCard renders as `<article>`**.

**How to apply:** Any new HCard-based UI that must be visible *while editing in export-preview* has to be added to that whitelist or it's silently `visibility:hidden` — rendered, sized, in the DOM, all `v-if` gates passing, just invisible. Don't chase the `v-if` conditions; check computed `visibility`. The actual exported PDF (`.pdf-export` / `@media print`) separately uses `article { display:none }`, so whitelisting for preview does NOT leak chrome into the output.

**Diagnosing invisible-but-rendered UI:** a console DOM probe (`getComputedStyle().visibility` + `getBoundingClientRect()` + `elementFromPoint()` per selector) finds this fast; static code reading does not. Related: in-page editor chrome must counter-scale via `--inverse-scale` (set on `#page-boundary` by HyparView.ts) or it shrinks illegibly on large paper.
