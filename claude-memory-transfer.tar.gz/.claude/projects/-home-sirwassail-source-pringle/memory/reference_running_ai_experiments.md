---
name: reference-running-ai-experiments
description: "How to run/validate AI eval *experiments* (color-by, occupancy-calc, etc.) headlessly, and why the hypar-browser MCP can't trigger them"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 084cd11d-0c30-47e1-8a00-baf6bfd455d2
---

To run an AI eval **experiment** (the multi-trial, report-card kind registered in
`src/qa/aiExperiments.ts` — color-by, occupancy-calc, whole-building, doors-windows,
furniture): use the CLI, NOT the hypar-browser MCP.

- `npm run eval:<id> -- --api=prod [--case=<caseId>] [--trials=N] [--out=path]`
  (e.g. `eval:color-by`). Or directly: `node scripts/run-eval.js --suite=ai-experiment --experiment=<id> ...`.
- This is the **same path CI uses** (`.github/workflows/aiEval.yml` → `run-eval.js`).
  It connects straight to the dev bridge WS (`/__mcp__`) and calls the `run_ai_experiment`
  bridge handler. `--api=prod` is needed so server-side flags load.
- Needs `playwright/.auth/eval-auth.json` (interactive `npm run eval:auth`, opens a
  Chromium to sign in). The auth artifact is **portable/reusable across worktrees** —
  copy a recent one from another crew worktree's `playwright/.auth/` instead of re-minting.
- The dev server is auto-discovered via `.vite/dev-server.json` (don't hardcode a port).

The **hypar-browser MCP cannot run experiments.** `mcp/server.js` only exposes
`run_eval_case` (single cases from `src/qa/evalCases.ts` — NOT the experiment registry),
`send_prompt`, `get_transcript`, `get_canvas_screenshot`, `get_layout_rankings`. The
`run_ai_experiment` handler exists in the in-app bridge (`src/dev/mcpBridge.ts`) but is
not registered as an MCP tool. So don't reach for MCP to validate an experiment; use the CLI.

Transcripts: the `eval-cases` suite supports `--transcripts`; the `ai-experiment` suite
does **not** (the runner captures `result.messages` but the headless report drops them).
See [[reference-eval-flag-pinning]] and [[reference-fixture-json-embedding]].
