---
name: strategic-handoffs-on-multistep-builds
description: "On multi-step bead-tracked builds, /sw-handoff at major milestones — after a task closes, before a parallel group"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: f4bb9387-52cc-4fc1-b485-ed0fa275c179
---

On multi-step bead-tracked feature work, run `/sw-handoff` at strategic
milestones — after a major bead closes, before starting a parallel group of
beads. Don't handoff mid-task or after every bead.

**Why:** Long single-session implementations burn context and risk losing the
design rationale before the work is done. Handoff files a session-note bead
under the epic, then a fresh session re-orients cleanly via `/sw-focus`.

**How to apply:** For a typical foundation → parallel work → integration
breakdown, handoff after the foundation closes (before parallel work starts),
and again after the parallel group closes (before integration). Confirmed by
Eric on the TODO-panel epic pr-uptz (2026-05-29).
