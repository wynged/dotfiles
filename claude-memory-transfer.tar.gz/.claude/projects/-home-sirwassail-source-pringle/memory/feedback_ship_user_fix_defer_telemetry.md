---
name: ship-user-fix-defer-telemetry
description: Eric ships the minimal user-facing fix alone and defers telemetry/internal-hygiene changes — especially cross-repo or wire-distinguishable ones — as measured follow-ups
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 0f833a67-dc83-4bd4-8439-3b139b678700
---

When a bug has both a user-facing fix and a separate internal-hygiene change,
Eric ships ONLY the user-facing fix first. Concrete case (2026-05-29): a
cannot-be-opened bug had (a) an API self-heal — return "no project" when the
last-opened-workflow lookup hits a nonexistent workflow — and (b) a telemetry
"severity split" emitting a distinct `workflow-not-found` code (api PR #1874 +
pringle PR #4916). He dropped the split entirely and kept the self-heal.

**Why:** The split had zero user-facing benefit (pringle renders the same
generic dialog regardless of code, by access-boundary uniformity). Its only
gain was cleaner alerting on residual events — not worth (1) the cross-repo
lockstep + deploy ordering, or (2) the info-disclosure surface of emitting a
distinguishable code over the wire (the very thing the api-716 security bead
was about). Speculative internal hygiene that adds coordination or security
surface isn't worth shipping until the residual problem is actually measured.

**How to apply:** Separate "fixes the user-facing bug" from "improves our
telemetry/observability/internal signal." Ship the former alone, measure the
residual, and add the latter only as a follow-up if the noise persists. Treat
any internal distinction that must be emitted over the wire (or to external
callers) as a security surface, not a free win. When a multi-PR plan is in
flight, proactively ask whether the hygiene half is even needed — don't just
execute the plan. Extends [[feedback_test_before_pr]]; aligns with the
root-cause / simple-first principles in CLAUDE.md.
