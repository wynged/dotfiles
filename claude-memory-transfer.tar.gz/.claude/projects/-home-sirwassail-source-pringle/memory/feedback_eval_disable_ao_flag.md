---
name: feedback-eval-disable-ao-flag
description: "AI eval runs must set the disable-ao URL flag, otherwise rendered trial images come out blocky from ambient occlusion artifacts on simple geometry."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 2add7e81-9517-4a98-a4a9-96209286ae35
---

When running AI evals (anything that renders trial result images of layouts/spaces),
include the `disable-ao` URL flag. Without it the report-card / trial thumbnails
get weird blocky shading artifacts because SAO (screen-space ambient occlusion)
darkens the corners and edges of simple block geometry.

**Why:** Eric flagged trial images coming out visibly blocky. The flag is
registered at `src/3dViewer/HyparView.ts:38` as `disable-ao` — "Disable ambient
occlusion and enable some extra device debugging." `HyparView` watches it
(`HyparView.ts:193, 395`) and `PdfExport.vue:408` also respects it. With it on,
the SAO pass is skipped so flat-shaded space blocks render cleanly.

**How to apply:** Anywhere the eval/QA pipeline constructs a URL or sets URL
flags for the app under test, include `disable-ao` (combine with other flags
via comma, e.g. `?flags=disable-ao,<other>`). Do NOT use `offline` for evals —
the AI chat needs to be logged in, so evals run against the authenticated app.
When auditing an eval-runner or buildingRunner-style code path, check that the
launch URL carries `disable-ao`. Related:
[[camera-controls-lerpLookAt-stale-matrix]] also concerns report-card image
quality from the eval runner.
