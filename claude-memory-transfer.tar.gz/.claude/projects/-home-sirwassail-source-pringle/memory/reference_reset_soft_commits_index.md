---
name: reference_reset_soft_commits_index
description: "git reset --soft + commit ships the INDEX, not the worktree — stage edits first or you commit stale content"
metadata: 
  node_type: memory
  type: reference
  originSessionId: ca2d9843-a974-432b-96ec-989c5b744e34
---

After `git reset --soft <base>` to collapse commits into one, the index still
holds whatever was staged *before* the reset. When the reset follows a sync
`git merge origin/main`, that index = the merge's content, NOT any later
**unstaged** worktree edits. A plain `git commit` then commits the index and
silently ships the wrong/stale version.

On PR #4922 this committed the pre-review `maxQueueSize` cap version I had
already removed in the worktree — i.e. the opposite of the reviewed decision.
The tell was gh's `Warning: N uncommitted changes` on `gh pr create`.

**Guard:** after `reset --soft`, run `git add -A` (or verify `git diff --cached`
CONTENT, not just the file-name list — a name-only check passes because the
right files are staged, just with the wrong content) before `git commit` /
`--amend`. Cross-check the PR diff after pushing: `gh pr diff <N> | grep <thing-you-removed>`
should be empty.
