---
name: reference_eval_auth_zero_tokens
description: AI eval scores 0 with 0 tokens / 0 tool-calls / no error → the EVAL_AUTH_JSON CI secret is stale (Cognito refresh token expired)
metadata: 
  node_type: memory
  type: reference
  originSessionId: 76bdfd0b-0598-4b7b-8477-84617f2027b7
---

When an `aiEval` workflow run "succeeds" but every case scores 0 and the
per-trial `auxMetrics` show `input-tokens: 0, output-tokens: 0,
total-tool-calls: 0` with `error: {}` and ~1.5–2.5s trials, the model was
never invoked — the eval ran unauthenticated. Root cause: the `EVAL_AUTH_JSON`
repo secret's auth has expired. The real auth is a **Cognito refreshToken in
localStorage** (`CognitoIdentityServiceProvider.*.refreshToken`), not the
cookies (which are just `_ga`/PostHog). The idToken/accessToken are 1-hour and
always "expired" in a saved blob; the app re-mints them from the refreshToken on
load — so once the refreshToken passes Cognito's window the eval silently fails.

Diagnose: `gh secret list | grep EVAL_AUTH_JSON` (check its updated date — a
~2-week-old secret is suspect), and confirm the 0-token signature in the report
artifact's `auxMetrics`. The report drops transcripts, so 0-tokens is the tell.

Fix: re-mint (`npm run eval:auth`, interactive prod login → writes
`playwright/.auth/eval-auth.json`), then `gh secret set EVAL_AUTH_JSON <
playwright/.auth/eval-auth.json` and re-dispatch. A recently-minted local
`playwright/.auth/eval-auth.json` can be pushed straight to the secret without
re-minting if its refreshToken is still fresh.

NOT the cause: the storageState `origins[].origin` port (e.g. `:8081` vs CI's
`:8080`). `run-eval.js`'s `loadEvalAuth(httpUrl)` rewrites the origin to the
live target at load time, so the captured port never matters. See
[[reference_running_ai_experiments]] and [[feedback_eval_disable_ao_flag]].
