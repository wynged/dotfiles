---
name: reference_bash_tool_node_path
description: "In the Bash tool, node/npm/npx aren't on PATH (Windows node shadows them, breaks on WSL UNC) — prepend Linux nvm node"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 79976a14-287c-40fd-ac5f-db9611dfac1a
---

In the Claude Code **Bash tool** (a non-interactive shell), `node`/`npm`/`npx`
are NOT usable the way they are in Eric's interactive terminal. The interactive
shell sources nvm; the Bash tool does not. PATH instead leads with the **Windows**
node (`/mnt/c/Program Files/nodejs`, `/mnt/c/ProgramData/nvm`), which breaks under
WSL: `npx` gets hijacked by `CMD.EXE` ("UNC paths are not supported"), and `node`
returns "command not found" / "permission denied" (exit 126).

Fix — prepend the Linux nvm node for the command:
`export PATH="/home/sirwassail/.nvm/versions/node/v24.15.0/bin:$PATH"`
(`.nvmrc` pins **v24**; pick the latest `~/.nvm/versions/node/v24.*/bin`). Then
`node ./node_modules/jest/bin/jest.js …`, `node ./node_modules/eslint/bin/eslint.js …`, etc.

Same trap bites the **/dev skill's tmux pane**: `tmux split-window "... npm run dev"`
can spawn a pane whose shell lacks nvm, so `npm` hits Windows node, fails, and the
pane closes immediately (the dev server silently never starts). Force nvm onto PATH
inside the pane command: `... && export PATH=/home/sirwassail/.nvm/versions/node/v24.15.0/bin:$PATH && npm run dev`.

Also note: **zsh does not word-split unquoted `$VARS`** — `eslint $FILES` passes the
whole string as one arg. Pass file lists as explicit args, or use `${=FILES}`.

Related: [[feedback_dev_port_from_skill]].
