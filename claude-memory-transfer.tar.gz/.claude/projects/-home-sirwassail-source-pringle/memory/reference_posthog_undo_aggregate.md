---
name: posthog-undo-is-rate-tracker-aggregate
description: "In pringle PostHog, undo is a per-minute aggregate (undo-per-minute/undo-total), not a discrete event"
metadata: 
  node_type: memory
  type: reference
  originSessionId: ad2f9a7e-051f-4d88-940c-1d399bc6bfc8
---

pringle records `undo` via `recordRateTrackingEvent('undo')` (in `Project.undo()`),
which only increments an in-memory counter flushed once per minute into a
`rate-tracker` session event (field `undo-per-minute`) and a session-level `$set`
stat (`undo-total`). There is NO discrete per-undo PostHog event. To check whether
undo happened in a session window, look at `undo-per-minute` in the rate-tracker
buckets around the moment AND whether `undo-total` advanced — the per-event
timeline will never show it. The counter lives in `Project.undo()` so it advances
on any undo (keyboard or button), making it code-definitive. Same pattern applies
to other `recordRateTrackingEvent` keys (e.g. `profile-stretch`). See
[[mantis-posthog-access]].
