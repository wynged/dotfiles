---
name: Plans must be bead-anchored and swarm-ready
description: How Eric wants plan-mode plans delivered for non-trivial features on pringle
type: feedback
originSessionId: dc13b663-925b-4176-859d-a75c5ff46342
---
For non-trivial features on pringle, a plan is not ready until it is (a) filed under a bead epic with child task beads and (b) structured so multiple sub-agents could start in parallel with just the bead descriptions.

**Why:** Eric runs work through a swarm of sub-agents that read bead descriptions to pick up tasks. A monolithic plan document is insufficient — the bead tree IS the distribution mechanism, and each child bead must stand alone with file paths, signatures, reuse pointers, and acceptance criteria. (Context: he rejected an `ExitPlanMode` that had a good plan markdown but no bead epic and no child tasks, saying: "you need to file this plan under a bead epic, you are in charge of writing up the best plan that is ready to be built rapidly and correctly by a swarm of sub agents.")

**How to apply:**
- Before calling `ExitPlanMode` for a feature of non-trivial scope:
  1. Create a project epic via `/home/sirwassail/source/city_hy/scripts/start-project.sh <rig-path> "<title>"` — even in plan mode, this is authorized preparatory work because the plan is about the bead tree.
  2. Link the current worktree branch with `link-project.sh <epic>`.
  3. Create one child task bead per parallelizable work stream. Each bead description should include: goal (1 sentence), files to create/modify (with paths and approximate line numbers), reuse pointers, interface/contract it exposes, acceptance criteria, plan-file reference.
  4. Wire dependencies (`bd dep add <task> <depends-on>`) so `bd ready` surfaces wave-1 tasks first.
  5. Update the plan markdown to include a "Bead Tree" section (IDs) and "Swarm Execution Plan" wave table.
  6. Append the same pointer/wave info to the epic notes via `bd update <epic> --append-notes`.
- Be proactive: don't ask whether to file under beads; assume yes for anything above a typo fix.
- Taking agency is valued here — "you are in charge" — so clarify once with `AskUserQuestion` if requirements are genuinely ambiguous, then build the plan yourself without further check-ins.
