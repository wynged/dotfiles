---
name: Dev server port — read from /dev skill output, not hardcoded 8080
description: The pringle dev server port is dynamic; consult the /dev skill for the actual port, do not default to 8080
type: feedback
originSessionId: ffbef80e-ea85-47af-b7c6-7e612e438154
---
When checking whether the pringle dev server is up or hitting it from scripts/
tools, do NOT assume port 8080. The `/dev` skill launches the dev server in a
tmux pane and tells you the resulting port — read it from there.

**Why:** Eric pushed back when I `curl`'d localhost:8080 to check dev status;
the repo CLAUDE.md mentions 8080 as the typical port but the skill actually
binds dynamically. Guessing 8080 wastes a check and misreports state.

**How to apply:** Before probing the dev server in this worktree, either (a)
use `/dev` to start/locate it and capture the port from the skill output, or
(b) ask Eric what port it's on. If neither, don't probe — just describe the
change and ask Eric to reload.
