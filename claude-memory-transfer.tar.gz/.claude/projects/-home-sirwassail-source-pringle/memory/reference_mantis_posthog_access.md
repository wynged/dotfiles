---
name: mantis-posthog-access
description: bug-sherrif/mantis has PostHog access — dispatch for prod event-data questions
metadata: 
  node_type: memory
  type: reference
  originSessionId: ad2f9a7e-051f-4d88-940c-1d399bc6bfc8
---

`bug-sherrif/mantis` (on-demand, asleep by default) has PostHog access via an
events-API tool and can answer prod event-data questions (crash sessions, event
timelines, rate-tracker aggregates). Dispatch by pairing `gc mail send
bug-sherrif/mantis -s ... -m ...` (full detail) with `gc session submit
bug-sherrif/mantis "..."` to wake it — a bare nudge won't spawn an asleep
on-demand session. It pulls the events API; it does NOT pull session-replay
frames by default — ask explicitly if you need replay-level confirmation.
Remember to `unset BEADS_DIR` before `gc session` commands. See
[[posthog-undo-is-rate-tracker-aggregate]].
