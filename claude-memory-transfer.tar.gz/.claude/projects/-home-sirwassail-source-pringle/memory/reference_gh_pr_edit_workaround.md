---
name: gh pr edit broken — use REST API to update PR body
description: In hypar-io/pringle, `gh pr edit` exits 1 with a "Projects (classic) is being deprecated" GraphQL error. Workaround to update PR body via REST API.
type: reference
originSessionId: 830db91f-090d-46ba-8189-02769f457b2f
---
`gh pr edit <N> --body-file ...` and `gh pr edit <N> --body ...` both exit 1 in this repo with:

> GraphQL: Projects (classic) is being deprecated in favor of the new Projects experience, see: https://github.blog/changelog/2024-05-23-sunset-notice-projects-classic/. (repository.pullRequest.projectCards)

The gh CLI's edit mutation touches `repository.pullRequest.projectCards`, which the GitHub GraphQL API now rejects. The failure is silent in piped output (`| tail -5`) because exit code gets lost — always check `$?` or run without a pipe.

**Workaround** — use the REST API directly:

```bash
gh api -X PATCH repos/hypar-io/pringle/pulls/<N> -F body=@/tmp/pr-body.md --jq '.html_url'
```

REST doesn't touch classic projects, so it succeeds cleanly.

**How to apply:** any time you need to update a PR title/body/state on hypar-io/pringle, reach for `gh api -X PATCH repos/hypar-io/pringle/pulls/<N>` with the relevant `-F` flags instead of `gh pr edit`. `gh pr view`, `gh pr list`, `gh pr create`, `gh pr comment`, etc. are unaffected — only the edit mutation fails.
