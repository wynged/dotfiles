---
name: reference-eval-flag-pinning
description: "AI eval setups must pin feature flags via setFlag (ai-color-by ON, occupancy OFF) — server-side flags aren't reliable in the eval run"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 084cd11d-0c30-47e1-8a00-baf6bfd455d2
---

In an AI eval case `setup()`, pin the feature flags you depend on with `setFlag(...)`
from `@/flags` — do not assume the prod eval account's server-side flag state.

- `getFlag = flags[name].state || urlFlags.includes(name)`, so a URL flag can only ADD a
  flag, never unset one. The eval account may have flags on/off in ways that break the run.
- The color-by experiment's `create_visualization` tool is gated behind **`ai-color-by`**
  (`useAiChat.ts` → `useFlag('ai-color-by')` → reactive `tools` computed, `toolDefinitions.ts`).
  If it's not on, the AI never calls `create_visualization` and ends in `final_text`/clarification.
- So `colorByEval` setup pins `setFlag('occupancy', false)` (test the flag-OFF path) AND
  `setFlag('ai-color-by', true)` (so the viz tools register regardless of account flags).

The flag store is reactive, so `setFlag` in `setup()` propagates to the already-created
`useAiChat` before the prompt is sent. See [[reference-running-ai-experiments]].
