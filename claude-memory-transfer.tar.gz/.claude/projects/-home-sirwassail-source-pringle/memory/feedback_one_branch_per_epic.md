---
name: One branch per epic, not per bead
description: For multi-bead epics in pringle, all work lands on a single branch/PR — beads are tracking units, not branch boundaries
type: feedback
originSessionId: 545a31b3-c512-4621-b875-1c491406914d
---
When an epic has multiple child beads (design, impl, validation, ai-eval, prompt routing, etc.), do NOT spin up a branch and PR per bead. All of the work lands on the **same branch**, in one PR scoped to the epic.

**Why:** Eric's correction on pr-uic — I had treated `fix/opening-input-validation` as the branch for pr-uic.3 only and was about to spin a separate branch for pr-uic.4 (bulk primitive). He said: "We should be doing all of this in one branch not just bead." Beads are work-tracking units; the branch is the merge unit for the whole epic.

**How to apply:**
- When `/sw-focus` shows the linked epic + many child beads, assume the current feature branch carries them all unless told otherwise.
- Don't propose "land pr-uic.3 first, then start a new branch for pr-uic.4" — propose "land pr-uic.3 commits, then continue on this branch with pr-uic.4."
- Update the PR title/body as scope expands so the description matches what's actually shipping.
- The branch name may end up narrower than the final scope (here: `fix/opening-input-validation` for an epic that also adds bulk tools). That's fine — don't rename mid-flight unless Eric asks.
- Beads still get closed individually as their work completes; that's orthogonal to branch strategy.
