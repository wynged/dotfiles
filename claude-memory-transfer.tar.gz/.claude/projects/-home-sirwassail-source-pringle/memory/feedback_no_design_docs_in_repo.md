---
name: Don't commit design docs to the pringle repo
description: Pringle repo doesn't host design docs — keep planning out of the working tree; put design content in bead design fields / notes instead
type: feedback
originSessionId: 8f451bdc-adf8-403a-b781-a829ed2d189c
---
Do not create `docs/design/*.md` or any similar design/planning doc in the pringle repo. Design content belongs in bead `--design` / `--notes` fields (durable, non-tree), not committed to `docs/`.

**Why:** Eric, 2026-04-24 — "we don't commit design docs" — said after I created `docs/design/bulk-opening-placement.md` as pr-uic.2's deliverable. The bead description listed `docs/design/...` as an option but the project convention rejects it. Design files are repo noise and pull attention away from implementation.

**How to apply:** When a bead's deliverable is phrased as "design doc as a short markdown in docs/design/... or inline in this bead's notes", always take the bead-notes/design-field path. If a PR-style review of a design is wanted, draft it in the conversation or the bead and get sign-off there — do not open a docs-only PR for planning artifacts. If you've already committed one, `bd update <id> --design-file <path>` to preserve the content, then reset the commit.
