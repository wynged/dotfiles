---
name: Never rebase a feature branch onto main (pull --rebase OR plain rebase)
description: On feature branches that have merged from main, rebase flattens the merges. This bites on pr_feedback flows too — the forager template says "git rebase origin/main" but that step blows up when the PR branch carries a merge commit, causing non-fast-forward push and forcing a force-push.
type: feedback
originSessionId: 814fd9b8-93a2-4e8f-a7ca-b482f313dbe9
---
Never run `git rebase origin/main` (or `git pull --rebase`) on a feature branch. Use `git fetch && git merge origin/main` instead — or skip the update entirely if the branch is already current.

**Why:** Two incidents:

1. 2026-04-10 — PR #4657 (`feat/mcp-bridge`) was polluted with 6 duplicate commits because someone ran `git pull --rebase` on a branch that had previously merged `origin/main`. Rebase flattens merges by default, so it took every main commit the merges had brought in (the PR #4660 show-debug-toggle series and PR #4645 ai-float-rounding series) and replayed them as linear cherry-picks on top of the origin tip. New SHAs, same patches, showed as unrelated diffs in the PR. Evidence in `git reflog`: `pull --rebase (pick): ...` entries.

2. 2026-05-04 — pr-utsf forager run on PR #4791 (`fix/insert-spaces-grid-offset`). I followed the forager prompt template's pr_feedback flow literally (`git rebase origin/main`), which flattened the remote merge commit `b694907d7` into a linear cherry-pick. Push then rejected as non-fast-forward — and force-push is also forbidden by the same protocol. Recovery: `git reset --hard origin/<branch>`, re-apply the fix, push as additive commit.

**How to apply:**
- Never type `git pull --rebase`, `git pull -r`, or `git rebase origin/<base>` on any feature branch.
- The forager prompt template's pr_feedback flow says "git fetch origin main && git rebase origin/main" — **deviate**: use `git merge origin/main` instead, or skip if `git log HEAD..origin/main` is empty.
- `pr-watch` (and now lookout) already auto-merge `origin/main` into open PR branches, so manual updates are rarely needed before pushing additive fix commits.
- If Eric asks you to "update from main" or similar, use merge, not rebase.
- If a local rebase is ever explicitly requested, `--rebase-merges` preserves merge commits so this pitfall doesn't bite — but default behavior does not.
