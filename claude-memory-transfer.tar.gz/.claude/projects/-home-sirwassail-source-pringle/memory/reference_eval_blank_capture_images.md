---
name: reference_eval_blank_capture_images
description: AI-eval report images blank or byte-identical across cases → capture races geometry load / runs after option delete
metadata: 
  node_type: memory
  type: reference
  originSessionId: 0f4a305e-9557-4531-87fd-4a30eee1ee46
---

When an AI-eval report card (color-by / occupancy / wholeBuilding) shows layout
images that are blank or **byte-identical across different cases**, the capture
in `src/qa/<eval>/...Runner.ts` is sampling the canvas before the pasted
fixture's geometry (server "function instances", e.g. Walls LOD 200 / Elements
To Model) has loaded, and/or **after** the trial's design option was deleted
(deleting the option strips the colored model from the scene → empty grid).

Diagnose: flip the runner's `DEBUG_<EVAL>_EVAL` flag to `true` and read per-trial
`imageBytes` (a ~19KB JPEG = blank grid; ~300KB = real render). Identical
`imageBytes`/md5 across cases = same canvas captured.

Fix pattern (applied to color-by in PR #4917, commit 4ded02c8f): `await
proj.waitForUpdatesToFinish()` after setup and again before `captureLayoutImage`,
and move the empty-option cleanup to AFTER capture so the model is still in the
scene.

NOTE: occupancy + wholeBuilding runners share `captureLayoutImage`
(`src/qa/experimentRunner/`) but do NOT yet call `waitForUpdatesToFinish` — same
latent blank-image bug if their fixtures grow heavy. `waitForUpdatesToFinish`
tracks the update pipeline; the silent `catch` in `captureLayoutImage` now warns
via `verbose`. Related: [[reference_eval_auth_zero_tokens]], [[reference_running_ai_experiments]], [[feedback_eval_disable_ao_flag]].
