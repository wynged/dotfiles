---
name: feedback_check_binary_nul_after_edits
description: "After edits, treat a `Bin` line in git diff --stat for a text file as a red flag — a stray NUL byte passes type/lint/test silently"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 9f78f41d-9e8a-4de1-9776-da46c8fe1269
---

After making edits, scan `git diff --stat` for any text file shown as `Bin`,
and NUL-scan touched files (`python3 -c "print(open(F,'rb').read().count(b'\x00'))"`).

A stray NUL byte inside a string literal — e.g. an edit dropping a literal NUL
into a `join('<NUL>')` separator — is valid JS/TS and passes vue-tsc, eslint,
and jest **silently**, but git flags the whole file as binary, breaking
diffs/blame and committing a binary-flagged source file.

**Why:** on feat/custom-pdf-title-blocks an edit put a literal NUL in a hash
separator; every gate stayed green and it was caught only via the `Bin` entry
in `git diff --stat`.

**How to apply:** a `Bin` line in `diff --stat` for a file that should be text
is the tell. Locate the byte (python offset / `od`), replace it, and re-verify
`file <path>` reports "text" (not "data") before committing. Green gates do not
rule this out.
