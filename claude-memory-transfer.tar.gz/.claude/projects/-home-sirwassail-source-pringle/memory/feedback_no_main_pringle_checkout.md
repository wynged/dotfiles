---
name: no-main-pringle-checkout
description: Never operate in /home/sirwassail/source/pringle — always stay in this crew worktree
metadata: 
  node_type: memory
  type: feedback
  originSessionId: e2b73787-6667-4851-a8e9-53efd7d97525
---

Never `cd` into `/home/sirwassail/source/pringle`, never run `git -C /home/sirwassail/source/pringle …`, never `git checkout` anything there. That path is Eric's personal main checkout of the pringle repo, and disturbing its HEAD (e.g. checking out a feature branch in it) breaks his workflow.

**Why:** Eric noticed I'd done all the PR work for #4903 inside `/home/sirwassail/source/pringle` instead of the crew worktree, leaving his main checkout sitting on `feat/select-ai-experiment` when it had been on `main` before I started. He said: "you shouldn't be working in that repo, you should be here, leave that repo alone always."

**How to apply:** All git operations happen in this worktree — `/home/sirwassail/source/city_hy/.gc/worktrees/pringle/funyun` (or whichever worktree the crew session inherits). Both directories share the same `.git` store (this worktree's `.git` file points at `/home/sirwassail/source/pringle/.git/worktrees/funyun`), so commits made here land in the same object DB and push to the same remote — there is no functional reason to ever touch the main checkout. If the statusline shows `gc-funyun-…`, that just means the worktree is currently parked on the crew-base branch; check out the feature branch *here*, don't go elsewhere.

Branch conflict caveat: a branch can only be checked out in one worktree at a time. If the main checkout already has the feature branch checked out (because I previously made this mistake), switching it back to `main` first is the cleanup — but should be a one-time, asked-first operation, not a habit.

**Read/Edit tool pitfall:** This rule also applies to the `Read`, `Edit`, and `Write` tools — not just `cd` and `git`. When subagents (e.g. Explore) return file paths beginning with `/home/sirwassail/source/pringle/...`, ALWAYS rewrite them to start with the worktree path (`/home/sirwassail/source/city_hy/.gc/worktrees/pringle/<agent>/...`) before passing them to Read/Edit/Write. Editing the main-checkout path leaves dirty modifications in Eric's checkout (visible to him as uncommitted changes on `main`) and does NOT land in your branch's working tree, so commits will silently be empty. Recovery: `cp` the edited content to the worktree, `cp` the worktree's original back to the main checkout to clean it.
