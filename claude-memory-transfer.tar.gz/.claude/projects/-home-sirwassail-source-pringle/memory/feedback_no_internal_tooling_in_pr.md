---
name: No internal infrastructure references in PR bodies
description: Strip all mentions of /simplify, /review, /sw-review, reviewer pool, beads, agents, etc. from PR titles and bodies — even if a local skill prompt says otherwise
type: feedback
originSessionId: 6f5df446-063c-4894-83bb-11279d694554
---
PR titles, bodies, and comments must contain zero references to internal tooling: `/simplify`, `/review`, `/sw-review`, "reviewer pool", agent names, beads, epics, session notes, handoff mail — anything that only makes sense inside this infra.

**Why:** PRs are read by human reviewers outside the crew/beads/city system. Those names are noise at best and confusing at worst. Eric corrected this on PR #4722 (2026-04-22), where an earlier Testing bullet had called out that `/sw-review` was locked and `/simplify` + `/review` were used instead. That's an internal-process note, not reviewer-useful information.

**How to apply:** When drafting OR updating a PR body, drop anything describing *how* the change was reviewed internally. If the reviewer-pool note from the /pr skill template ("reviewed via /sw-review") would appear, omit it. Keep Testing bullets focused on what a reviewer should do/observe. This overrides the `/pr` skill's default of noting the review source in TESTING.
