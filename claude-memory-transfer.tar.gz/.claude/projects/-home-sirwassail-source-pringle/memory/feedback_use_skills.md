---
name: Always invoke skills via Skill tool
description: When user references a slash command like /pr, /cleanup, etc., always use the Skill tool — never manually replicate the workflow
type: feedback
---

When the user says "/pr" or any other slash command, invoke it via the Skill tool rather than manually running the underlying commands. Skills have specific templates, rules, and workflows that must be followed. Manually replicating the steps bypasses those rules.

**Why:** User explicitly called out that I skipped the /pr skill's template and rules by manually running `gh pr create` instead of invoking the skill.

**How to apply:** Any time a user references a slash command (e.g., "push and /pr", "/cleanup", "/dev"), use `Skill` tool with the appropriate skill name. Don't shortcut by running the commands yourself.
