---
name: reference_forage_review_metadata_backwards
description: "In /sw-forage-review, cross-check metadata.branch against the harden report's verdict — the branch/superseded pointers can be stamped backwards"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: d9d6a6f5-75e0-45c1-be91-76b907d9a0df
---

When running `/sw-forage-review`, before `checkout`/`approve`, read the harden
report in the bead notes and confirm which branch it blesses (its
`## Assessment: sound` section) vs. which it calls a misdiagnosis. The
`metadata.branch` (what `checkout`/`approve` act on) and `metadata.superseded_branch`
can be stamped **backwards** relative to the harden verdict: the
`assessment`/`testability` grades and the committed regression test may describe
one branch while `metadata.branch` points at the other.

Seen on `pr-2qxa` (2026-06-02): metadata.branch pointed at a misdiagnosed
geometry fix (`fix/space-area-world-transform`, no test) while the verified
red→green test and the `sound` harden verdict belonged to the units fix on the
other branch (`fix/move-overlap-warning-area-units`). The inbox "⚠ CORRECTED —
supersedes …" tag reflected the backwards pointer, not the real verdict.

**Why:** `checkout` swaps to `metadata.branch` and `approve` queues the
`pr_creation` child off `metadata.branch`. If it's wrong, you review and then
ship the misdiagnosed fix — a non-fix that passes review because nobody opened
the right diff.

**How to apply:** If the metadata is backwards, correct it before checkout:
`bd update <id> --set-metadata branch=<right> --set-metadata head_sha=<sha> --set-metadata superseded_branch=<wrong>`.
The signal that confirmed the units fix was correct here is the classic
unit-factor diagnostic ([[reference_unit_factor_diagnostic]]): create_space and
move ran the *same* area computation but reported 3000 vs 278.7 (×0.0929 =
ft²→m²), so the defect was the missing outputUnits conversion, not geometry.
