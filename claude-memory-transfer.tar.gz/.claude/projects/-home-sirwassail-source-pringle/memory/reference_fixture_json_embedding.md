---
name: reference-fixture-json-embedding
description: Pringle eval fixtures embed serialized JSON in a single-quoted JS string — a fragile pattern that drops interior-quote escaping
metadata: 
  node_type: memory
  type: reference
  originSessionId: 084cd11d-0c30-47e1-8a00-baf6bfd455d2
---

Eval fixtures (e.g. `src/qa/colorByEval/fixtures/colorByEvalModel.ts`,
`occupancyCalcEval/fixtures/placeholderProfile.ts`) store the "Copy elements as JSON"
output as a **single-line, single-quoted JS string literal** that `pasteElements`
`JSON.parse`s.

This is fragile: if any element value contains a `"` (e.g. furniture named `Desk - 30" x 72"`),
`JSON.stringify` correctly escapes it to `\"`, but pasting that into a single-quoted JS
literal lets JS string-parsing decode `\"` back to a bare `"`, producing **invalid JSON**
that throws on paste (error like `Expected ',' or '}' ... at position N`). `placeholderProfile.ts`
only survives because it has zero interior quotes.

Fix: in the literal, interior quotes must be `\\"` (so eval yields `\"`). The robust way to
re-embed is `export const x = ${JSON.stringify(jsonString)}` (auto-escapes everything). The
copy serializer itself is fine — it uses `JSON.stringify`; the bug is purely the manual
file embedding. A failed `pasteElements` makes an eval trial error in ~40ms with 0 tokens
and misleading "no create_visualization / final_text" criteria defaults.

See [[reference-running-ai-experiments]].
