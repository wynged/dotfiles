---
name: warn-before-live-worktree-edits
description: Warn Eric to stop testing before fanning out parallel edits — he runs a dev server on this worktree
metadata: 
  node_type: memory
  type: feedback
  originSessionId: d60c7c4e-8436-4bc3-aade-879c6c1cdcce
---

Eric runs a Vite dev server directly against this crew worktree and tests the live app while I work. On 2026-05-29 I launched a 7-agent parallel implementation workflow editing core files (incl. the 1124-line CustomPdfTitleBlockEditor.vue) without warning him. Vite hot-reloaded a half-written file into his open dialog and it crashed with "_ctx.imageUrl is not a function" — a transient artifact of an in-progress edit, not a real bug.

**Why:** parallel sub-agents rewrite files over several minutes; any save triggers a hot reload, so the running app passes through many broken intermediate states. Eric can't tell a transient mid-edit crash from a real regression, and it wastes his time.

**How to apply:** BEFORE launching a workflow/agents that edit files (especially multi-file or one big SFC), tell Eric the app will be unstable and to hold off testing until I give the all-clear. When the batch lands, run gates (vue-tsc/eslint) and confirm consistency before saying it's safe to test. If he reports a console error mid-batch, first suspect in-flight edits (check whether the workflow is still running) rather than treating it as a final-state bug. See also [[feedback_test_before_pr]].
