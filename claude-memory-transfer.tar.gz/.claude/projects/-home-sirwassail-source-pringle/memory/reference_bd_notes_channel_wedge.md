---
name: reference_bd_notes_channel_wedge
description: Reading raw bead notes can wedge the tool-result channel; dump to a file and use Read instead
metadata: 
  node_type: memory
  type: reference
  originSessionId: 686b4c6b-1ba4-4198-a7d8-14836fb763f1
---

A non-printable byte embedded in a bead's `notes` field can wedge the entire
tool-result channel: after `bd show <id> --json | jq -r '.[0].notes'` echoes it
to the channel, every subsequent command (even a bare `echo`) returns EMPTY
output, though the commands still execute. This stranded a prior ant mid-task on
deep-dive bead bs-mol-vqu21 (event `missing-identity-strategy`) and forced a full
re-route to a fresh ant.

Safe pattern when reading foreign/unknown bead notes:
1. Redirect to a file, never to the channel:
   `bd show <id> --json | <city>/scripts/launder-bd-json.sh | jq -r '.[0].notes' > /tmp/notes.raw`
2. Scan for non-printable bytes before reading:
   `LC_ALL=C grep -cP '[^\x09\x0A\x20-\x7E]' /tmp/notes.raw` (expect 0).
3. Open the file with the Read tool (handles binary/non-print gracefully) rather
   than `cat`/`echo`.

`launder-bd-json.sh` only JSON-escapes control chars so `jq` can parse; it does
NOT strip a stray NUL/non-UTF8 byte inside a string. That residual byte is what
reaches and wedges the channel. Related: [[feedback_check_binary_nul_after_edits]]
(a stray NUL byte also silently flags files as binary in diffs).
