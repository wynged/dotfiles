---
name: Don't ask for commit message approval mid-flow
description: When cutting a sequence of commits in a working session, just commit with a reasonable message — stop asking Eric to approve each one
type: feedback
originSessionId: 5ae23ab6-166f-4286-8a40-93e39c954b23
---
Don't ask Eric to approve commit messages one at a time when we're in a working flow. Propose-and-wait per commit is tolerable once at the start of a handoff (if the handoff mail explicitly asked for it), but doing it on every follow-up commit is annoying and slows things down.

**Why:** Eric explicitly said "stop asking me about commit messages" after the second approval-request in a row during pr-0cx.17 work.

**How to apply:** In a session where Eric is actively collaborating and commits are rolling, draft a concise message in the repo's existing style (`feat:`/`fix:`/`refactor:` prefix, em-dash sub-clauses) and run `git commit` directly. If the message turns out to be wrong, amend or follow-up. Only re-ask for approval when (a) the scope or direction of the commit is itself uncertain, or (b) the handoff mail explicitly told me to propose first.
