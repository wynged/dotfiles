# Memory Index

## Feedback
- [Don't rebase unnecessarily](feedback_no_unnecessary_rebase.md) — avoid rebasing feature branches unless actually needed

## Project: pringle (hypar-io/pringle)
- TypeScript/Vue codebase
- No node_modules in crew/lays clone — can't run local type checks
- Build: `vue-tsc && vite build`, Lint: `eslint --ext .ts,.vue src`
