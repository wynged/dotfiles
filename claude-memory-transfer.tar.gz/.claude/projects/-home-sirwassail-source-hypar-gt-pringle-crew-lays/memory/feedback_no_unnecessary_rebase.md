---
name: Don't rebase unnecessarily
description: Avoid rebasing feature branches on main unless actually needed — it rewrites history and forces force-pushes
type: feedback
---

Don't blindly follow `gt hook` advice to `git pull --rebase` onto main. Only rebase when there's an actual conflict or the user asks for it. Rebasing rewrites commit history, breaks normal pushes, and forces force-pushes on existing PRs.

**Why:** Unnecessary rebase on feat/sensible-window-placement rewrote 6 commits, caused push rejection, required force push to update PR #4486.

**How to apply:** When `gt hook` says "X behind origin/main", evaluate whether a rebase is needed right now. If you just need to push a new commit, push it directly.
