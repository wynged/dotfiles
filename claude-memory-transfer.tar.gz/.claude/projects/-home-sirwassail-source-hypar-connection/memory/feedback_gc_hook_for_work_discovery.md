---
name: Use `gc hook` for ant work discovery
description: Prefer `gc hook` over the multi-step bd list/ready/cross-rig-find-work sequence when checking for work at ant startup
type: feedback
originSessionId: eff63053-cf48-4c49-a0a3-bc39335f987a
---
When an ant worker spawns and needs to discover work, run `gc hook` instead of the multi-step startup protocol (bd list --assignee / bd ready --assignee / bd ready --metadata-field gc.routed_to / cross-rig-find-work.sh).

**Why:** `gc hook` uses the agent's configured `work_query` to check assigned work first, then routed pool work, in one call. It's the consolidated entry point the harness uses for work-available hooks. The multi-step protocol in the worker prompt is the long-form equivalent — `gc hook` collapses it.

**How to apply:** At ant startup, after `bd prime`, run `gc hook`. Exit 0 means work exists (the output is the bead list); exit 1 means no work — run `gc runtime drain-ack` and exit. If there is work, claim and proceed as usual (check METADATA for molecule_id, then `bd mol current`, etc.). Cross-rig routing still matters: if the claimed bead is in a foreign rig's store, keep BEADS_DIR pointed at that store for the session.
