---
name: reference_dolt_eventsdata_telemetry_bloat
description: "~/.dolt/eventsData accumulates millions of queued telemetry .devts files — big silent disk hog, safe to purge"
metadata: 
  node_type: memory
  type: reference
  originSessionId: db8d032e-254b-4454-833c-06579c5106b1
---

`~/.dolt/eventsData/` is dolt's local anonymous usage-event telemetry queue. Each event is a ~148-byte `.devts` file; if dolt can't flush them (offline / no network) they accumulate indefinitely. On 2026-05-29 this dir held **1.4M files = 5.4G** and was the single biggest *safe* disk win on a disk-full warning.

**Safe to purge** — pure anonymous metrics, nothing functional. Fastest purge avoids 1.4M slow `find -delete` per-file syscalls in the foreground:
```
cd ~/.dolt && mv eventsData eventsData.purging && mkdir eventsData   # instant swap, dolt keeps writing to fresh dir
rm -rf eventsData.purging   # run in background; df climbs as inodes unlink
```
The dir has a `lock` file but the swap is safe; dolt recreates structure as needed.

Gotcha: `df` looks flat until the rm actually completes (space frees progressively as inodes unlink). Don't trust an early `df` reading mid-purge.

Other dolt-adjacent cleanup targets seen same session: `~/backups/*-revive/-floor/-scratch` (old DR scratch from a past recovery — keep `.dolt-backup/`, that's the live path), `.beads.safety-<ts>/` one-off snapshots, and the live `.beads/dolt` via [[project_beads_bloat_recipe]]. The real non-dolt hog is `.gc/worktrees/` (~30G of per-agent node_modules). Related: [[reference_dolt_recovery]], [[reference_beads_backup_bloat]].
