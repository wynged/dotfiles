---
name: Dual-location packs — gc loads from .gc/system/packs/, not repo packs/
description: gc reads orders/scripts/prompts from .gc/system/packs/ (runtime, gitignored), not from the repo-gitted packs/ tree. Edits must be dual-placed to take effect.
type: reference
originSessionId: 17dcef94-e14d-4e99-a17e-7207d0dcfd1e
---
**gc loads pack content from `.gc/system/packs/`, NOT from `packs/`** in the city repo. Discovered Session 20 (2026-04-12) while activating `mol-dog-purge-dropped` — the new order didn't appear in `gc order list` after a full restart because the files were only in `packs/maintenance/`, not in `.gc/system/packs/maintenance/`.

## How to verify

- `gc order show <name>` prints an absolute `Source:` path. That's the file gc actually read. For existing orders like `mol-dog-reaper`, the source is `/home/sirwassail/source/city_hy/.gc/system/packs/maintenance/formulas/orders/mol-dog-reaper/order.toml` — NOT the repo path.
- `gc order list` rescans each invocation. No daemon restart needed once files are in `.gc/system/packs/`. Saves you a wasted full restart.

## How to apply an edit

Every file edit in `packs/<pack>/` must be dual-placed:

1. Edit (or create) the file in `packs/<pack>/...` (source of truth, gitted).
2. Copy to the mirror at `.gc/system/packs/<pack>/...` (runtime, gitignored).
3. Run `gc order list` / `gc order show` to confirm gc sees it.

For new order files:
```bash
cp -r packs/maintenance/formulas/orders/<name> .gc/system/packs/maintenance/formulas/orders/
cp packs/maintenance/scripts/<script>.sh .gc/system/packs/maintenance/scripts/
chmod +x .gc/system/packs/maintenance/scripts/<script>.sh
```

## What's unknown

- Is this intentional or a missing sync step? `.gc/system/packs/*/pack.toml` gets its mtime bumped on `gc start` (so something writes to it), but nothing copies from local `packs/`. Likely gc binary embedded resources are extracted on start without reconciling local edits.
- Session 19's `dog.md.tmpl` edits and `propulsion.md.tmpl` WorkQuery fix live in `packs/maintenance/` — **unclear whether those edits ever became runtime-effective.** Worth verifying next time we touch the dog prompt. The two `pack.toml` files have diverged: `.gc/system/packs/maintenance/pack.toml` uses old `min_active_sessions`/`max_active_sessions` schema, `packs/maintenance/pack.toml` uses new `[agent.pool] min=0 max=3`. If gc loaded local, the schemas would match.
- Only ONE `pack.toml` for maintenance exists on the whole machine (`/home/sirwassail/source/city_hy/packs/maintenance/pack.toml`). The `.gc/system/packs/maintenance/pack.toml` must therefore be generated from embedded resources.

Tracked in `ch-pk5oxu` (P3) for future investigation.

## Where to look if touching pack content

- `_gascity_howto/04-formulas-molecules.md` has a gotcha callout under "Order discovery"
- `CLAUDE.md` has a one-paragraph gotcha under "Config gotchas"
- `_my_city/session-log.md` Session 20 entry has the full discovery narrative
