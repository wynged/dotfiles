---
name: Crew claim convention — never use --claim
description: Crew prompts must claim work via $GC_SESSION_ID, not bd's --claim flag, to avoid alias-assignee phantom spawns and reconciler tick-drag
type: feedback
originSessionId: 695c04f2-1e5f-45f6-b5bf-ca9bfe45ee2d
---
When a crew/pool/ant/reviewer/witness prompt instructs an agent to claim
a bead, the canonical form is:

    bd update <id> --assignee "$GC_SESSION_ID" --status=in_progress

NEVER use these legacy patterns in any crew prompt or skill:

- `bd update <id> --claim` — sets assignee to the bd actor, which on this
  machine resolves to `git config user.name = "Eric W"`. Every agent's
  claim ends up looking like a human claim. The check script
  (`scripts/check-alias-assignees.sh`) flags human-name assignees as
  reconciler tick-drag drivers (beads stay in `assignedWorkBeads` with
  `ready=map[]`, churning per-named-spec dolt queries every tick).
- `bd update <id> --assignee "$GC_SESSION_NAME"` — writes the alias-shape
  (`pringle--combo`). When the session is later swept, the closed bead's
  alias squats the name slot and drives `poolDesired` phantom-spawn
  cascades (the ch-vg7 / project_alias_assignee_spawn_bug pattern).

Read queries should also use `$GC_SESSION_ID` for coherence with writes:

    bd list --assignee="$GC_SESSION_ID" --status=in_progress
    bd ready --assignee="$GC_SESSION_ID"

**Why:** `$GC_SESSION_ID` is the concrete bead-id of the running session
(e.g. `ch-6gy`), set in every agent shell. It's neither alias-shaped (no
`/` or `--`) nor human-name (no space or `@`), so the check script and
reconciler both treat it correctly. It's stable across normal sleep/wake
cycles — only changes when the session bead is fully closed and reborn,
which is rare and requires manual reassignment anyway.

**How to apply:** when reading or editing any prompt under
`prompts/{crew,pool-worker,ant-worker,sw-witness,sw-reviewer,overflow-crew}.md`
or any crew skill in `overlays/crew*/.claude/`, swap `--claim` and any
`$GC_SESSION_NAME`/`$GC_AGENT` assignee references for `$GC_SESSION_ID`.
The `sw-focus.md` warnings ("Do NOT use `--claim` on epics") stay — they
specifically warn against the legacy pattern and remain accurate.

Convention landed 2026-04-28 after pr-60b9.2 surfaced the "Eric W"
contamination during a phantom-spawn investigation.
