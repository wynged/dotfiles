---
name: MCP SDK client request timeout footgun
description: The Anthropic MCP SDK client defaults to a 60-second per-tool-call timeout. Any tool that wraps a real LLM call needs an explicit longer timeout or the client gives up while the server keeps running.
type: reference
originSessionId: 1b3bd701-13e5-4ce8-b171-c53712dcd2eb
---
The `@modelcontextprotocol/sdk` client (version 1.29.x at time of writing) defaults to a **60-second request timeout** for `client.callTool({...})`. For any MCP tool that wraps a long-running operation — especially anything that calls a real LLM and waits for completion (e.g. running an AI eval, agent loop, etc.) — this is far too short.

**Symptom:** `McpError: MCP error -32001: Request timed out` in the client log after 60s. The server-side bridge handler keeps running and may eventually persist its result, but the client has lost track of it.

**Fix:** Pass an explicit timeout via the third argument to `callTool`:

```js
const result = await client.callTool(
    { name: 'run_cycle', arguments: { ... } },
    undefined,                     // result schema (unused here)
    { timeout: 10 * 60 * 1000 }    // 10 minutes
);
```

Match the timeout to the slowest realistic case for your tool. The pringle RL-loop smoke test (`scripts/test-mcp-run-cycle.js` in cheezeit's worktree) uses 10 minutes for a 2–5 minute eval.

**Note for Claude Code as MCP client:** Claude Code's built-in MCP client may have its own (possibly longer) default. Verify before assuming. The 60s default is specifically the bare-SDK Node client behavior.

**Related:** When debugging an MCP handler crash, also forward `err.stack` from the bridge handler — by default many handlers only forward `err.message`, so you can't tell which line crashed. See `src/dev/mcpBridge.ts` in the pringle RL-loop branch for the right pattern (`error: stack ? \`${message}\n${stack}\` : message`).
