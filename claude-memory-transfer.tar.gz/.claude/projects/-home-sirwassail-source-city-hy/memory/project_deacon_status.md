---
name: Deacon status in city_hy
description: Deacon agent is not running in city_hy; its patrol steps are being migrated to exec orders; gc dolt health has a latent O(history) bug
type: project
originSessionId: 9aaad051-d402-4a8f-a1c5-b6d11c6547d7
---
**Deacon is not wired into city_hy.** `gc session list --json` shows no `deacon`
session. Anything invoked only from `packs/gastown/formulas/mol-deacon-patrol.formula.toml`
will never fire on its own — manual invocation is the only path.

**Deacon patrol steps are being migrated to exec orders** in
`packs/maintenance/formulas/orders/`. Look for the comment
`# Replaces deacon patrol step: <name>` at the top of each `order.toml` — as of
2026-04-10, `cross-rig-deps` and `orphan-sweep` have been ported, `gc dolt health`
has not.

**Latent bug in `packs/gastown/commands/health.sh:105`:** runs
`dolt log --oneline | wc -l` per database with no timeout. On beads-backed DBs
with 100k+ auto-commits this walks the full commit graph and can peg CPU for
hours. Kills with SIGKILL only (dolt ignores SIGTERM). Fix when the step gets
migrated into an order: swap for `SELECT COUNT(*) FROM dolt_log` via the existing
`$conn_args` sql-server connection. Currently dormant because nothing runs it.

**Why:** This came out of a 2026-04-10 investigation where a manually-fired
`gc dolt health` from a mayor session was stuck at 140% CPU for 98 minutes. Full
context in `_my_city/session-log.md` Session 14.

**How to apply:** (a) If something on deacon's old patrol list seems broken or
missing, check whether it's been migrated to an order yet before assuming the
deacon will handle it. (b) If `gc dolt health` ever gets invoked (manually or
via a future order), expect it to hang unless the O(history) line is fixed
first. (c) Don't reflexively kill deacon-related config — the migration is
in-progress and the agent definition may still be load-bearing elsewhere.
