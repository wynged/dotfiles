---
name: bd hooks skip order-tracking + session beads
description: city_hy patches .beads/hooks/{on_create,on_update,on_close} to skip order:* and issue_type=session beads — gc upgrades will clobber, re-apply
type: project
originSessionId: 599772cb-6c78-46e0-ad02-8239a74592c1
---
`.beads/hooks/{on_create,on_update,on_close}` in city_hy fork-exec `gc event emit` on every bead lifecycle event. Two classes of bead drove almost all forks:

1. **Order-tracking beads** (title prefix `order:` or label `order-tracking`) — 5–6 hooks per order run, dozens of orders/min.
2. **Session beads** (`issue_type=session` like `ch-2dd0c mayor`) — supervisor heartbeats `state` and `synced_at` every few seconds per named session, ~10 sessions = constant churn.

Patch: each hook short-circuits with
```sh
case "$DATA" in
  *'"title":"order:'*|*'"order-tracking"'*) exit 0 ;;
  *'"issue_type":"session"'*) exit 0 ;;
esac
```
before the `gc event emit` fork. Cache-reconcile still picks up the beads on its own scan.

**Why:** Pattern-C CPU spikes (8–11 concurrent gc procs, gc_sub_cpu ~7700% jiffies per burst) traced via process-parent capture (/tmp/burst.log). First filter alone left session-heartbeat residue still firing 11-proc bursts. Patched 2026-05-03 in city_hy only.

**How to apply:** If gc upgrades **OR supervisor restarts** overwrite the hooks, re-apply both `case` arms. The clobber on supervisor restart (not just `gc upgrade`) was confirmed 2026-05-03 — the gc binary itself embeds the upstream hook content as Go strings (`strings /home/sirwassail/go/bin/gc | grep "Installed by gc"` returns 2 hits) and `gc-beads-bd.sh init` re-installs them on every per-rig init pass. Watch for `gc_subproc_n` returning to 8–11 in /tmp/cpu_sample*.csv as the regression signal. The right-place upstream fix is in gascity (skip emit for these classes, or replace fork-exec with a Unix-socket write to controller.sock) — not yet filed. **Tracked agenda item:** wire a periodic city-side re-applier order so this becomes self-healing.

**Risk to watch:** the session-bead skip means events.jsonl won't see session-state transitions; consumers that tail the event stream (rather than reconcile against dolt) would miss them. Lookout's hall pane uses tmux-only awake detection (per `project_hall_tmux_only.md`), so it's safe. If a future feature wants live session events, revisit.
