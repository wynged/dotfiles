---
name: named-session-workdir-template-leak
description: "Recurring 2026-05-13 (combo) + 2026-05-14 (frito) — named_session bead spawn caches template-name workdir (.gc/worktrees/pringle/crew) or leaks pringle/crew into alias_history; upstream trigger is poolDesired-on-template (ch-9y0t)"
metadata: 
  node_type: memory
  type: project
  originSessionId: 533b24de-5829-472e-bd5c-ceba51ca547e
---

A pringle on_demand named_session (combo / ch-nq45m) booted into the template's worktree path instead of its own:

- `metadata.work_dir = .gc/worktrees/pringle/crew` (wrong — that path was a non-worktree dir with overlay-only files, no `.git`)
- `metadata.alias_history = pringle/crew` ← smoking gun: combo had been aliased to the template name at some prior reconcile
- `metadata.alias = pringle/combo`, `agent_name = pringle/combo`, `template = pringle/crew`

The other named-crew (utz, frito, taki, etc.) all had correct work_dirs in the same window, so this was per-bead drift, not a global template-resolution bug. Likely combo's bead was created during a transient state where `qualifiedName` fell through to the template's qualified name (`pringle/crew`), and `agents/crew/agent.toml` expanded `{{.AgentBase}}` → `crew`. The wrong path was then cached on the bead and remained sticky across `generation` bumps.

Rhymes with — but is distinct from — [[project_named_session_materialize_skills_fix]]: that fix routed materialize-skills' `--agent` to the template name on purpose; this bug is the same template-name leak escaping into `qualifiedName` for work_dir resolution.

**Why:** `internal/workdir/workdir.go::PathContextForQualifiedName` derives `AgentBase` from `config.ParseQualifiedName(qualifiedName)`. If `qualifiedName` is ever the template's qualified name for a named_session bead, AgentBase becomes the template's base name and the worktree path is wrong forever (cached on the bead).

**How to apply:** When a crew member reports "I'm not in a worktree" or lands in a generic dir, check `gc bd show <session-bead> --json` for `metadata.work_dir`. If it ends in the template basename (e.g. `/crew`) instead of the session's name, the recovery is:

```
gc session close <alias>
gc bd update <bead-id> --set-metadata work_dir=""
gc bd update <bead-id> --set-metadata alias_history=""
gc session submit <alias> "..."   # spawns a fresh bead with correct work_dir
```

Move the stray `<template>/` directory aside (e.g. `.crew.bad`) before respawn so worktree-setup --sync doesn't get confused by the orphan. Verify the new bead's `metadata.work_dir` ends in the session name, not the template name.

**2026-05-14 update — frito recurrence + root-cause chain identified:**

Frito (ch-hj5x7) booted with the correct `work_dir=.gc/worktrees/pringle/frito` but still wrote overlay files into `.gc/worktrees/pringle/crew/` and ended up with `alias_history=pringle/crew`. The smoking-gun was supervisor-log `poolDesired: pringle/crew = 1` repeating 7,107 times between log lines 1747796–1899510 — the [[project_alias_assignee_spawn_bug]] / ch-9y0t pattern, **still open upstream**.

Trigger chain:
1. A work bead lands with `assignee=pringle--<crew>` (double-dash session_name shape, NOT the slash alias shape).
2. Supervisor's named-session lookup misses (expects `pringle/<crew>` slash form), falls through to `poolDesired` keyed on the **template** (`pringle/crew`).
3. The reconciler tries to spawn a pool slot for `pringle/crew`; overlay-copy and `.runtime/session_id` writes use the template's qualified name → land in `.gc/worktrees/pringle/crew/`.
4. Whichever named crew happens to wake during that window inherits `alias_history=pringle/crew` on its bead (combo last time, frito this time). Russian roulette.

**Lookout is NOT the producer** (Eric's hypothesis 2026-05-14). All `lookout/` `bd update` calls set metadata only (`session_name=`, `agenda.rank`, `kind`, `pr_feedback`, `gc.routed_to`), never `--assignee`. Handoff path uses slash-form alias via `gc session close`/`submit`.

Actual producers of `pringle--<name>` assignee shape:
- `prompts/graph-worker.md:83` — `bd update "$SIB" --assignee="$GC_SESSION_NAME"` (double-dash shape)
- `gascity/internal/bootstrap/packs/core/assets/prompts/pool-worker.md:18-21` (gascity-bundled)
- `gc handoff` binary path (per ch-9y0t description; not patchable locally)
- Any crew slash command that uses `$GC_SESSION_NAME` instead of `$GC_SESSION_ID` for assignment (see [[feedback_crew_claim_convention]])

Defenses in place: `scripts/check-alias-assignees.sh` flags contamination, pr-watch's `resolve_owner_bead()` rewrites alias→bead-id on the call sites it controls. Root fix is upstream gascity (ch-9y0t).

**2026-05-17 update — ch-9y0t fix committed (not yet deployed/verified):**

First fix landed on gascity branch `fix/pool-desired-skip-named-session-templates` (1 commit off main, `4667306a`), carried on `local-integration` (combo) via merge `c7b51d44`. New helper `isNamedSessionTemplateOnly(cfg, agent)` in `cmd/gc/pool_desired_state.go` gates the three `cfg.Agents` loops so a pure named-session template (no namepool, no max_active_sessions) never produces `poolDesired`. Verification check-in bead: **ch-5sl** (agenda-infra). Baseline pre-deploy: `poolDesired: pringle/crew = 1` had fired 7135× in supervisor.log. NOTE — per-alias `poolDesired` lines (`pringle/frito`, `mayor`, ...) are legitimate keep-alive demand and must survive the fix; only the bare template `pringle/crew` entry is the contamination.
