---
name: Dog pool (city_hy maintenance workers)
description: Elastic city-scoped dog pool runs maintenance formulas (doctor, backup, stale-db, phantom-db, compactor); enabled Session 19 after long disablement
type: project
originSessionId: 2bf6ba5d-bf2c-42a9-9379-24f8a8cbd8bf
---
**State as of Session 19 (2026-04-12):** Re-enabled after months of being
skip-listed in `city.toml [orders] skip = [...]`. Eric had disabled the whole
maintenance pack to test running without it and to avoid token churn. The
result was 16 GB of trash hoarded in `.dolt_dropped_databases` over ~24h
because `mol-dog-phantom-db` had no executor.

**Pool config** (`city.toml`):
- `name = "dog"`, no `dir` (city-scoped)
- `min_active_sessions = 0`, `max_active_sessions = 3`, `idle_timeout = "2h"`
- `prompt_template = "packs/maintenance/prompts/dog.md.tmpl"`
- `namepool = "namepools/dogs.txt"` (15 pet names, locally created)
- `scale_check = "scripts/city-scale-check.sh dog"` (locally created — counts
  open beads with `metadata.gc.routed_to=dog`)
- No `overlay_dir` — `packs/maintenance/overlays/default/` doesn't exist locally

**Active dog formulas** (all routed via `target=dog` in their order definitions):
| Formula | Interval | What it does |
|---------|----------|--------------|
| `mol-dog-doctor` | 5m | Probe dolt health (read-only) |
| `mol-dog-backup` | 15m | Sync DBs to backup remotes (rig + offsite) |
| `mol-dog-stale-db` | 15m | Detect/report stale DBs |
| `mol-dog-phantom-db` | 1h | `dolt_purge_dropped_databases()` — reclaims trash dir |
| `mol-dog-compactor` | 24h | Flatten dolt commit history (daemon-executed; dog observes only) |

**2026-04-13 — upstream caught up to workaround #2:** gascity PR #528 extended default `EffectiveScaleCheck()` to add a third query counting open molecule-type beads with `gc.routed_to=<template>` and no assignee — exactly what the custom `city-scale-check.sh dog` does (minus type filter). Once city_hy runs gc ≥ v0.14.1, the custom script *may* be removable by dropping the `scale_check` field entirely and letting the default fire. Not tested yet; leave the script in place until a quiet window to verify dog pool still scales correctly with the default. Remaining workarounds #1 and #3 (prompt template shared-includes, stale formula list) are still active — those are pack content issues, not core gc.

**Workarounds applied this session** (file as-is, fix upstream):

1. **`packs/maintenance/prompts/dog.md.tmpl` references gastown templates**
   that aren't in the maintenance pack: `{{template "architecture" .}}` and
   `{{template "following-mol" .}}`. Copied them from
   `gascity/examples/gastown/packs/gastown/prompts/shared/` into
   `city_hy/packs/maintenance/prompts/shared/`. Filed as ch-c7bhb7.

2. **The maintenance pack's dog WorkQuery template var resolves wrong.**
   The `{{ .WorkQuery }}` substitution in propulsion-dog produced an
   assignee-based query, so dogs spawned, found nothing, and exited.
   Replaced with explicit `bd list --metadata-field gc.routed_to=$GC_TEMPLATE
   --status=open --json` in both `dog.md.tmpl` and `shared/propulsion.md.tmpl`,
   mirroring `prompts/ant-worker.md`. Filed as ch-unjzm7 (closed Session 19).

3. **Dog prompt's "Available Formulas" list was stale** — only listed
   shutdown-dance/jsonl/reaper. Added doctor/backup/stale-db/phantom-db/
   compactor. Filed as ch-r1ueps (closed Session 19).

**How to verify the pool is healthy:**
```bash
gc order check                       # are dog formulas due?
bd list --metadata-field gc.routed_to=dog --status=open --json | jq length
gc session list | grep dog           # are dogs spawning?
gc sling --dry-run dog ch-zbf31g     # does sling recognize the agent?
```

**How to wake the pool manually if scale_check is wrong:**
```bash
gc sling --force --nudge dog <bead-id>
# prints "No running pool members for 'dog' — poked controller for wake"
# pool spawns within ~10s
```

**Related:** project_ant_pools.md (sister pattern, rig-scoped), reference_dolt_recovery.md (mol-dog-phantom-db is the runbook automation).
