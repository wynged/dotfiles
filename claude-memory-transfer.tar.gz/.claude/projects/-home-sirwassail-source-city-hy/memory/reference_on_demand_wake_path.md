---
name: On-demand named session wake path
description: For mode=on_demand named sessions, gc session submit (not wake or nudge) is what actually spawns them; wake clears flags, nudge queues on held sessions
type: reference
originSessionId: 26e263cc-dfd7-4469-8693-b089adb91a7b
---
For named sessions with `mode = "on_demand"` in city.toml, the commands behave differently than for always-on sessions:

- `gc session wake <id>` — clears `user-hold` and quarantine flags only. Does NOT spawn the tmux session.
- `gc session nudge <id> "msg"` — if session is suspended/asleep, queues the message but does NOT wake/spawn. Requires an already-running session.
- `gc session submit <id> "msg" [--intent default|follow_up|interrupt_now]` — the semantic wake path. Wakes, spawns, AND delivers the message. This is the working dispatch primitive for sleeping on-demand agents.

**How to apply:** Any dispatch script that targets crew that may be on-demand-and-asleep should use `gc session submit` rather than `gc session nudge`. For crew dispatch that currently does `gc mail send + gc session nudge` (documented in sw-agenda), add `gc session submit` as the wake-from-sleep variant — or unify on submit, since submit works whether the session is awake or asleep.

**Validated 2026-04-16** by flipping utz pringle from always → on_demand and confirming:
1. Reconciler does not auto-wake on_demand sessions after suspend (45s observation window).
2. nudge to suspended utz returned `Queued nudge for pringle/utz` but session stayed `asleep`.
3. wake cleared the hold flag but session stayed `asleep`.
4. submit brought session to `active` within 30s.
