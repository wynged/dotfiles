---
name: Use sw- prefix for Eric's custom creations
description: Eric uses sw- prefix (from SirWassail username) on commands, formulas, and artifacts he creates to distinguish his work from pack/system defaults
type: feedback
---

Slash commands, formulas, and other artifacts Eric creates should use the `sw-` prefix.

**Why:** Eric's username is SirWassail; the sw- prefix lets him quickly identify which things are his custom creations vs. pack or system defaults.

**How to apply:** When creating new formulas, slash commands, scripts, or other named artifacts for Eric, prefix them with `sw-`. E.g., `sw-review`, not `review`.
