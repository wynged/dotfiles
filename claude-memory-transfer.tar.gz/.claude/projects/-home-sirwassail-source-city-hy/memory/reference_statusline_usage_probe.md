---
name: reference-statusline-usage-probe
description: "Where the Claude Code statusline's 5h/7d rate-limit data comes from, and how it can silently break across project moves"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 4a380ff6-f53a-4d77-9202-7a80e24c7a74
---

The 5h/7d usage bars in Eric's statusline are NOT fed by the CLI's built-in `rate_limits` JSON. They come from `~/.claude/.usage-tracking/usage.json`, populated by a cron job that scrapes `/usage` from a throwaway headless Claude session.

**Layout:**
- Probe: `~/.claude/usage-probe.sh` (spawns its own tmux on socket `claude-usage-probe`, sends `/usage` to a Haiku session, parses the dialog, writes JSON)
- Cron: `crontab -l` — `7,17,27,37,47,57 * * * *` every 10 min
- Output: `~/.claude/.usage-tracking/usage.json` (keys: `session_5h_pct`, `week_all_pct`, `*_resets`, `updated_at`)
- Log: `~/.claude/.usage-tracking/probe.log`
- Statusline consumer: `~/.claude/statusline-command.sh` lines ~163–181

**Why this is worth remembering:** When the bars look broken (missing, stale, stuck), the first check is `cat ~/.claude/.usage-tracking/usage.json` and look at `updated_at`. If stale, check cron + the probe script path. The system silently broke once before because the cron pointed at a project-local probe (`~/source/hypar_gt/scripts/usage-probe`) that got archived when Eric moved from hypar_gt → city_hy. Living at `~/.claude/` now, so a future project move won't kill it — but a Claude Code CLI change to the `/usage` dialog format would.

**How to apply:** If Eric reports the statusline indicators look wrong/missing, check usage.json's `updated_at` and the probe log before assuming a CLI bug. If a future Claude Code version reformats `/usage`, the awk parser in `usage-probe.sh` (regex matching `Current session`, `Current week`, `% used`, `Resets`) will need updating.
