---
name: Don't default new pools to suspended
description: When adding a new pool agent (forager, prospector, etc.), don't pre-set suspended=true "for safety" — pools sit idle when no beads route to them, and suspended just makes the dispatcher silently no-op
type: feedback
originSessionId: 51f4ff8f-6f51-4e89-9886-157a6d1736d5
---
When introducing a new pool species (`[[agent]]` block with namepool +
scale_check + max_active_sessions), do NOT default to `suspended = true`
as a precaution.

**Why:** A pool with no matching beads sits idle by design — its
scale_check returns 0 demand, no slots spawn. Marking it suspended
adds nothing protective; it just turns the dispatcher skill into a
silent no-op when Eric tries to use it. Eric called this out on the
forager rollout (2026-05-03): "why do we have to leave them
suspended?" — there was no actual reason beyond me being overcautious.

**How to apply:**
- New pool agent.toml files should ship un-suspended unless there's a
  concrete reason (known bug, ongoing incident, half-finished
  formula).
- "First use will be a smoke test" is not a reason — idle slots are
  already a no-op until work arrives.
- This applies symmetrically to `prospector` and `forager`; same
  logic should drive future pools.
- Existing `suspended = true` on a pool you didn't add is different —
  it usually means a real bug or incident. Investigate before
  flipping.
