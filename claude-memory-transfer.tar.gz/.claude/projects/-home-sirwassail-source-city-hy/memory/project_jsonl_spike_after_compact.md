---
name: jsonl-spike-after-compact
description: "JSONL 'spike detected [HIGH]' mails are near-always noise (compaction drops + small-N % swings). ch-l62's abs-delta-100 floor was CLOBBERED by a gc-update; live script now uses a weaker min-prev-count floor (default 10, >=) so tiny dbs like hi (prev=10) slip through. Detector now alerts once-per-spike then advances baseline."
metadata:
  node_type: memory
  type: project
  originSessionId: f56b78e3-2d89-4d88-b6bd-a59c3ae81a05
---

The `jsonl-export` exec order (`.gc/system/packs/maintenance/assets/scripts/jsonl-export.sh`, runs every 15m via `orders/mol-dog-jsonl.toml`) mails "ESCALATION: JSONL spike detected [HIGH]" when a db's scrubbed issue-row count changes >20% vs the last archived commit. Archive repo: `.gc/runtime/packs/maintenance/jsonl-archive`. **Default triage: noise.** Verify by reading that archive's `git log` — `[HALT]` commits are the spikes; clean `exported=N/N` commits before/after mean it self-resolved.

**Two real failure modes, both benign:**
- **Compaction drop** (e.g. `ch` 228→120): beads-row-compact / sw-wisp-compact / compact-dolt-history prune closed beads; record count drops, not active-work loss. A successful 11/11 export at the new (lower) count right after the HALT confirms no data loss.
- **Transient partial dolt read**: a HALT commit reading `exported=3/3` (vs the usual 11) means dolt was mid-restart and only a few dbs were visible — the "drop" is a read artifact; next run recovers.

**The mechanism REGRESSED (2026-05-21, ch-wisp-rjdzt).** My earlier note (ch-l62, 2026-05-14) said the fix was `MIN_ABS_DELTA_FOR_SPIKE` (abs-delta floor of 100: spike requires `Δ>20% AND |Δrows|>=100`). That floor is **GONE from the live script** (`grep MIN_ABS_DELTA` = 0) — a gc-update pulled a newer gascity jsonl-export.sh, exactly the regression the old note warned about. The live script instead has `MIN_PREV_FOR_SPIKE_CHECK` (env `GC_JSONL_MIN_PREV_FOR_SPIKE`, default 10): it **skips** the % check when `PREV_COUNT < floor` using `>=`. So `hi` (hypar-insights docs vault, prev=10) sits exactly on the boundary → check runs → +3 rows = 30% → fires. abs-delta-100 would have silenced it (|Δ|=3); min-prev-10 does not.

**The flooding bug (#1547) IS fixed differently now:** on HALT the script commits the new snapshot (advancing PREV_COUNT) but skips push, and fires the alert exactly once. So each spike = one mail, then baseline moves on. That's why these self-resolve — they are not re-firing every 15m.

**Durable fix is gascity-source-only — verified 2026-05-21 (ch-v9l).** You CANNOT patch this in place: the live `.gc/system/packs/maintenance/assets/scripts/jsonl-export.sh` is materialized from the gc binary and the daemon re-syncs it every 30s (`patrol_interval`), so any edit auto-reverts within the minute (mtime resets to the embedded build time). The env route is also dead: `OrderOverride` schema has NO `env` field (`additionalProperties:false`) and there is no workspace/city-level env map (env only exists for agents/providers), so you can't even bump the existing `GC_JSONL_MIN_PREV_FOR_SPIKE` via city.toml. The city repo `packs/maintenance/scripts/jsonl-export.sh` is a stale ~5KB divergent copy, NOT the materialization source — ignore it. The only durable path: patch the gascity source (`/home/sirwassail/source/gascity` — both `examples/gastown/packs/maintenance/assets/scripts/jsonl-export.sh` AND `cmd/gc/.gc/system/packs/maintenance/assets/scripts/jsonl-export.sh`, keep identical) to AND in `MIN_ABS_DELTA_FOR_SPIKE` (default 100, env `GC_JSONL_MIN_ABS_DELTA_FOR_SPIKE`) with the existing % check, then rebuild + reinstall gc (or it lands on the next gc-update). **Tracked in ch-v9l; DEFERRED by Eric 2026-05-21 to ride the next gc-update — no standalone rebuild.** Re-check ch-v9l at gc-update time so this doesn't get re-clobbered like ch-l62 did.

Related: [[beads-bloat-recipe]], [[bd-hooks-skip-order-tracking]], [[dual-location-packs]], [[gc-upgrade-clobbers-orders]].
