---
name: gc session timeouts and quarantine cascades
description: Default 60s startup_timeout is too tight for cold Claude in a worktree; diagnostic pattern for quarantined sessions
type: reference
originSessionId: b8556ed8-f455-47ec-a857-9894b7cd9ed0
---
**The default `[session] startup_timeout = "60s"` is too tight** for first-wake
of Claude Code inside a rig worktree with a large codebase (e.g. pringle's
1.1 GB hypar checkout). First cold wake needs to index CLAUDE.md, the codebase,
and load a long prompt template. Observed failure: every crew session hits
`outcome=deadline_exceeded duration=1m4.037s` on the first few waves after
`gc stop && gc start`, then after 2–3 consecutive failures the session enters
`asleep quarantine` state.

**city_hy runs `startup_timeout = "120s"`** as of Session 21 (2026-04-13).
This was added to the `[session]` block at the top of `city.toml`. Commit
`a37a7b7` — "Session 21: gc 0.14.1 upgrade fallout".

**Diagnostic flow when sessions won't wake:**

1. `gc session list` — look for `STATE=asleep REASON=quarantine`. Reviewer
   agents showing `REASON=no-wake-reason` are normal (just no work assigned).
2. `tail -100 ~/.gc/supervisor.log | grep "op=start"` — read outcome strings:
   - `outcome=success` — fine
   - `outcome=deadline_exceeded duration=1m4s` — hit `startup_timeout`;
     bump `[session] startup_timeout` OR fix whatever's slow
   - `outcome=provider_error ... err=running pre_start: pre_start[0]: ...` —
     a specific pre_start command failed; look at the script
   - `outcome=provider_error ... signal: killed` — parent context cancelled
     (usually because `gc stop` hit mid-wake)
3. `pgrep -afl claude` — if you see more claude processes than live tmux
   sessions, the reconciler is spawning + timing out + re-spawning. Confirms
   "wake path works but detection races the budget."
4. Manually test: `cd <worktree> && time claude -p 'say hi'` — if this is
   fast, cold-start overhead is the issue; if slow, claude itself is slow.

**Fixing a quarantine cascade:**

1. Fix the root cause (bump timeout, repair pre_start, etc.)
2. `gc session wake <name>` — clears both hold AND quarantine in one shot
   (per `gc session wake --help`). No separate unquarantine command.
3. Wait for the next tick (~30s-4min depending on wake-budget load) and
   re-check `gc session list`.

**Related fields in `[session]` block:**
- `startup_timeout` — total Start() budget (default 60s) — THE knob
- `setup_timeout` — per-command budget for pre_start/session_setup (default 10s)
- `nudge_ready_timeout` — nudge delivery (default 10s)
- `socket` — tmux socket name (default = city workspace name)

**Related memories:** `feedback_full_restart.md` (supervisor restart),
`reference_debugging_gc_daemon.md` (supervisor.log location + halt/resume),
`project_always_on_crew.md` (why crew are named sessions).
