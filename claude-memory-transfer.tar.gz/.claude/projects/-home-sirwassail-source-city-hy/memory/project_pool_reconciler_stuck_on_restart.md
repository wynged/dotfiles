---
name: pool reconciler wedged after hot reload during spawn-fail loop
description: Reconciler stops scale-checking pools after a `gc reload` that coincided with a closed-alias spawn-fail; full city restart doesn't recover it; tracked as bead ch-14z
type: project
originSessionId: 7b8278eb-9d19-4c4b-b939-4e0aa2bd440f
---
When `gc reload` happens while a pool is in a `provider_error: session is closed: ch-...` spawn-fail loop (a closed-alias squat — ch-vg7 family), the supervisor's pool reconciler stops emitting `scaleCheck:` log lines for *most* pools afterward. Only one named-on_demand session (e.g. pringle/funyun) keeps getting reconciled. The wedge survives a full city stop/start.

Live hit on 2026-04-28: bug-sherrif/ant scale_check returned 9 beads, pringle/ant returned 6, zero ants spawning. Trigger was `gc reload` at 2026-04-26 15:45 during a hypar-connection/ant spawn-fail loop. The 04-27 19:49 city restart did not bring scale_check evaluation back.

**Workaround** (not a fix — pools should self-scale):
1. `unset BEADS_DIR; gc supervisor reload` — triggers a one-shot reconciliation that adopts pending session beads.
2. `gc session new <rig>/<pool>` per missing slot — bypasses scale_check, creates an ad-hoc session bead the reconciler picks up.

This drains the queue but doesn't restore the scale_check evaluation loop. Once the bootstrapped ants idle out, queued work will sit again until you re-bootstrap.

**Right fix is upstream gascity** — tracked as `ch-14z` in city_hy beads + agenda Infra. The reconciler should tolerate one pool's spawn errors without dropping the rest from the iteration list, and reload shouldn't wedge pool state.

**How to apply:** If supervisor.log has `provider_error.*session is closed` entries followed by a `Config reloaded` entry, and afterwards `scaleCheck:` is only firing for one pool while real demand exists elsewhere, you've hit this. Workaround above buys time; don't bother adding a startup-bootstrap order — papering over a reconciler bug masks the upstream fix.
