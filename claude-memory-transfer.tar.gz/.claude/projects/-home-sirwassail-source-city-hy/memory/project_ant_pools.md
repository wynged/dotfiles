---
name: Ant pools, cross-rig routing, and investigation tracking
description: Elastic ant workers with cross-rig molecule routing, sw-investigate formula, investigate-record feedback loop — built and tested 2026-04-09
type: project
---

Ant pools are elastic worker agents (0-5 auto-scaling) configured per-rig in city.toml. Cross-rig molecule routing lets a formula poured on one rig dispatch steps to another rig's ant pool.

**Why:** Cricket (bug-sherrif crew) fans out investigation work to ants that may need to run on different rigs (e.g., deep-dive on pringle's codebase for a bug detected via bug-sherrif's triage).

**How to apply:**

### Cross-rig routing (tested end-to-end 2026-04-09)
- `scripts/cross-rig-scale-check.sh <route>` — queries ALL rig beads dirs. Used by both ant pool scale_checks in city.toml.
- `scripts/cross-rig-find-work.sh <route>` — ants call this in step 4 of startup. Returns bead ID + BEADS_DIR for foreign-rig work.
- Beads stay in originating rig's `.beads/` — ants export `BEADS_DIR` to the foreign path for all `bd` commands.
- Both rigs share one Dolt server (port 40014, hosted by pringle). DB names: `bs`, `pr`, `ch`.
- When adding a new rig: update BOTH cross-rig scripts with the new beads path.

### Investigation tracking (new 2026-04-09)
- `triage/bin/investigate-record` on bug-sherrif writes investigation metadata back to `patterns.json`.
- Fields: `investigation.document`, `last_investigated`, `instances_at`, `root_cause_known`, `root_cause_summary`, `fix_status`.
- `investigate-record stale --threshold N` detects patterns needing re-investigation.
- The sw-investigate report step calls this automatically. Even no-change passes reset the staleness clock.
- `patterns.json` is the single source of truth for investigation state — investigation docs are output only, no frontmatter.

### Known gaps
- `missing-subscription-group-id` still not in patterns.json (has an investigation doc but no pattern entry).
- `instances.jsonl` doesn't exist yet on bug-sherrif — instance counting returns 0 until the PostHog ingest pipeline populates it.
