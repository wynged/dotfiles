---
name: forage-kind-metadata
description: Lookout filters forage beads on metadata.kind; sw-forage.sh dispatch now stamps both kind=forage_request and gc.routed_to
metadata: 
  node_type: memory
  type: reference
  originSessionId: ae90f705-2df2-459a-ac32-bc894b6dab3b
---

The forage workflow has two metadata fields that must BOTH be set for a forage-request bead to be visible AND dispatched:

- `metadata.kind` ∈ `{forage_request, pr_feedback, forage_result}` — the lookout dashboard filters its bd-list with `--has-metadata-key kind` and drops anything whose `kind` is not one of these three (`lookout/internal/forage/forage.go:200, classify()`). Without this stamp the bead is invisible in the Forage pane even after routing.
- `metadata.gc.routed_to=<rig>/forager` — what the pool reconciler reads to claim work.

`scripts/sw-forage.sh dispatch` now sets both as of 2026-05-20 (the older version only stamped routed_to, so manually-filed forage-requests stayed invisible in lookout until the worker claimed them — and even then only crossed into "in-flight" via assignee, never via kind).

**Layout note (2026-05-20):** the lookout Forage pane's top-level grouping is by kind (`forage requests`, `pr feedback`, `forage results`), with `pending / in-flight / awaiting` state sub-buckets inside each kind block. Recently closed stays flat at the bottom. Empty kind groups are dropped.

**How to apply:** when manually filing a forage-request bead by hand (not through `sw-forage.sh have-a-forager`), remember to stamp `kind=forage_request` along with `forage_request=ready`. Or just call `sw-forage.sh dispatch <id>` and let it handle both.
