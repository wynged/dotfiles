---
name: Lookout dispatch queue (human-gated)
description: Design locked 2026-05-04 for replacing lookout's auto-fire with a Eric-approved queue panel; foundation pr_feedback flow already wired
type: project
originSessionId: 14fd63e0-a7f8-476a-b28c-8ce8852ff353
---
Lookout currently auto-fires four categories of nudge to worker sessions when state changes (`lookout/internal/dispatch/dispatch.go:204-272` and `:335-346`): closed-without-merge → /sw-cleanup, merge conflicts, failed CI checks, CHANGES_REQUESTED reviews. No approval gate exists or has ever existed — `--dispatch` toggles all-or-nothing in main.go. Eric wants a human-gated queue inside the lookout TUI.

**Why:** Today's session — auto-fire of /sw-cleanup nudges to gleaner for PRs #4789/#4790/#4792 that were closed-by-rename, not abandoned. The nudges are valid in shape but lack context; Eric should see and approve.

**How to apply:** Locked design (Eric's decisions in this session, 2026-05-04):

- Two-pane lookout panel: existing PR state at top (passive), pending dispatch queue below.
- Row per (PR, category): badge / target session / short summary / source link.
- Keystrokes: `j/k` nav, Space select, `f` fire, `x` exclude (= dismiss + permanent suppress for that PR+category), `a` toggle-all, Enter to drill in. **No `e` editor** (Eric: "no").
- Dedup: once-fired-or-excluded stays out; auto-evict on state-invalidates-dispatch (PR reopened, CI passed, etc.); re-add only on state cycle; ~3s footer flash on eviction.
- Batches with confirm-prompt above N=3.
- Exclusions persisted in `~/.lookout/exclusions.json` keyed `(repo, PR#, category)`; auto-expire after PR merges. **Queue itself NOT persisted** — re-emerges on next poll naturally.
- **No cross-PR grouping** (Eric: "don't group"); separate rows per category per PR.
- Auto-approve overrides per-category, default off; `cleanup` after merged PR is the obvious safe candidate.

**Status (as of 2026-05-04):**
- pr_feedback forager flow wired in `packs/forage/prompts/forager.md.tmpl` (replaces v2 stub).
- First end-to-end test in flight: bead `pringle/pr-utsf` (PR #4791 lint fix, max-len at CommandInterfaces.ts:27). Gleaner claimed it as `forager-ch-lkwt`.
- Lookout Go work not yet started — pending validation that pr_feedback flow runs clean.
- Same queue UI also gates the new cicd_fix → forager dispatch (kind=pr_feedback, lookout fires `bd create` on `f`).

**Auto-lint-fix step landed in pr_creation flow** same session — `npm run lint:fix` + `npm run lint:ts` + commit if diff.
