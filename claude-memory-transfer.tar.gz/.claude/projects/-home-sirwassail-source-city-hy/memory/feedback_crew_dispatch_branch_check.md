---
name: Crew dispatch — check branch, not idleness
description: Before assigning new work to a named crew member, check what branch their worktree is on. Idle time is NOT a reliable signal.
type: feedback
originSessionId: 12ad75c9-8472-4551-8928-db9ed8c2e05a
---
Before dispatching new work to a named crew member, check the branch in their worktree — **not** their `LAST ACTIVE` timestamp.

**Why:** Eric's crew frequently "babysit" feature branches while a PR cycles through review — they're mostly idle waiting for feedback, but they own that branch and shouldn't context-switch to new work. Using idleness as the dispatch signal routes work to someone who's just waiting on PR comments, forcing them to drop their PR context. Eric called this out 2026-04-20 after I dispatched pr-416 to bugle based on "29m idle" when bugle was on `feat/visualize-elements-bounding-region`.

**How to apply:**

```bash
for agent in <pringle crew>; do
  wd="/home/sirwassail/source/city_hy/.gc/worktrees/pringle/$agent"
  branch=$(git -C "$wd" branch --show-current 2>/dev/null)
  [ -z "$branch" ] && branch="(detached: $(git -C "$wd" rev-parse --short HEAD))"
  echo "$agent: $branch"
done
```

- **Free for new work**: detached HEAD, `main`, `master`, or auto-generated names like `gc-<agent>-<hash>` (gascity default branch names when no user-owned work is claimed).
- **Babysitting, do not disturb**: named feature/fix branches like `feat/*`, `fix/*`, `refactor/*`, `ai-*`, or any branch that sounds like a PR title. These crew own a PR in flight.

If every crew is on a named branch, tell Eric — don't force-dispatch. He may choose to interrupt a specific crew or defer the task.
