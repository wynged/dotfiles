---
name: project_transcript_rag_content_capture_stopped
description: transcript-rag broke when PostHog moved AI content out of the events table; fix is to query the posthog.ai_events HogQL table
metadata: 
  node_type: memory
  type: project
  originSessionId: 86977d84-3109-40b2-86e7-b8dea5d28334
---

As of ~2026-05-27 `transcript-rag` ingest builds 0 chunks (empty `text`). Root cause is a **PostHog platform change, not the app** (Eric was right; my first two diagnoses were wrong).

PostHog renamed "LLM analytics" → "AI observability" and split AI event storage:
- The standard **`events`** table (what the legacy `/api/projects/:id/events/` REST endpoint AND public HogQL `FROM events` read) now has the large props **stripped** — `properties.$ai_input` etc. are NULL. `ingest.py` reads this → 0 chunks.
- The full content lives in a dedicated HogQL table **`posthog.ai_events`** (namespaced — bare `ai_events` fails with "Unknown table"). 30-day retention (`retention_days` column); content deleted after, metadata persists.

**THE FIX (verified 2026-06-02, works with the existing API key — no new scopes):** query `posthog.ai_events` via `POST /api/projects/:id/query/` with `{"kind":"HogQLQuery"}`. Content is in **dedicated columns, NOT under `properties`**: `input` (json, full message array incl. system prompt + rolling history), `output_choices` (json, the reply), `output`, `input_state`, `output_state`, `tools` (json), plus clean columns `trace_id`, `session_id`, `generation_id`, `model`, `provider`, `*_tokens`, `*_cost_usd`, `latency`, `is_error`, `error`, `event`, `span_type`, `distinct_id`, `timestamp`. Confirmed: pulled the full "Hertsmere planning constraints" conversation from `input`. The old `render_transcript`/`render_gist` renderers can be reused by mapping `input`→`$ai_input`, `output_choices`→`$ai_output_choices` into synthetic event dicts.

Gotchas: (1) **keyset-paginate on `timestamp`** — offset pagination returns HTTP 400 for personal API keys; loop `WHERE timestamp > <cursor> ORDER BY timestamp LIMIT N`. (2) `input` rows are large (40K–450K chars; full rolling history per generation) — select only needed columns, modest LIMITs. (3) PostHog AI help-chat hallucinated the table as bare `ai_events`; the real name came from a `DatabaseSchemaQuery` (also exposes `posthog.trace_spans`, `posthog.trace_attributes`). (4) `/query` is for ad-hoc use, not bulk export — fine for our incremental volume (~6k rows/7d); for >30-day archival use a PostHog **batch export** (API: `/api/environments/:env/batch_exports/` + `…/backfills/`, needs `batch_export:read|write` scopes our key lacks). Related: [[project_transcript_rag_bankruptcy_2026_06_01]].
