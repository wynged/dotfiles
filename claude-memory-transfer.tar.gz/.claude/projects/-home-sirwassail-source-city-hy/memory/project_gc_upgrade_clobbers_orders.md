---
name: gc upgrade clobbers order tunings
description: gc version bumps can silently re-apply upstream defaults to orders/*.toml, undoing local interval/timeout tuning — audit after every upgrade
type: project
originSessionId: f9c4e1bd-8a60-417e-99eb-1e9ccd8f20d9
---
gc upgrades can re-write `orders/*.toml` files back to upstream defaults, silently undoing local tunings.

**Why:** Confirmed 2026-05-01: the gc 1.0.1 upgrade (commit `ca703f7`, 2026-04-25) reset `orders/beads-health.toml` from `interval = "5m"` back to `"30s"`, re-introducing a regular 30s dolt CPU spike. The earlier tuning was commit `b1cf4c6` ("bump beads-health interval from 30s to 5m"). User noticed only days later when symptom resurfaced.

**How to apply:**
- After any `gc-update` / version bump, diff `orders/*.toml` against the previous commit and re-apply any tunings that got reverted.
- When investigating regular-cadence dolt CPU spikes, check `git log` on `orders/*.toml` — a recent gc-upgrade commit modifying interval values is a strong signal.
- Candidates besides beads-health: any order whose interval the user has explicitly tuned. Audit list: compact-dolt-history, gc-dolt-disk, beads-row-compact, dolt-backup-rotate, nightly-bs-sweep.
- Also clobbers `.beads/config.yaml`: 2026-05-07 saw a writer concatenate `types.custom: …` directly onto `backup.enabled: false` (no newline), producing yaml line-8 parse error that broke `bd ready`. Symptom: `bd` warns "yaml: line 8: mapping values are not allowed in this context". Fix is splitting the two keys onto separate lines and restoring trailing newline.
