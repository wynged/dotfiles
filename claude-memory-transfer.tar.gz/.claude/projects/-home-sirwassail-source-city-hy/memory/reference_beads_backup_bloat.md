---
name: Beads backup dir bloat + split-state recovery
description: How to clean up a bloated .beads/backup/ dir and recover when bd and dolt disagree about the backup destination
type: reference
originSessionId: 019d0d6d-c8ff-4118-8be2-cb636cee1359
---
`.beads/backup/` can balloon far beyond the live dolt db (observed 115G vs 4.2G live, and again 7.3G vs 469M on 2026-04-27) because `bd backup sync` accumulates orphaned `nbs_table_*` chunks and stale `.darc` archives that aren't GC'd. The `manifest` file references only the current table set; everything else is garbage.

**Now automated.** `orders/dolt-backup-rotate.toml` + `scripts/dolt-backup-rotate.sh` rotate the backup destination bi-weekly (interval=336h) when `backup_mb > BACKUP_ROTATE_RATIO * live_mb + BACKUP_ROTATE_SLACK_MB` (defaults 3 + 500). The script preserves `closed-issues-*.csv` snapshots that beads-row-compact writes to the same dir. Manual procedure below remains the operator runbook for split-state failures.

**Cleanup procedure (low-space scenario — destructive):**
1. `rm -rf .beads/backup` — safe; real data lives in `.beads/dolt/`
2. `bd backup sync` — will likely fail with "no backup destination configured" even though dolt still has the remote
3. `bd backup init .beads/backup` — will likely fail with "address conflict with a remote: backup_export"
4. Fix the split state: `cd .beads/dolt/<dbname>` (e.g. `ch`) then `dolt backup remove backup_export`
5. Back to repo root: `bd backup init .beads/backup` then `bd backup sync`

**Why the split state happens:** bd's own state (push-state.json etc.) can diverge from dolt's internal backup registry. `bd backup remove` refuses to run when bd thinks nothing is configured, so you have to reach past it with the `dolt` CLI. The dolt backup list lives per-database under `.beads/dolt/<dbname>/`.

**Verify:** `du -sh .beads/backup` should match live db size (~4G), and `bd backup status` should show a recent Dolt Backup sync.
