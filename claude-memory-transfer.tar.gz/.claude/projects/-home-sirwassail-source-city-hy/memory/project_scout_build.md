---
name: Scout-build burst refinery
description: Crew-runnable burst refinery that fans work to scout-builder pool workers and integrates their branches locally — no push to origin
type: project
originSessionId: 5cf6753d-5a04-4293-981e-8ad7ec6575c3
---
**What it is:** `sw-scout-build` is a skill that lets a crew member plan a
multi-change project, fan the work out to a `scout-builder` pool on the
pringle rig, and sequentially integrate each worker's branch into the
crew's feature branch — essentially a bounded, crew-local variant of the
always-on `refinery` agent.

**Why:** Eric wanted a way to dispatch a pool of workers on a large
initiative without spinning up a dedicated always-on refinery, and without
polluting GitHub origin with ephemeral worker branches. The skill + new
worker species + local-only git rendezvous were all built on 2026-04-11.

**How to apply:**
- When Eric (or a crew member) says "plan this out and have workers build it"
  or "fan these changes out", the `sw-scout-build` skill is the answer.
  Invoke via `/sw-scout-build` in a crew session.
- The flow is **local-only**. Scouts never `git push`; their branches live
  as local refs in the shared rig `.git` (scouts run in nested worktrees of
  the rig, so they share the object database and refs with the crew). Do
  NOT suggest adding pushes "for safety" — that's the whole point.
- Sequential rebase + ff-merge is non-negotiable. The watch loop processes
  one merge-ready bead at a time. Don't suggest parallelizing it; that
  reintroduces the conflict problem the sequential-rebase protocol exists
  to solve.
- The new worker species is **`scout`** (camp/ranger theme, short base name
  with purpose suffixes). First variant is `scout-builder`. Future variants
  should follow `scout-<noun>` paired with skills named `sw-scout-<verb>`.
- Ants remain the city-wide anomaly (bug theme). Don't rename them to fit
  the camp theme — they're grandfathered.

**Files:**
- `packs/gastown/formulas/mol-scout-builder.formula.toml` — worker formula,
  extends `mol-polecat-base`
- `packs/gastown/prompts/scout-builder.md.tmpl` — worker prompt
- `city.toml` — `[[agent]] name = "scout-builder"` on pringle,
  max 4 sessions, scale_check via `cross-rig-scale-check.sh pringle/scout-builder`
- `.claude/skills/sw-scout-build/SKILL.md` — skill playbook
- `scripts/sw-scout-build.sh` — helper with verbs `plan | watch | reject | finish`
- Tracking bead: `ch-f7xgx`

**Known bug (2026-04-12):** Pool reconciler spawns dynamic sessions
(`ch-*`) instead of named pool workers (trailblazer, pathfinder, etc.).
Dynamic instances all get `AgentBase=scout-builder` → same `work_dir` →
git worktree collision. Named workers would get unique dirs via namepool
but are never started by the reconciler. Tracked as `ch-mesz0`. Pool is
**suspended** until fixed. Workaround: assign beads directly to a crew
member (cheezeit) for sequential implementation.

**Fragile assumptions to watch for:**
- Scout worktrees must be nested worktrees of the rig (they are today via
  the agent `work_dir` + `worktree-setup.sh` pattern). If a future scout
  pool ever clones the rig into a separate .git, the shared-refs rendezvous
  breaks and would need a different mechanism (local bare repo, etc.).
- Feature branch must be a local-only ref until `finish`. If someone
  manually pushes it mid-burst, that's OK but not required.
- `gc bd --rig` wrapper silently fails `--unset-metadata` for dotted keys
  (`gc.routed_to`). Use `BEADS_DIR=... bd update` directly as workaround.
  Tracked as `ch-fkayx`.
