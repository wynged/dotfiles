---
name: feedback-plain-language-human-facing
description: "Agents must write human-facing output (PRs, mail, reports) in plain language — no obscure jargon/acronyms; common shorthand is fine"
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 89f0fa2a-2852-4874-a14b-8670cc158b32
---

All agents must write **human-facing** output in plain language — no tricky/obscure programmer jargon or insider acronyms. Covers PR titles, PR descriptions, PR comments, mail to Eric, status reports, and learning briefs. **Internal/mechanical text stays terse** (bead titles, commit messages, agent-to-agent nudges).

**Why:** 2026-06-02 Eric flagged pringle PR #4921 — title `fix: FP-tolerant, atomic level elevation/height edits`, body full of `ULP drift` / `sub-nanometre` / `comparators` / `classifier` — as too hard to parse.

**Calibration (important):** the bar is NOT "a non-programmer must understand it." Common shorthand is explicitly fine — Eric named `no-op` and `EPSILON` as OK; also lint/CI/refactor/async. The target is *obscure* terms and acronym pile-ups. Prefer the plain word when the precise one adds nothing ("all-or-nothing" > "atomic"); if a precise term earns its place, gloss it once.

**How to apply / where it's enforced** (committed 24dfcd4):
- `_my_city/crew-operating-procedure.md` — canonical rule (§ "Write So a Human Can Skim It"); reaches 6 of 7 crew via the absolute-path `@`-include in their overlay CLAUDE.md.
- `overlays/crew/.claude/commands/pr.md` + `overlays/crew-hypar-insights/.claude/commands/pr.md` — plain-language title guidance w/ the 4921 before/after + a body "No Obscure Jargon" section. The insights copy is the carrier for that rig (no shared procedure — docs-vault, no CLAUDE.md per [[reference_crew_overlay_rig_claude_clobber]]).
- `prompts/mayor.md`, `prompts/scholar.md`, `prompts/sw-witness.md`, `packs/forage/prompts/forager.md.tmpl` — one line each for their human-facing output.

**Not touched (deliberate):** pool/ant/reviewer/dog worker prompts — their output is internal/mechanical or engineer-to-engineer technical review. Extend there only if Eric asks.

**Propagation note:** active crew worktrees auto-re-staged the new `/pr` ~2 min after the source edit (newer than the old "session-start-only" overlay behavior). Shared procedure is live on next orient via the absolute `@`-include. Only inactive pool/ephemeral worktrees hold stale `/pr` copies; they self-heal on next session start.
