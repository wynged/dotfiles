---
name: Auto-process agenda wisps
description: Mail with subject `agenda [tier]: ...` should be folded into agenda beads on arrival, not flagged
type: feedback
originSessionId: d1e5cff7-95ec-405f-a2c4-8213f4fbb259
---
Wisps sent from the lookout (or agent-to-mayor) with subjects that start
with `agenda [project]:` or `agenda [infra]:` are an explicit routing
signal — the sender wants that content added to the agenda under the
named tier. Read and fold them into beads immediately as part of
handling the startup hook or any prompt that surfaces them.

The agenda is bead-backed (since 2026-05-07). Fold a wisp by creating a
bead with the appropriate label:

```bash
bd create --type=task \
  --labels=agenda-project   # or agenda-infra
  --title="<wisp body title>" \
  --description="<wisp body details, attribution>"
```

Taxonomy note: before 2026-04-22 the tiers included `[bite]` and combined
forms like `[bite · infra]`. Those are gone — treat stale `[bite]` subjects
as Projects when folding.

**Why:** Eric called this out on 2026-04-14 after I left two wisps
(`ch-wisp-2de`, `ch-wisp-dg1`) sitting unread for a full session while
repeatedly flagging them to him instead of acting. The subject pattern
is unambiguous intake — if I had read the mail I'd have seen the body
was self-describing agenda items. Flagging is worse than doing when the
routing is this obvious.

**How to apply:**

1. On startup, if `gc mail inbox` shows unread agenda-prefixed wisps,
   read them with `gc mail read <id>` and `bd create` an agenda bead per
   item (label `agenda-project` or `agenda-infra`) before the first reply
   turn. Optionally also `--add-label agenda-active` if the body indicates
   it's already in flight.
2. A single wisp may contain multiple items ("add X; also add Y") —
   split them into separate agenda beads.
3. Attribute cross-agent wisps in the description (e.g. `Origin: mantis,
   YYYY-MM-DD`).
4. After folding, `gc mail mark-read <id>` to clear the inbox.
5. Mention the additions to the user at the end of the turn so they see
   what landed, but don't ask permission first — the subject pattern is
   the permission.
6. Only ask the user when the wisp is ambiguous (no tier prefix, or body
   that doesn't look like an agenda item).

Explicit user instructions like "don't do anything" apply to the *current
question*, not to orthogonal inbox maintenance. If in doubt, confirm the
scope rather than generalizing "don't do anything" to mean "ignore mail".
