---
name: Forager branches must never leak Gas City internals
description: Forager-produced branch names must use `<tag>/<slug>` (matching /pr's semantic tags), never bead IDs or pool/agent names — these branches become real GitHub PRs
type: feedback
originSessionId: 14fd63e0-a7f8-476a-b28c-8ce8852ff353
---
Forager-produced branches (and any other branch that may eventually become a GitHub PR) must use sensible `<tag>/<slug>` names — e.g. `fix/insert-spaces-grid-offset`, `feat/copy-layout-ai-tool`, `refactor/extract-design-api-helpers`. Never `forage/<bead-id>`, `gleaner/<worker>/...`, or any other Gas City internal artifact. Bead IDs in commit messages are also forbidden — they leak into `git log` of `main` after merge.

**Why:** Session 2026-05-04. The forager pool opened pringle PR #4789 from a branch named `forage/pr-v36m`. Eric called it "ridiculous" and ordered the rename — `pr-v36m` is a Gas City bead ID, meaningless to anyone outside the city, but it ends up in everyone's branch list, code review tooling, and `git log` once merged. PR #4789 closed when the GitHub branch-rename API didn't preserve the PR; replaced by #4791 on `fix/insert-spaces-grid-offset`.

**How to apply:** The rule is baked into `formulas/mol-forager.toml` (workspace-setup leaves the worktree at detached HEAD; implement-and-test step 3 has the worker pick a `<tag>/<slug>` name *after* reading the bead) and `packs/forage/prompts/forager.md.tmpl` (metadata table + mail body example). If a `gc-update` clobbers either file, restore the deferred-naming logic. The same rule applies anywhere a Gas City worker eventually produces a GitHub PR — don't let bead IDs, pool names, or formula names ride along.
