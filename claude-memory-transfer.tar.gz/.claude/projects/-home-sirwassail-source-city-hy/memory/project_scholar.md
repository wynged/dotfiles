---
name: Scholar — daily learning brief
description: City-scoped on-demand research agent; scheduled at 05:30 to mail mayor 3-7 tips on Claude Code / gascity / multi-agent / adjacent topics, filtered against what Eric already knows
type: project
originSessionId: 31f0bb5d-d624-42d3-af9e-57162c2f753e
---
Scholar is a city-scoped on-demand research agent introduced 2026-04-26.

**Files:**
- `agents/scholar/agent.toml` — work_dir `.gc/agents/scholar`, overlay
  `overlays/scholar`, prompt `prompts/scholar.md`, no rig (city-scope).
- `prompts/scholar.md` — research-only persona; no rig, no PRs, output-only.
- `overlays/scholar/{CLAUDE.md, .claude/settings.json, .claude/commands/sw-learning-brief.md}`.
  Settings pre-allows WebSearch + WebFetch + read-only Bash so headless cron
  runs don't prompt for permissions.

**Daily trigger:** `orders/daily-learning-brief.toml` (cron `30 5 * * *`)
runs `gc session submit scholar "/sw-learning-brief"`. Scholar does ~15-25
web searches across Claude Code release notes, Anthropic blog/docs,
gascity changes, multi-agent orchestration patterns. Filters out anything
already in Eric's CLAUDE.md, MEMORY.md, agenda-state.md, or prior briefs.
Ships 3-7 tips to `handoffs/learning-briefs/YYYY-MM-DD.md` and mails mayor
a 3-bullet digest with path to full brief. Stands down after — no idle
loitering, no work-claiming.

**How to apply:**
- Mayor's morning sweep (`/sw-focus`) auto-surfaces the digest via mail-check
  hook. Eric reads it from mayor's inbox or browses `handoffs/learning-briefs/`
  directly.
- Scholar can also be used ad-hoc: `gc session submit scholar "<topic>"` for
  research requests. Reply lands as mail to the requester + optional file in
  `handoffs/research/`.
- First-time dispatch needs `gc session new scholar --alias scholar --no-attach`
  before `submit` works.
- If scholar comes back saying "Unknown command: /sw-learning-brief" after an
  overlay edit, `gc session kill scholar` then resubmit (overlay copy is
  session-start-only).
