---
name: Pringle RL self-improvement loop (mol-pringle-rl-loop)
description: Continuous loop owned by pringle/cheezeit — runs the building-design AI eval each cycle, evaluates artifacts, implements improvements directly on branch, then loops. Formula v4, confirmed cycling autonomously as of Session 18 (2026-04-12).
type: project
originSessionId: 4b0ffc97-aa4c-4f6a-99e5-972e30e03357
---
`mol-pringle-rl-loop` is a patrol-style looping molecule (mirrors `mol-deacon-patrol`) that drives `pringle/cheezeit` through continuous cycles of pringle's "Complete building design from scratch" AI eval. Each cycle:

1. Calls `mcp__hypar-browser__run_cycle` (creates a fresh `DesignOption`, runs the eval against the real cloud Hypar AI, persists `transcript.md` + `floorplan.png` + `result.json` under `/tmp/pringle-rl-loop/<iso-ts>/`).
2. Evaluator (cheezeit) reads the slim transcript + floorplan + structured result and identifies up to N improvements.
3. **Implements each improvement directly on `feat/ai-space-layout-eric`** — no scout-build dispatch. Formula v4 removed the plan-burst/dispatch/watch-burst steps in favor of cheezeit doing it herself.
4. Pours the next iteration; bounded by `cycles_remaining` (-1 = unbounded).

**Why:** Eric wanted a crew member running an RL-style loop that improves pringle's AI design agent automatically — prompt edits, tool add/remove, MCP changes — and commits them directly without human intervention beyond escalations.

**How to apply:**
- **Don't pour additional wisps yourself** — cheezeit pours her own next iteration each cycle. The wisp is linked to `feat/ai-space-layout-eric` via `.bead-projects/`.
- The persistent dev stack (vite + headful Playwright chromium with persistent profile) lives in `.gc/worktrees/pringle/cheezeit` and is managed by `scripts/start-rl-stack.sh start|status|stop|restart|login`. Logs in `/tmp/pringle-rl-stack/`.
- **Vite is pinned to port 8081** with `--strictPort` because Hypar auth cookies are scoped to `localhost:<port>`.
- Hypar login persists in `~/.cache/pringle-rl-loop/chromium-profile`.
- Cycle artifacts are durable on disk in `/tmp/pringle-rl-loop/<iso-ts>/` — never overwritten.
- Formula source: `packs/gastown/formulas/mol-pringle-rl-loop.formula.toml`. Must be symlinked into BOTH `.beads/formulas/` dirs (city_hy and pringle rig) for `bd mol wisp` to resolve it.
- **Symlinks are fragile** — they live in `.beads/` which is dolt-managed. Any db maintenance can delete them. Recreate with: `ln -sf .../packs/gastown/formulas/mol-pringle-rl-loop.formula.toml .beads/formulas/`
- **`bd mol wisp` does NOT set the top-level `formula` field** on the bead. The pour-next step should set `--set-metadata formula=mol-pringle-rl-loop` explicitly. crew.md detects formula wisps via three checks: top-level formula, metadata.formula, title matching `mol-*`.
- **BEADS_DIR**: Wisps live in the pringle rig's beads (`/home/sirwassail/source/pringle/.beads`). Use `BEADS_DIR=...` when querying from city_hy.
- The MCP `run_cycle` tool defaults: `case_name="Complete building design from scratch"`, `new_option=true`. Returns `{cycle_dir, transcript_path, floorplan_path, result_path, exit_status, model_check, option_id, duration_ms}`.
- A 2-4 minute eval is normal.
