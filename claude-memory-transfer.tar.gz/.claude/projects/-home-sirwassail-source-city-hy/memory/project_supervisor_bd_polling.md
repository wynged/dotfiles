---
name: Supervisor's internal bd polling dominates dolt CPU
description: Identified 2026-05-03 — `gc supervisor run` itself fork-execs bd ~40/sec, accounting for ~all of city_hy's 76/s dolt handshake rate after the bd-hook storm fix landed
type: project
originSessionId: 162c3415-8961-4089-b8c0-449a0cf95868
---
**Update 2026-05-03 (later same day):** earlier framing was incomplete.
The 76/s handshake rate + 40/sec supervisor bd-fork rate was the symptom
of a **wedged reconciler**, not steady-state behavior. After
`systemctl --user restart gascity-supervisor.service`, supervisor bd-fork
rate dropped to **0 procs in a 5-second probe** (vs 201 in 5s pre-restart).
dolt 94% → ~30%. So the restart-as-mitigation in `/sw-dolt-check` §3.14
is the right first move; the "no local fix" framing only applies if the
wedge state recurs immediately after restart. Keeping this memory as
the diagnostic narrative — Probe A is still how you confirm it, but
restart-first is the new top of the playbook.

After the bd-hooks skip-block fix (per `project_bd_hooks_skip_order_tracking`)
landed on city_hy, dolt CPU stayed pegged at 80-90% with handshake rate ~76/s
— even with only 2 named sessions and 2 `gc nudge poll` procs running.

**Why (when wedged):** `gc supervisor run` (the systemd-managed daemon)
fork-execs `bd` ~40 times/sec from its own PID, not from session pollers
or hooks. Each bd invocation opens a fresh mysql connection to dolt →
handshake fan-out → auth-bound CPU.

**How to apply:** When dolt CPU is high but session count is low, jump
straight to `/sw-dolt-check` §1.6 Probe A. If the dominant bd parent is
`gc supervisor run`, you've hit Pattern D. Don't waste time on §3.1
session-poller reduction — supervisor itself is the source.

**Caveat that bit us:** the standard bd-tracer wrapper at
`/home/linuxbrew/.linuxbrew/bin/bd` MISSES supervisor traffic — supervisor
invokes the cellar absolute path
`/home/linuxbrew/.linuxbrew/Cellar/beads/<VERSION>/bin/beads` directly.
An empty PATH-symlink-wrapper log under known dolt load is itself the
smoking gun: nothing else is hammering bd. Use the cellar-binary swap
(documented in `/sw-dolt-check` §1.6 Probe B form 2) to enumerate
supervisor's exact subcommands.

**Status:** No local fix. Upstream gascity behavior. Workarounds in
`/sw-dolt-check` §3.12: reduce surface area or file upstream. The bd-hook
storm fix (§3.11) already eliminated the dangerous *spike* behavior;
the residual baseline is annoying but not load-bearing on user latency.
