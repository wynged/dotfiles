---
name: Dolt journal corruption recovery
description: How to recover city_hy's bd dolt store when the chunk journal corrupts — use bd backup restore, not dolt fsck revive
type: reference
originSessionId: d4492d2e-aa27-4f83-8918-c30de252556c
---
**Symptom:** `dolt sql` from a fresh CLI on `.beads/dolt/ch/` errors with
*"possible data loss detected in journal file at offset N: corrupted journal — run 'dolt fsck'"*. The running sql-server may still be working fine because its in-memory state has advanced past the corruption point — restarting it would fail.

**The actual disaster recovery mechanism is `bd backup`, not the journal.** bd auto-syncs to `.beads/backup/` every 15 min via `DOLT_BACKUP('sync')` (in-process dolt client) when a git remote is configured. This is a separate, journal-independent snapshot. Confirm freshness with `bd backup status` — `Last backup: <ts>` should be recent.

**Recovery procedure:**

1. **Take live forensic snapshot first**: `cp -a .beads/dolt /home/sirwassail/backups/city_hy-beads-dolt-<ts>/` while the live server is still up. Don't stop anything yet.

2. **Run `dolt fsck` against the backup copy** (read-only) to identify which sub-databases are corrupted. Usually only `ch` is bad; `bs` / `pr` / `__gc_probe` are clean and should be preserved as-is.

3. **Force a fresh auto-sync**: `bd backup status` and wait for the next tick (interval=15m), or trigger any bd command in city_hy that causes auto-sync to fire. This shrinks the recovery window to a couple of minutes.

4. **Stop the city cleanly:**
   ```
   gc stop                                            # unregister city
   systemctl --user stop gascity-supervisor.service   # supervisor + child dolt die
   ```

5. **Preserve the corrupt dir as forensics — don't delete it:**
   ```
   mv .beads/dolt .beads/dolt.corrupt.<YYYYMMDDTHHMMSS>Z
   ```

6. **Restore via bd, not dolt:** `dolt backup restore` (native) silently leaves `refs/heads/main` pointing at the init commit even though all chunks are copied. Use the bd wrapper:
   ```
   mkdir -p /tmp/bd-restore-<ts> && cd /tmp/bd-restore-<ts>
   bd init
   bd backup restore /home/sirwassail/source/city_hy/.beads/backup --force
   ```
   This produces `.beads/embeddeddolt/<dbname>/` with a working dolt store.

7. **Move into place** — dolt picks up the db name from the directory name:
   ```
   mkdir -p city_hy/.beads/dolt
   cp -a city_hy/.beads/dolt.corrupt.<ts>/{bs,pr,__gc_probe,config.yaml} city_hy/.beads/dolt/
   mv /tmp/bd-restore-<ts>/.beads/embeddeddolt/<dbname> city_hy/.beads/dolt/ch
   ```

8. **Restart:**
   ```
   systemctl --user start gascity-supervisor.service
   gc start
   bd stats   # verify issue count matches expectations
   ```

9. **Purge the corrupt dir from dolt's trash bin once you're confident the restore is healthy.** `dolt drop` and `mv` the old dir into `.dolt_dropped_databases/` — but bytes are NOT reclaimed until you call:
   ```
   dolt --data-dir .beads/dolt --use-db ch sql -q "CALL dolt_purge_dropped_databases();"
   ```
   You MUST scope to a healthy db (`--use-db ch`) because `__gc_probe` errors with "cannot resolve default branch head" and breaks any default-db connection. In Session 19 (4/12) this had been forgotten for ~24h and was hoarding 16 GB of dropped ch + ch.backup.* + __gc_probe. **Never call before you're sure the dropped DBs aren't needed for forensics — it's permanent.** The `mol-dog-phantom-db` formula does this automatically on a 1h cadence, but only when a dog agent exists in the pool.

**Gotchas:**
- **`bd init` in /tmp during recovery picks the wrong backup remote name.** When step 6 runs `bd init` in /tmp, the resulting db has its backup remote named `default` instead of `backup_export`. After moving the new ch into place, the running dolt sql-server keeps `default` in its in-memory remote registry — every subsequent bd command then emits *"address conflict with a remote: 'default' -> file:///.../.beads/backup"* because the auto-backup register tries to add `backup_export` pointing at the same path. On-disk fix in `repo_state.json` does NOT clear the in-memory state — only `gc restart` (which restarts the dolt sql-server) clears it. Filed as ch-hvkm51. Always do a full `gc restart` immediately after step 8 even if the city seems healthy.
- **Never run multiple `dolt backup restore` calls against the same target dir in parallel.** They silently clobber each other and produce a broken result. `bd backup restore` takes ~5–10 min for a 4k-issue / 18 GB backup; pass `timeout: 600000` to Bash so it doesn't auto-background after 2 min.
- **`dolt fsck --revive-journal-with-data-loss` is truncate-at-first-corruption, not splice-and-recover.** For a 1+ GB journal it can lose hours of writes. `bd backup restore` is almost always better.
- **Per-rig backups are stale by default.** bd auto-sync only fires from the project root where bd is invoked. If you're recovering bug-sherrif or pringle, check `.beads/backup/backup_state.json` timestamp first — if it's hours old, the live server's in-memory state is fresher than the backup, and you should force a sync before stopping anything.
- **`repo_state.json` has `branches: {}` even on working databases** — don't be misled by this empty field thinking the restore failed. Test with `dolt sql -q "SELECT COUNT(*) FROM issues"` instead.
- **`du -sh .beads/dolt/*` will lie to you.** The `*` glob skips `.dolt_dropped_databases` and `.dolt`, both of which can be huge. Always also check `du -sh .beads/dolt/.dolt_dropped_databases` — that's where dropped DBs live until purged.

**Related beads:** ch-zjgsf (root cause), ch-fwamd (dolt vs bd restore divergence), ch-t90ou (stale per-rig backups), ch-8tse1 (dolt branch refs internals), ch-hvkm51 (bd init /tmp leaks default remote name), ch-2lmkam (purge step belongs in runbook).
