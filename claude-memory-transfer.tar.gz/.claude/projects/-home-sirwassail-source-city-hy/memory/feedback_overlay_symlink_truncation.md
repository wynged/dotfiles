---
name: Overlay symlinks pointing back to canonical truncate
description: Don't symlink an overlay file back to its canonical destination — the overlay copy will truncate it on every session start
type: feedback
originSessionId: 484efcae-371d-4610-94d1-d859b3eb5586
---
Don't add symlinks under `overlays/<agent>/.claude/commands/X.md` that resolve back to the canonical `.claude/commands/X.md`.

**Why:** Mayor's overlay copies land in the city root (empirically — `sw-focus.md` and `sw-handoff.md` appear at `.claude/commands/` on every session start with the boot timestamp). When the overlay source is a symlink whose resolved target equals the destination, `cp src dst` operates on the same inode and truncates the file to 0 bytes. This burned `sw-agenda.md` (152-line file → 0 bytes, then committed empty in `ca703f7` during the gc 1.0.1 upgrade) and `sw-cd-cleanup.md` (always 0 bytes since add). Commit `b507de8 "fix: repoint mayor sw-agenda symlink to city root"` was a well-meaning attempt that *caused* the recurring wipe — past-Claude assumed the symlink would let one canonical file serve both locations; in reality it became a self-truncating trapdoor on every overlay copy.

**How to apply:** If a command needs to be in both `.claude/commands/` and `overlays/<agent>/.claude/commands/`, keep them as two regular files (overlay copy will overwrite the city-root one with overlay content on every session start, so treat the overlay copy as the source of truth and `.claude/commands/X.md` as generated). If the file should only exist in one place, pick one and don't symlink. Never symlink overlay → canonical when the canonical lives at the overlay copy's destination.
