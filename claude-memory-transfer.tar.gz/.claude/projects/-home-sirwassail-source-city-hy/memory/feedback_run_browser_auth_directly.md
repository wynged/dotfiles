---
name: run-browser-auth-directly
description: "Just run interactive auth commands (aws sso login, gcloud auth login, gh auth login) directly — don't ask Eric to type them. The browser flow is the approval step."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: bae9e8fa-c8ad-4ce3-b147-a7bc1c0e0223
---

When an auth/login command is needed (`aws sso login --profile X`,
`gcloud auth login`, `gh auth login`, etc.), just run it via Bash —
don't ask Eric to type `! aws sso ...` or copy-paste.

**Why:** The command opens a browser where Eric clicks approve. The
typing step is the slow part — the browser approval is the actual
gate. Asking him to type the command adds a round-trip without
adding any safety, because he still has to approve in the browser
either way.

**How to apply:** When the [[sw-morning-routine]] SSO check (or any
similar pre-flight) reports EXPIRED, run the login command directly
in the next Bash call, then re-check, then continue. The browser
will pop up on Eric's machine and he'll approve.
