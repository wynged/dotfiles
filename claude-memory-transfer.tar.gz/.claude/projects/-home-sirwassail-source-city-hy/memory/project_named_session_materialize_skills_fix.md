---
name: named-session-materialize-skills-fix
description: "Resolved 2026-05-12 — gascity templateNameFor now substitutes named_session template name for materialize-skills pre_start, parallel to the pool-instance fix"
metadata: 
  node_type: memory
  type: project
  originSessionId: 5e4dd772-d681-4866-9599-28c3804bd4e9
---

The named_session sibling of upstream commit `cb770047` ("materialize-skills uses template name for pool instances") landed in Eric's local gascity branch `caching-store-no-fetch` on 2026-05-12. Bug beads [[project_named_session_drift_pattern]] (ch-lxko + ch-is5h4) are resolved by this patch.

**Why:** Pool fix used `cfgAgent.PoolName` to detect "this is an instance of a template"; named_session expansion doesn't set PoolName, so the fix never fired and `--agent pringle/<session>` kept hitting `unknown agent`. Now `templateNameFor` also detects the named_session case via `cfgAgent.QualifiedName() != qualifiedName` and returns the template's qualified name (e.g. `pringle/crew`).

**How to apply:**
- If wake fails with `pre_start[1]: exit status 1` again after a future `gc-update`, this fix may have been clobbered — diff `cmd/gc/agent_build_params.go::templateNameFor` against upstream and re-apply.
- The pre_start command's `--agent` value is generated at every reconcile tick from this function, so no bead-stored fingerprint needs clearing after rebuild.
- Files: `cmd/gc/agent_build_params.go` (the fix), `cmd/gc/template_resolve_skills_test.go` (regression test `TestResolveTemplateNamedSessionMaterializeUsesTemplateName`).

**Gotcha during diagnosis:** `bd dolt start` (run before realizing supervisor manages dolt itself) leaves a rogue dolt sql-server holding the `api` database lock; the next supervisor restart loops on "database api is locked by another dolt process" until the rogue is killed.
