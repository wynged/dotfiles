---
name: Dolt remotes — local-only stance
description: Eric does not sync per-rig beads dbs across machines; rig dolt remotes should stay unset to avoid push-failure noise
type: feedback
originSessionId: 4b25c752-16d0-454d-8bba-550992ec6a62
---
Per-rig beads dbs under `.beads/dolt/<rig>/` should have **no `origin` remote** unless Eric explicitly says he syncs that rig from another machine. The `git+https://...` remotes use dolt-over-git transport (not regular git) and constantly retry pushes that fail because the local backup darc chunk gets GC'd before push completes — manifests as hundreds of `Blob not found: <hash>.darc` errors per session and `non-fast-forward` rejections.

**Why:** 2026-04-29 audit found every rig db (`api`, `bs`, `co`, `el`, `hc`, `he`, `hp`, `pr`, `sc`) had `origin` set, and 883× `Blob not found` for `pr` alone. Eric confirmed he doesn't need any rig's beads visible from another machine. Only `bs` (bug-sheriff) was kept as a remote, repointed to the current `hypar-io/bug-sherrif.git` URL (was stale at `wynged/...`).

**How to apply:** When auditing dolt health (§3.5 of `/sw-dolt-check`), if `Blob not found` or `non-fast-forward` errors appear against a rig remote, default to `cd .beads/dolt/<rig> && dolt remote remove origin` rather than trying to heal the push. Only keep a remote where Eric has explicitly named it as needing cross-machine sync. The `ch` city db has never had a remote — that's correct, it's local-only by design.
