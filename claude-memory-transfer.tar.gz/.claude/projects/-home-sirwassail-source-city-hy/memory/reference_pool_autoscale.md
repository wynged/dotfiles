---
name: Pool agent autoscale checklist
description: What city.toml needs for an elastic pool agent (ant, dog, scout-builder) to actually scale up when work is queued
type: reference
originSessionId: 2bf6ba5d-bf2c-42a9-9379-24f8a8cbd8bf
---
A pool agent in `city.toml` needs FOUR things to autoscale on demand. Missing
any one and the pool sits at `min_active_sessions` forever even with work
queued.

1. **`[[agent]]` block** with:
   - `min_active_sessions = 0` (or whatever floor)
   - `max_active_sessions = N` (the cap)
   - `prompt_template = "..."` (must render without errors — check
     `gc supervisor logs | grep "template.*not defined"`)
   - `wake_mode = "fresh"` typically

2. **`namepool = "namepools/foo.txt"`** — required for any pool agent. Without
   it the pool can't allocate unique session names. The file is a plain text
   list of names, one per line. Reuse `namepools/ants.txt` or
   `namepools/dogs.txt` if your pool fits the theme; otherwise create one.

3. **`scale_check = "/abs/path/to/script.sh <route>"`** — script must print a
   non-negative integer to stdout indicating how many slots are wanted. The
   reconciler clamps to `[min, max]`.

   - For **rig-scoped pools** (ant, scout-builder): use
     `scripts/cross-rig-scale-check.sh <rig>/<agent>` — counts ready
     unassigned beads with `metadata.gc.routed_to=<rig>/<agent>` across all
     rig `.beads` dirs.
   - For **city-scoped pools** (dog): use `scripts/city-scale-check.sh <pool>`
     — counts open beads in `city_hy/.beads` with `metadata.gc.routed_to=<pool>`.
   - **CRITICAL: use `bd list`, not `bd ready`.** `bd ready` excludes molecule
     parents (beads with open child tasks), and most formula orders pour
     molecules — the count will be 0 even when work is sitting open.

4. **A correct `WorkQuery` in the prompt template** — the agent's startup
   protocol must query for routed work via `gc.routed_to`, NOT `assignee`.
   The `gc sling` command sets metadata only; pool members race to claim via
   `bd update --claim`. Working pattern (see `prompts/ant-worker.md`):
   ```bash
   bd list --metadata-field gc.routed_to=$GC_TEMPLATE --status=open --json
   ```
   The maintenance pack's dog prompt uses `{{ .WorkQuery }}` which resolves
   to an assignee-based query — it's broken upstream (ch-unjzm7 closed; fix
   committed locally in city_hy).

**Diagnostic flow:**

```bash
gc sling --dry-run dog ch-zbf31g    # Pool: dog (min=0 max=3) → block recognized
./scripts/city-scale-check.sh dog   # should return >0 if work queued
gc supervisor logs | grep "scaleCheck.*dog"  # supervisor sees the count
gc supervisor logs | grep "poolDesired.*dog" # reconciler decides desired
gc session list | grep dog          # actual sessions
gc session peek <dog-id> --lines 30 # what is the dog doing? finding work?
```

If `scaleCheck=N` and `poolDesired=N` but `gc session list` shows none after
~30s, the pool spawn is stuck — usually a prompt template error. Kill the
stuck session beads (`bd close <ids>`) and the reconciler will respawn fresh.
Per project_restart_always_on_sessions.md, sometimes you also need to do a
full `gc restart` to clear cached template state.

**Related:** project_dog_pool.md, project_ant_pools.md, project_scout_build.md.
