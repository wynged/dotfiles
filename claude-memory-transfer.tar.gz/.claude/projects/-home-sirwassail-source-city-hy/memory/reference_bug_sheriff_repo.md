---
name: Bug sheriff repo location
description: Canonical URL for the bug sheriff repo (now org-owned under hypar-io)
type: reference
originSessionId: e7b93702-bc89-406c-a85a-9e8b46990278
---
Bug sheriff repo is at `https://github.com/hypar-io/bug-sherrif.git` (note: "sherrif" spelling in URL).

Ownership moved from Eric's personal account to the `hypar-io` organization. Use this URL for any clone/remote operations referencing bug sheriff.
