---
name: sw-review-2-lens
description: "sw-review pipeline runs 2 lenses (soundness, fit) as of 2026-05-13 — Standards + Restraint + Reuse merged into 'fit' with explicit CSS gating, because AGENTS.md compliance was being silently skipped"
metadata: 
  node_type: memory
  type: project
  originSessionId: f56b78e3-2d89-4d88-b6bd-a59c3ae81a05
---

`/sw-review` dispatches 2 reviewer pool beads, not 3:
- **soundness** (what BREAKS): correctness, impact, consistency.
- **fit** (what doesn't BELONG): standards / restraint / reuse, all
  carrying a `subcategory` tag on each finding.

The 'fit' lens has REQUIRED CSS Compliance output — for every
`.vue`/`.scss`/`.css`/`<style>` block touched, the reviewer must emit
either a `✓ all-compliant` line or a specific finding. Silent
passthrough = incomplete review.

Both lenses read `_distillery/codebase-lessons/pringle.md` index
unconditionally and cherry-pick topic files based on touched paths.
Fit also reads `pringle/AGENTS.md` + any nested AGENTS.md walked up
from each touched dir.

**Why:** Eric flagged 2026-05-13 that the 3-lens setup was excessive
AND reviewers routinely failed to consult AGENTS.md for CSS rules.
Standards + Restraint paired naturally (both rely on AGENTS.md
reading). Code-reuse folded in because all three subcategories share
the "doesn't belong" mindset. Crew now applies fixes directly — no
`/simplify` round-trip; the fit reviewer's analysis IS the fix list.

**How to apply:** when editing `overlays/crew/.claude/commands/sw-review.md`
or `formulas/sw-review.toml`, preserve (a) the codebase-lessons
unconditional read, (b) the CSS Compliance required-output section in
the fit bead, (c) the subcategory tagging on every fit finding.

Canonical record: Lens history comment block in
`formulas/sw-review.toml`. Authoritative dispatch surface is
`overlays/crew/.claude/commands/sw-review.md` (sw-review.md wins if
the two diverge — see formula header).

Related: [[reviewer-directive-not-consult]], [[pr-comment-replies]],
[[overlay-copy-timing]] (changes only take effect on next crew worktree
session-start; current crew don't see edits live).
