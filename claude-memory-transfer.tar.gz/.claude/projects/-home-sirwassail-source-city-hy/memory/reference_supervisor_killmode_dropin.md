---
name: Supervisor KillMode drop-in — REMOVED 2026-04-28
description: Drop-in is gone; default KillMode=control-group restored so restarts cleanly reap tmux + named sessions
type: reference
originSessionId: cd37d85a-20dc-4236-8285-8f0291559fa6
---
**Status (2026-04-28):** Removed at Eric's request. He prefers cleaner, more aggressive restarts where every named session gets reaped and respawned from city.toml. The drop-in at `~/.config/systemd/user/gascity-supervisor.service.d/killmode.conf` is deleted and the parent dir is gone. `systemctl --user show gascity-supervisor.service -p KillMode` reports `KillMode=control-group` (systemd default).

**Implication for `gc restart`:** mayor and every other named session WILL be killed and respawned. Pre-2026-04-28 behavior where mayor/pin/attached sessions rode through restarts no longer applies. Plan accordingly — don't run `gc restart` while you care about preserving an unattached LLM session's conversation state.

**Original context (kept for the why):** Upstream `gastownhall/gascity#1174` — default `KillMode=control-group` causes `systemctl --user restart gascity-supervisor.service` to SIGTERM every tmux server in the supervisor's cgroup. Named/scaled sessions auto-respawn but one-per-bead dev/polecat sessions lose conversation history permanently. The drop-in (`KillMode=process`) was the local mitigation between 2026-04-24 and 2026-04-28.

**Why removed:** the protection was masking a coupling that made restarts non-deterministic — some sessions survived (mayor with `pin`, attached sessions), others got reaped (random named sessions per `feedback_supervisor_restart_session_loss`). Eric judged the predictability of "everything gets reaped, then respawns from config" more valuable than preserving in-flight conversations.

**If you ever want it back:**
```bash
mkdir -p ~/.config/systemd/user/gascity-supervisor.service.d
cat > ~/.config/systemd/user/gascity-supervisor.service.d/killmode.conf <<'EOF'
[Service]
KillMode=process
EOF
systemctl --user daemon-reload
```

**Why a drop-in (not unit edit) if reinstating:** `gc start` regenerates `~/.local/share/systemd/user/gascity-supervisor.service` from a template and clobbers inline edits. Drop-ins under `*.service.d/` survive regeneration.
