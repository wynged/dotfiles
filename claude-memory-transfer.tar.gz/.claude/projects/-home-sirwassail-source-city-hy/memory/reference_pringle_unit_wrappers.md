---
name: Pringle tool-boundary unit conversion
description: Pringle has an existing wrapper pattern that auto-converts AI-tool inputs/outputs between display units and metric, to remove unit arithmetic from the LLM. Reuse for any unit-mismatch bug in aiQuery tools.
type: reference
originSessionId: 05d8fa53-9466-46c0-8b9f-37d8213fe17e
---
`src/components/aiQuery/tools/toolInvocationWrappers.ts` is the canonical
pattern for unit handling in pringle's AI tools. Header comment:

> Converts tool inputs from the user's units to metric before execution, and
> converts outputs from metric back to the project's display units after
> execution. **This removes the need for the LLM to do any unit arithmetic.**

How it works:
- Per-param `unitType` annotation in the JSON schema (e.g. `{ type: 'number', unitType: 'length' }`).
- Each dimensional parameter gets a `{name}_unit` companion field so the LLM specifies units per-param.
- Output units declared via `outputUnits` on the AiTool; converted outputs include a `_units` annotation so the LLM reads back the unit context.
- Backed by `@/units/units` (`BuiltInUnits`, `UnitType`, `UnitSystem`, `conversionFactor`).

When to invoke this pattern: any aiQuery tool that takes or returns
unit-bearing values (length, area, volume, factor tables, thresholds) and
where the assistant could supply a value in either unit system.

Known gap as of 2026-05-05: `create_visualization` was escaping the safety
net (filed pr-zxee on pringle to fix). Other tools (`metricTools.ts`,
`analysisTools.ts`) may have the same gap — worth auditing if a unit-mismatch
bug recurs there.
