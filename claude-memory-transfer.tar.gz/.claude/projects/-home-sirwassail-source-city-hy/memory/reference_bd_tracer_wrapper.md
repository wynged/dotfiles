---
name: bd tracer wrapper for dolt load attribution
description: Symlink-swap technique to log every bd subprocess invocation with parent and args — answers "who is hammering dolt" when SHOW STATUS shows high handshake rate
type: reference
originSessionId: 91873b7f-8e7a-40ae-9b8b-25ece5aa8347
---
When dolt CPU is high and you need to identify which bd-shellout source dominates, a process-level sampler won't work — bd subprocesses are sub-50ms and slip between `pgrep`/`ss` polls. Use a wrapper around the bd binary instead.

**Setup (no city restart required):**

```bash
mkdir -p /tmp/bd-tracer
cat > /tmp/bd-tracer/bd <<'EOF'
#!/bin/bash
{ printf '%s pid=%s ppid=%s parent=[%s] args=[bd %s]\n' \
    "$(date +%s.%N)" "$$" "$PPID" \
    "$(tr '\0' ' ' < /proc/$PPID/cmdline 2>/dev/null | head -c 120)" \
    "$*"; } >> /tmp/bd-invocations.log 2>/dev/null
exec /home/linuxbrew/.linuxbrew/Cellar/beads/<VERSION>/bin/bd "$@"
EOF
chmod +x /tmp/bd-tracer/bd
ln -sfn /tmp/bd-tracer/bd /home/linuxbrew/.linuxbrew/bin/bd
```

**Capture window:** wait 60-120s while the city runs normally.

**Restore (always do this — unmonitored bd calls are slow):**

```bash
ln -sfn ../Cellar/beads/<VERSION>/bin/bd /home/linuxbrew/.linuxbrew/bin/bd
```

**Analysis:**

```bash
# Top parents (who's spawning bd)
awk -F'parent=\\[' '{print $2}' /tmp/bd-invocations.log | awk -F'\\]' '{print $1}' | cut -c-80 | sort | uniq -c | sort -rn | head

# Top subcommands
awk -F'args=\\[bd ' '{print $2}' /tmp/bd-invocations.log | awk '{print $1, $2}' | sort | uniq -c | sort -rn | head
```

**Worked result (city_hy, 2026-05-01):** `gc nudge poll` was 86% of bd traffic (~22 bd shellouts/sec from 5 active sessions × 2s poll interval × ~9 bd calls per iteration). Work_query was only 7%. ch-b9q's batched work_query fix was therefore correct but immaterial — the real load source is the nudge poll loop.

**Caveats:**
- The wrapper adds ~5-10ms latency per bd call — fine for diagnosis, not for steady-state operation.
- Always restore the symlink. Forgetting leaves bd permanently slow.
- The brew Cellar version path can change after `brew upgrade beads`; check `readlink -f` of the original symlink first.
- Not all bd traffic shows up if a caller invokes `/home/linuxbrew/.linuxbrew/Cellar/beads/.../bin/bd` directly. Check `which bd` matches the swapped symlink.
