---
name: reference-suspend-pack-pool
description: "How to suspend a pack-defined pool agent (e.g. pringle/forager) in city_hy — gc agent suspend is blocked, [[patches]] won't reload; edit agents/<name>/agent.toml directly."
metadata: 
  node_type: memory
  type: reference
  originSessionId: 154960be-6f1b-4b8b-adcf-8c38e1023168
---

To suspend a pack-derived pool agent (forager, prospector, ant, reviewer…) in city_hy:

- `gc agent suspend <dir>/<name>` **fails** — "agent is defined by a pack — use [[patches]] to override".
- A `[[patches.agent]]` block in `city.toml` (`dir`, `name`, `suspended = true`) is the documented override, but **`gc reload` / `gc supervisor reload` do NOT apply it** — patches resolve at composition time, not reload. Worse, `gc reload` reports "No config changes detected" even when city.toml genuinely changed — its change-detection is unreliable; don't trust it.
- **What works:** edit the agent's own V2 directory file `agents/<name>/agent.toml` directly — set `max_active_sessions = 0` (caps the pool at zero workers; surest) or `suspended = true`. Then `gc supervisor reload` triggers a reconcile and the supervisor's config-drift watcher re-reads `agents/*/agent.toml` and applies it. The pool then drops out of `gc status` entirely and all its sessions end.
- `gc session kill` alone never stops a pool — the reconciler respawns to meet `poolDesired`, which is multi-source (the forager pool also serves pr_feedback / pr_creation work, not just `forage_request` beads). Cap the pool; don't chase demand by deferring beads.
- Foragers leave orphaned `vite`/`esbuild` dev servers in their worktrees after the session dies — `ps`-grep `worktrees/<rig>/<name>` and kill those too.

Done 2026-05-17 to stop the forager pool churning in the [[project-fpextra-drift-persists]] drain loop (tracked as bead ch-6tif). Reverse: restore `max_active_sessions = 3`.
