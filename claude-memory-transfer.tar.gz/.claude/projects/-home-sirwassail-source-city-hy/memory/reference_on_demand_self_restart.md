---
name: On-demand named sessions can't self-restart while attached
description: gc runtime request-restart refuses on-demand named sessions attached via tmux; cycle paths and why the old handoff flow broke
type: reference
originSessionId: 1b2fd6e8-23b9-4125-a907-ac036014bd28
---
`gc runtime request-restart` refuses on-demand named sessions when the user is attached via tmux: "Restart skipped for named session; controller cannot restart on-demand named sessions." The controller's user-attended-process guard blocks the kill.

Cycle paths that work:
- From the attached pane: `Ctrl+D` twice or `/exit` → session goes idle → next submit wakes fresh (wake_mode: fresh gives clean conversation, handoff mail is read on startup).
- From another shell: `gc session kill <name>` — terminates the runtime, same effect on next message.

Why this matters: the old always_on handoff flow relied on the agent itself calling request-restart after filing handoff mail. With on_demand named crew, that path is a silent no-op while the user is attached, so handoff mail gets filed but the conversation never cycles unless the user takes manual action.

**Resolution (2026-04-29, ch-wn2w)**: `/sw-handoff` now calls `"$GC_CITY/lookout/lookout" handoff "$GC_SESSION_NAME"` after `gc handoff`. That subcommand schedules a deferred `gc session reset` (5s default) so the agent's final response renders before the cycle. See also `reference_session_kill_vs_reset.md` — reset, not kill, is the right verb for on_demand cycling.

First observed 2026-04-29 in cheezeit during a handoff attempt; pr-60b9.5 session note.
