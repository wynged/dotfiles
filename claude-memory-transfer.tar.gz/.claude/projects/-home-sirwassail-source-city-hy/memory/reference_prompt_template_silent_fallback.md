---
name: Prompt template silent raw-fallback
description: When a .md.tmpl references an undefined named template, gascity's renderPrompt logs to stderr and ships the raw body — partials AND .Var references appear unrendered in the agent's first message
type: reference
originSessionId: 659882b9-5ce8-4812-a444-cad71f938cf0
---
If an agent's first message arrives with literal `{{ ... }}` (both `{{ template "X" . }}` AND `{{ .AgentName }}` style), the cause is almost always a missing named-template reference. `gascity/cmd/gc/prompt.go:renderPrompt` catches `tmpl.Execute` errors and falls back to `Text: body` (the raw, unrendered template) — silently from the agent's POV; only `gc:` stderr lines reveal it.

Diagnosis: `unset BEADS_DIR && gc prime <rig>/<agent>` reproduces and prints the offending undefined-template name.

Loading order for partials (`renderPrompt`, `prompt.go:102-122`):
1. Each `cfg.PackDirs[i]/prompts/shared/` and `cfg.PackDirs[i]/template-fragments/`
2. Sibling `<prompt-dir>/shared/` (highest priority)
3. `agents/<name>/template-fragments/` (per-agent)

A pack whose templates reference cross-pack partials only works if that pack OR a pack defining the partials is in `cfg.PackDirs`. `gc config show | grep includes` shows the resolved list. Note: rig-level `includes` populate `RigPackDirs[rig]`, NOT `cfg.PackDirs` — agent prompt-render uses city-level only.

Fix patterns:
- Inline copies in sibling `shared/` (isolates the pack; no other coupling)
- Add the missing pack to city.toml imports (couples everything globally)
- Trim the prompt to only reference always-available partials
