---
name: Named-session drift pattern (live tmux, dead bead)
description: Pringle crew on_demand sessions repeatedly land in state=stopped sleep_reason=suspended with orphan tmux session — root cause is upstream gc, mitigation is mode=always
type: project
originSessionId: 68689cf9-e5b3-433a-b118-7bea01910a2a
---
Recurring pattern in city_hy: a pringle crew session (frito, cheezeit, etc.) ends up with bead `state=stopped, sleep_reason=suspended` while the tmux session is still alive on the `city_hy` socket and Eric is sometimes attached to the pane. /sw-handoff fails on these because:

- Reconciler skips suspended/stopped beads (`namedDesired ... decision=skip reason=no-canonical-no-work bead= state=`), so `restart_requested` is written but never observed.
- `gc session wake` only flips `StateSuspended → StateActive` (waits.go:185); it doesn't recognize the `state=stopped, sleep_reason=suspended` shape, so the wake CLI silently no-ops.
- The wake-msg from `gc session submit` lands in the still-attached old runtime as a nudge — same context, no cycle.

The reliable heal is `gc session close <alias>` — kills tmux, closes the bead, clears `session_name` automatically. Then `gc session submit <alias>` spawns a fresh bead.

**Likely originating triggers:**
- Hot supervisor restart / `gc stop`-`start` cycle reaps the bead but tmux server survives (per memory `feedback_supervisor_restart_session_loss.md`).
- `gc session kill` leaves bead suspended but tmux alive (per memory `reference_session_kill_vs_reset.md`).
- Each transition adds another chance to land in a divergent state; on_demand sessions cycle more, so they accumulate more chances.

**Side-effect noise:** supervisor's `healState` / session-beads layer keeps stale references to closed beads in memory and tries to set metadata on them every reconciler tick, logging `bead not found` (saw ch-9lu4, ch-c47d, ch-6hqq spam in supervisor.log 2026-05-07). Real upstream bug — `healState` should drop closed beads from its working set. Cleared on supervisor restart.

**Why:** Multiple upstream gc bugs converge to make on_demand crew drift-prone. None of them are config issues — `wake_mode` (fresh vs resume) is unrelated; it controls claude conversation continuity, not bead lifecycle.

**How to apply:** When troubleshooting "why is crew session X going to sleep / not waking / handoff broken," first check for this divergence pattern (`bd show <session-bead>` for `state=stopped` + `sleep_reason=suspended`, then `tmux -L city_hy ls` for orphan). Heal with `gc session close <alias>`. Long-term mitigation in city_hy 2026-05-07: pringle crew flipped to `mode = "always"` so the reconciler maintains them continuously and they never drift to suspended.
