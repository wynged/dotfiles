---
name: Stale session_name claim recovery
description: When `gc session submit X` errors with "session name already exists: Y already belongs to ch-NNNN", clear the closed bead's session_name metadata to free the tmux-name claim
type: reference
originSessionId: f2ab09d1-6211-465b-84fb-783e3b29ad5f
---
When `gc session submit pringle/<name>` (or any rig/name) errors with:

```
gc session submit: resolving configured named session "pringle/<name>": session name already exists: "pringle--<name>" already belongs to ch-NNNN
```

…the named session is bogged because a *closed* bead `ch-NNNN` still claims the tmux name in its `session_name` metadata. gc's name resolver consults closed beads with `session_name` set, not just live ones. City restart does NOT clear these — they live in dolt.

**Fix:** clear the metadata on the closed bead.

```bash
bd update ch-NNNN --set-metadata "session_name="
gc session submit <alias> <message>   # now spawns fresh
```

**Bulk find** (closed sessions whose names look like rig--agent, not ant-pool ids):

```bash
bd list --type=session --status=closed --json > /tmp/cs.json
python3 -c '
import json
text = open("/tmp/cs.json").read()
objs = []
dec = json.JSONDecoder(strict=False)
i = 0
while i < len(text):
    while i < len(text) and text[i].isspace(): i+=1
    if i >= len(text): break
    obj, end = dec.raw_decode(text, i)
    objs.extend(obj if isinstance(obj, list) else [obj])
    i = end
for b in objs:
    sn = b.get("metadata",{}).get("session_name","")
    if "--" in sn:
        print(b["id"], sn, b["metadata"].get("state",""))
'
```

Common closed-state values that leave the claim active: `gc_swept`, `stale-session`, `suspended`, `failed-create`. All produce the same wake bog.

This is upstream gc — file alongside ch-14z (pool reconciler wedge) when reporting. Until fixed, expect the bog to recur every time a named session is swept (idle timeout, restart, etc.).
