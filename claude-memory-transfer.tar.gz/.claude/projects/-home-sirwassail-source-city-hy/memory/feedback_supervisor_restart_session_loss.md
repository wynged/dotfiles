---
name: Hot supervisor restart preserves only some sessions
description: gc stop + supervisor stop/start keeps tmux server alive but reaps a portion of sessions; not a clean hot-swap
type: feedback
originSessionId: 62764772-2d8c-40e7-a45b-08421b27c24c
---
`gc stop` followed by `gc supervisor stop` does NOT preserve all running tmux sessions. Observed in city_hy 2026-04-27 during the cache-reconciler binary swap: started with ~10 named sessions, ended with 6 surviving. Survivors kept their original creation timestamps (so the tmux processes themselves persisted across the restart), but several sessions disappeared during `gc stop`'s reconciliation sweep before the supervisor itself shut down.

**Why:** `gc stop` triggers reconciliation that sweeps sessions it can't account for; some get reaped before the supervisor exits. The KillMode drop-in keeps the tmux *server* alive across systemd-driven restarts, but does not protect individual sessions from the unregister-time sweep.

**How to apply:** Don't promise a "swap without disturbing agents" when restarting the supervisor. Frame it as: "tmux server stays up, dolt stays up, but expect some named sessions to reap and respawn." If preserving a *specific* in-flight agent matters (e.g., it's mid-task on a feature branch), confirm with the user before restart, or consider whether the change can wait for a natural quiet point.
