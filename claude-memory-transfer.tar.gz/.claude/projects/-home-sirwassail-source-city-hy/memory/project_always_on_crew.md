---
name: crew-sessions-are-on-demand-with-no-idle-timeout
description: All named crew sessions are mode=on_demand; crew-* agent templates have idle_timeout removed so they never auto-suspend
metadata: 
  node_type: memory
  type: project
  originSessionId: 3e219aa7-7f5e-422e-85fe-7577b7f9f641
---

Every `[[named_session]]` for crew in `city.toml` runs `mode = "on_demand"`. Only `mayor` is `mode = "always"`. Eric does **not** want crew flipped to `always`.

To prevent on_demand crew from being drained mid-use by the supervisor's idle reconciler, all `crew-*` agent.toml templates have `idle_timeout` **removed** (per gascity schema: empty = idle checking disabled). As of 2026-05-28 this covers: `crew`, `crew-bs`, `crew-corp`, `crew-classroom`, `crew-hypar-insights`. (`crew-api` and `crew-hypar-project` never had one.)

**Why:** Eric was actively using `ruffle` (pringle/crew) when the 4h idle reconciler drained it overnight. The reconciler measures bead activity (`assignedWorkBeads`), not tmux keystrokes — so crew that aren't actively claiming a bead look idle. Combined with `wake_mode = "fresh"`, a drain wipes the conversation. Eric wants crew to stay until *he* closes them.

**How to apply:**
- New crew templates: omit `idle_timeout` entirely.
- New `[[named_session]]` for crew: `mode = "on_demand"`, never `"always"`.
- Don't reintroduce `idle_timeout = "4h"` on `crew-*` templates without checking with Eric — gc upgrades may try to re-add it (see [[project_gc_upgrade_clobbers_orders]]).
- Earlier note claiming "all crew are mode=always" was wrong; only `mayor` is.
