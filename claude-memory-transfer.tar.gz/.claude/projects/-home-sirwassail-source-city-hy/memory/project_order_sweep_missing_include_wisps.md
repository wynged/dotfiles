---
name: order-sweep-missing-include-wisps
description: "order-tracking-sweep runs without --include-wisps, so molecules with open wisp children never auto-close; orders blocked indefinitely"
metadata: 
  node_type: memory
  type: project
  originSessionId: 22dc0614-192a-46a4-b70b-6cadfd95f64d
---

2026-05-28: `mol-dog-backup` and `mol-dog-phantom-db` had not auto-fired in ~31 days. Root cause: tracking molecules from 2026-04-26/27 (ch-2oa, ch-5kqw) stayed `open` because their step children are wisp subtrees, and the auto-sweep order ships as:

  Exec: gc order sweep-tracking --stale-after 10m --quiet

Missing `--include-wisps`, so `sweep-tracking` cannot close the molecule even after 31 days. Scheduler reads "elapsed" off the oldest open tracking molecule for the order → permanently shows huge elapsed but never re-fires (treats it as "in flight").

**Why:** dog-pool exec orders produce molecule+wisp tracking shapes; the default sweep flags only handle plain orphans.

**How to apply:** when an exec order silently stops auto-firing, run `gc order check` — if `elapsed` > interval but it never fires, look for `bd list --label order-run:<order>` open molecules. Fix one-shot:

  gc order sweep-tracking --include-wisps <order...>

Lasting fix: edit `.gc/system/packs/maintenance/orders/order-tracking-sweep.toml` to add `--include-wisps`. WILL be clobbered by gc-update (see [[gc_upgrade_clobbers_orders]]). File upstream too.

Related: [[bd_hooks_skip_order_tracking]] is separate — that's bead.closed event noise suppression; this is about molecules never reaching closed state at all.
