---
name: Mayor hands off owned work
description: Don't propose committing or closing in-flight changes that another agent may own; coordinate or stand down
type: feedback
originSessionId: 33b629a4-4f87-446a-90d9-7a5079e38283
---
Mayor's role is dispatch and coordination — not grabbing in-flight work. When the mayor session sees uncommitted changes or in-progress beads, do NOT suggest committing, closing, or otherwise advancing them by default. Other crew (or another mayor session) may be mid-flight.

**Why:** On 2026-04-27, mayor opened with a focus report that proposed committing the lookout WIP (ch-nww: dashboard.go + main.go + new mayor slash commands + city.toml restructure) and asked about closing the phantom-cascade work. Both were being driven by other agents. Eric pushed back: "Don't commit the lookout work in progress another agent is working on that ... I assume that the phantom cascade fix is still being worked on you don't need to worry about it."

**How to apply:**
- When in-flight changes appear in `git status` from the mayor seat, treat them as "in someone else's hands" until proven otherwise. Mention them as situational awareness, but do NOT offer to commit them.
- If a fix landed in recent commits and there are still open related beads, assume work is ongoing — don't push to close.
- Large config restructures (e.g. city.toml stripping back to bare-bones because settings migrated to per-rig/per-agent tomls) are deliberate ongoing work; verify the safety values made the migration but don't second-guess the shape.
- If unsure, ask Eric who owns it before acting.
