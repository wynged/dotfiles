---
name: PR #416 closed; #531 replaces for named-session wake
description: Eric's wake-asleep-sessions PR was closed as wrong direction, but PR #531 covers the valid part (named-session on-demand) — rig-like pool case was intentionally excluded
type: project
originSessionId: b8556ed8-f455-47ec-a857-9894b7cd9ed0
---
**Context.** Eric opened gascity PR #416 (`fix: wake asleep sessions when work_query detects routed work`) on branch `fix/workset-wake-asleep-sessions`. It added `collectAsleepBeads` as a third fallback in the `WorkSet` handler so `gc sling` routing could wake asleep sessions. Closed 2026-04-13 by julianknutsen.

**Why closed.** From his comment: *"The current wake contract is narrower than the PR assumes: work_query remains a demand signal for routed work and for on-demand named sessions, but asleep pooled or template sessions are intentionally not reused for new generic demand. That behavior is already encoded in TestScaled_Demand2_OneActive and TestSelectOrCreatePoolSessionBead_SkipsAsleepBeads."*

Translation: the patch was right for **named on-demand** sessions (reviewer-alpha/beta/gamma) but wrong for **pool/template** sessions. Pool agents asleep due to drain-back-to-min are intentionally not revived — new demand should spawn new pool slots, not reuse drained ones.

**What replaced it.** gascity PR #531 (merged, by rileywhite) restructured `build_desired_state.go` to remove the `continue` at ~line 198 that was skipping named-session agents from demand evaluation. After #531, the named-session `on_demand` case in `compute_awake_set.go` runs three signals in priority:
1. `hasAssignedWork` → `named-on-demand:assignee`
2. `WorkSet[ns.Template]` → `named-on-demand:work-query`
3. `ScaleCheckCounts[ns.Template] > 0` → `named-on-demand:scale-check`

For each, the code tolerates asleep bead state — only `Drained` and `DependencyOnly` block wake. So asleep on-demand named sessions CAN wake via any of those three signals in gc ≥ v0.14.1.

**Why this applies to Eric's reviewer agents.** `reviewer-alpha`, `reviewer-beta`, `reviewer-gamma` in `city.toml` are named-session agents with `max_active_sessions=1`, no `work_query`, no `scale_check`. Their viable wake path is signal #1 — `hasAssignedWork` via bead assignee. A caller that sets `assignee=reviewer-alpha` on an open bead will wake the sleeping session on the next tick.

**Caveat for Eric's dispatch style.** Memory `feedback_named_agent_dispatch.md` says Eric uses mail+nudge /focus for named agents, NOT `gc sling` with routing metadata, because routing metadata caused perpetual nudges. So the wake path through assignee/work-query may still not be exercised in his actual dispatch flow. The #531 fix unblocks the mechanism but doesn't change Eric's working pattern unless he decides to start using sling for reviewer agents.

**Resolution 2026-04-14 — pool conversion.** After a sw-review cycle hit the wake-asleep failure mode in practice, Eric converted reviewer-alpha/beta/gamma into a single `reviewer` pool agent (`pringle/reviewer`, max=6, min=0, `namepools/reviewers.txt` with critic/judge/juror/…) mirroring the scout-builder/ant pattern. `scripts/cross-rig-scale-check.sh pringle/reviewer` counts unassigned beads tagged `gc.routed_to=pringle/reviewer`; gc spawns fresh pool slots up to max. `/sw-review` no longer slings or wakes — it just creates 3 beads with pool metadata + `gc.reviewer_pool=pending` and lets autoscale take over. Workers flip `pending → claimed` as a human-visible breadcrumb (real atomic claim is `--assignee`). This sidesteps the wake-asleep issue entirely because new demand always spawns fresh slots. Files touched: `city.toml` (3 blocks → 1), `namepools/reviewers.txt` (new, 10 names), `prompts/sw-reviewer.md`, `overlays/crew/.claude/commands/sw-review.md`, `formulas/sw-review.formula.toml` (header).

**Verification procedure (not run 2026-04-13 — defer until needed):**
```bash
# 1. Confirm reviewer-alpha session is asleep
gc session list | grep reviewer-alpha    # expect "stopped" or missing

# 2. Create a test bead assigned to reviewer-alpha in pringle's store
BEADS_DIR=/home/sirwassail/source/pringle/.beads bd create \
  --title="wake test" --description="verify #531" --type=task --priority=4 \
  --assignee=reviewer-alpha

# 3. Wait a tick (5-15s) and check for wake
gc session list | grep reviewer-alpha    # expect "running" with reason "named-on-demand:assignee"
tail -f ~/.gc/supervisor.log | grep reviewer-alpha

# 4. Close the test bead
BEADS_DIR=/home/sirwassail/source/pringle/.beads bd close <id> --reason="wake test"
```

If this works, it confirms #531 closed the gap Eric's #416 targeted for the named-session case. If not, investigate `ComputeAwakeSet` named-session path in the new code.

**Related:** `feedback_named_agent_dispatch.md` (why routing metadata is not used for crew/reviewers), `project_always_on_crew.md` (crew session policy).
