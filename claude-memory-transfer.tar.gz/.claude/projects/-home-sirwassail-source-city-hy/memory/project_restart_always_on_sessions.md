---
name: Restarting always-on named sessions
description: Use gc session wake / reset as the first-class path; direct bd metadata edits are last-resort only
type: project
originSessionId: 06eca32f-bfe4-4fe4-84cd-dc987567ef6b
---
Always-on named sessions (`mode = "always"` in `[[named_session]]`) resist being closed or restarted via `gc session close`. Gas City has first-class commands for every common case — reach for those before touching bead metadata.

**After a controller/supervisor restart, asleep sessions need waking:**
```bash
gc session wake <alias>     # e.g. gc session wake pringle/frito
```
Clears user hold and crash-loop quarantine. Reconciler starts the session on its next tick if it has wake reasons (config agent match). This is the correct path after `gc stop` / supervisor bounce / binary upgrade.

**Clean fresh-restart of a live session:**
```bash
gc session reset <alias>
```
Stops runtime and starts fresh with a new conversation. Preserves bead, alias, mail, queued work.

**Last-resort only (do NOT use by default):**
```bash
unset BEADS_DIR
gc session kill <id>
bd update <id> --set-metadata state=awake
```
Why: bypasses the state machine, skips hooks, and misses quarantine clears. Only use for zombie sessions that don't respond to `wake`/`reset`/`kill`, and update this note if you find a case where it's genuinely needed.

**What doesn't work:**
- `gc session close <id>` on an always-on — blocked: "configured always-on named sessions cannot be closed while config-managed"
- `gc session new <template>` — creates a *separate* manual session, not a replacement

**Why:** *Why:* Eric called out (Session 22) that directly mutating `state=awake` via `bd update` is too aggressive — session state is gc's job, not ours. *How to apply:* Default to `gc session wake` after restarts and `gc session reset` for clean restarts. Only fall through to kill + metadata edit if both have been tried and the session is stuck.
