---
name: Scheduled-agent dispatch pattern
description: For cron-style work that needs LLM judgment, the standard shape is thin cron order → gc session submit → slash command in overlay → mail mayor + handoff file
type: feedback
originSessionId: 31f0bb5d-d624-42d3-af9e-57162c2f753e
---
When a periodic task needs LLM judgment (research, triage, planning, multi-phase
work), build it as a "scheduled-agent loop" — three pieces:

1. **Thin cron order** in `orders/<name>.toml`:
   ```toml
   [order]
   trigger = "cron"
   schedule = "0 0 * * *"   # 5-field, minute-grain
   exec = "bash -lc 'unset BEADS_DIR; gc session submit <agent> \"/<slash>\"'"
   timeout = "60s"
   ```
2. **Agent template** under `agents/<agent>/agent.toml` (city-scoped or rig-scoped),
   with `overlay_dir` pointing at an overlay containing the slash command.
3. **Slash command** at `overlays/<overlay>/.claude/commands/<slash>.md` carrying
   the multi-phase prompt. Agent runs it, mails mayor a digest, writes the durable
   artifact to `handoffs/<topic>/YYYY-MM-DD.md`.

**Why:** Eric's morning sweep with mayor (`/sw-focus`) reads mayor's mail inbox.
Mail-check hook auto-injects unread mail into mayor's next prompt. So digests
landing as mail to mayor surface in his morning report without extra plumbing.
The handoff file is the durable artifact for browsing.

**How to apply:**
- New "every night/morning, do X" jobs go through this pattern. Don't reach for
  `claude -p` headless — sessions get the full overlay (skills, settings,
  CLAUDE.md, memory) and use Eric's existing Anthropic auth.
- Two live instances as of 2026-04-26: `nightly-bs-sweep` (cricket / 00:00) and
  `daily-learning-brief` (scholar / 05:30). Copy their shape.
- First-time dispatch on a new on-demand agent needs
  `gc session new <template> --alias <name> --no-attach` before `submit` works.
- The order won't fire when the controller is stopped — by design.
