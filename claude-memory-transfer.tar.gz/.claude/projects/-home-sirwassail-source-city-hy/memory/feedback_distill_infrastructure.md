---
name: Distill should consider infrastructure changes
description: When distilling, proposals should include broader city infrastructure (formulas, pr-watch script, hooks) not just prompt/CLAUDE.md edits
type: feedback
---

When synthesizing distill proposals, don't limit proposals to prompt and CLAUDE.md edits.
Consider whether the signal is better addressed by:
- A formula (automated workflow template)
- Modifying the pr-watch script
- Adding a hook (pre-PR, post-push, etc.)
- Other city infrastructure changes

**Why:** Eric noted that "merge from main" being repeated is the kind of thing
pr-watch should handle, not just a prompt rule. Broader infrastructure proposals
are more valuable than adding more text to prompts.

**How to apply:** During Step 3 (synthesis), for each theme ask: "Is a prompt
rule the right layer, or would a script/hook/formula be more effective?"
