---
name: Beads dolt bloat — cause and recipe
description: Session heartbeat churn creates 100K+ dolt commits; bd compact --days 0 + dolt gc --full is the fix
type: project
originSessionId: 0497d61a-d36f-4992-ac06-612922ddee07
---
**Cause.** Session beads (one per agent) get a full-payload `bead.updated` write every ~30-45s from heartbeat/state toggles (asleep↔awake). Top offender observed: ch-9sv (pringle/utz) with 21,581 updates in ~12 days. Each write carries the full metadata block (config_hash, live_hash, instance_token, etc.), and dolt's auto-commit turns each one into its own commit. In city_hy this reached **100,480 commits / 4.1G noms** (3.5G in a single oldgen darc) in ~2 weeks.

**Symptoms.** `.beads/dolt/ch/.dolt/noms/` balloons to multi-GB. `.beads/backup/` mirrors it 1:1 (same darc hashes). `.gc/events.jsonl` also grows (~1,800 events/hour sustained).

**Why `dolt gc --full` alone OOMs.** With ~100K commits, the reachable chunk set is large enough that `dolt gc --full` on a 31G RAM box exhausts memory and starts thrashing swap. You need to shrink the reachable set *first*.

**Recipe (safe, repeatable).**
1. Stop gc city (`gc halt` or ensure no dolt processes). Verify with `pgrep -af dolt` empty.
2. `cp -a .beads .beads.safety-$(date +%Y%m%d-%H%M)` — 40s, reversible undo.
3. `bd compact --dry-run` — see commit count. If all recent, use aggressive `--days`.
4. `bd compact --days 0 --force` — squash 100% into 1 commit (452ms). This doesn't reclaim space yet; it just makes old chunks unreachable.
5. `cd .beads/dolt/ch && dolt gc --full` — now safe; reachable set is 1 commit. Took 33s and reclaimed 4.1G→517M.
6. `bd dolt stop` — the auto-started sql-server holds ~12G cache after gc; stopping releases it.
7. `bd backup remove` + `rm -rf .beads/backup` — the file-based backup dir won't shrink from sync (content-addressed, same root). Remove config and delete dir; beads auto-creates a new backup via git remote.

**Key gotcha.** Default `bd compact` uses `--days 30` and squashes zero commits because all churn is recent. Must pass aggressive `--days 0` or `--days 1`.

**Why:** session bead heartbeats write-amplify dolt storage at ~1,800 events/hour in a busy city; without periodic compaction the db grows unbounded because dolt auto-gc only touches new-gen, not oldgen where bloat accumulates.

**How to apply:** Run this recipe when `.beads/` exceeds ~2G. Better: schedule `bd compact --days 7 --force` via a dog formula so it never gets here. (See the follow-up dog/formula investigation for the going-forward plan.)

**Scheduled coverage (as of 2026-04-27).** Three city orders maintain dolt-side health while the city is up:
- `orders/compact-dolt-history.toml` (2h) — `bd compact --days 0 --force` once commit count ≥ 3000.
- `orders/gc-dolt-disk.toml` (6h) — `CALL DOLT_GC()` per DB; auto picks shallow vs full by row/disk gates.
- `orders/beads-row-compact.toml` (6h) — prunes closed non-epic issues + heartbeat events.
- `orders/dolt-backup-rotate.toml` (336h / bi-weekly, added 2026-04-27 ch-p41) — rotates `.beads/backup/` when orphan chunks exceed `RATIO*live + SLACK`. The dolt-side orders never touch the backup destination, so this fills the gap that caused today's incident.

The manual recipe above is still the operator runbook for emergencies and for `dolt gc --full` from the CLI (which requires city-down because it fights the live sql-server). The scheduled `gc-dolt-disk` order uses `CALL DOLT_GC()` via SQL, which is safe live.
