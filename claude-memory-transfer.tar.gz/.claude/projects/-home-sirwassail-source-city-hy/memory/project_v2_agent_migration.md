---
name: project_v2_agent_migration
description: v2 directory-based agent migration — gc doctor --fix is lossy for multi-rig same-name agents; do it by hand
metadata: 
  node_type: memory
  type: project
  originSessionId: 7cb182fd-8d73-4e53-8f04-d708b4c32947
---

city.toml `[[agent]]` tables are deprecated in v2; directory-based agents live at `agents/<name>/agent.toml`.

**`gc doctor --fix` is lossy and unsafe for this case.** When a v1 agent name appears in multiple `[[agent]]` blocks (a city-wide base + one per rig — the pattern for generic pool workers `claude`/`claude-eco`), `--fix` keeps only the *last* block, including its `dir`, discarding the rest. It also re-clobbers `.beads/hooks` (strips the sw-skip-filter patch — see [[project_bd_hooks_skip_order_tracking]]).

**Correct manual migration:** one `agents/<name>/agent.toml` per agent, `dir` *omitted* — directory agents are rig-scoped by default, so the loader auto-expands to one instance per rig. Verified 2026-05-18: `agents/claude/` + `agents/claude-eco/` (no dir) → resolved config (`gc config show --json` → `.config.Agents`) reproduces the identical base + 9-per-rig topology of the old 20 blocks.

scale_check keeps the literal `{{.Rig}}` — gascity does NOT template-expand ScaleCheck; `cross-rig-scale-check.sh` substitutes it from cwd (see [[project_scale_check_template_bug]]).

Gotcha: `gc supervisor reload` re-stages `.beads/hooks` from the pack, re-clobbering the patch — re-run `scripts/sw-bd-hooks-patch.sh` and don't `git add -A` blindly afterward.

**Why:** clears the persistent `[[agent]]` deprecation banner / `v2-agent-format` doctor warning.
**How to apply:** never trust `gc doctor --fix` for multi-rig agents; migrate by hand and verify via `gc config show --json`.
