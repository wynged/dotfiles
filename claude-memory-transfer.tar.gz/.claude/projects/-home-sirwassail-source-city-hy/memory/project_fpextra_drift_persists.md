---
name: project-fpextra-drift-persists
description: 2026-05-15 — gc supervisor FPExtra config-drift oscillation still drains pool/named sessions despite 4 landed fixes in binary; pool workers survive via wake_mode=fresh resume but cost ~8s spawn + lost turn ×4-5 per task; tracked as ch-6tif
metadata: 
  node_type: memory
  type: project
  originSessionId: 7f671732-0a6b-4ec1-964f-a250e5f766a8
---

The gc supervisor's FPExtra fingerprint check still oscillates between stored
(at session-start) and current (per-tick) hashes for named + pool sessions —
declaring `config-drift` and draining live workers mid-task.

**Why:** Four upstream fixes already landed and ARE in the running binary
(/home/sirwassail/go/bin/gc built 2026-05-14 15:13 from local-integration
c7b51d44): 059e6b70 (drop pool.check), c4bb343d (cache last-good skill
catalog), 0d0292e4 (harden cache), b20a8d5a (attached-session no-restart).
Bug persists anyway — needs further diagnosis.

**How to apply:**

- When a crew/scheduled-agent mails about pool workers "disappearing
  mid-task and restarting": don't redirect them to flake / OOM / WSL git
  crash investigations. Default theory is FPExtra drift; verify in
  `~/.gc/supervisor.log` for `config-drift <session>: ... drifted fields:
  FPExtra`.

- The diagnostic prints only the CURRENT FPExtra map, not the stored one,
  so you can't see which KV changed. The printed map's contents look
  identical to expectations (skill hashes + wake_mode:fresh + pool.min/max
  for pools), but hashes differ. Something unprinted in the actual stored
  map is moving — that's the next debug step.

- For pool workers (e.g. reviewer): wake_mode=fresh means each respawn
  starts a new Claude conversation but the bead's assignee + in_progress
  status persists, so the worker resumes. Cost is ~8s spawn + lost
  in-progress turn per cycle, ~4–5 cycles per task. funyun observed this
  on pr-ar9v + pr-hiq8 (2026-05-15 ~07:30Z) and both completed.

- Citywide signature: drift hits every named/pool session in the same
  window (crew + pool + mayor). 4090+ events accumulated in supervisor.log
  by mid-day. Drift-fields=FPExtra for all of them.

- Workaround until the unprinted-key gets identified: nothing manual to do
  — workers self-recover. But this is the explanation for any "session
  disappeared and came back" report.

Related: [[project-named-session-workdir-template-leak]] (different
recurring drift pattern around work_dir templating, also unfixed upstream),
[[reference-debugging-gc-daemon]] (supervisor.log location).
