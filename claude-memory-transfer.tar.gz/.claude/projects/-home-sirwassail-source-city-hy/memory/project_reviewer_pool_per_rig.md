---
name: reviewer-pool-per-rig
description: Reviewer pool was made per-rig (2026-05-14) — moved from agents/reviewer/agent.toml (pringle-only) to packs/investigation/agents/reviewer/agent.toml (scope=rig); every rig that includes packs/investigation now has its own <rig>/reviewer pool
metadata:
  node_type: memory
  type: project
  originSessionId: 65f08d6d-33c7-4c75-b8da-81f253568ffb
---

The pringle/reviewer pool originally lived at `agents/reviewer/agent.toml` with `dir = "pringle"`. Its worker query was single-rig (`bd ready ... gc.routed_to=pringle/reviewer`) while its scale_check was cross-rig — when parcel (api crew) filed review beads on api's `.beads/` with `gc.routed_to=pringle/reviewer`, demand=2 fired pool spawns on pringle, but pringle-worktree workers never saw the api beads. 13+ pool sessions spawned in 26min on 2026-05-14, none ever claimed. Even if claim had worked, the pringle worktree's `origin` (hypar-io/pringle) couldn't fetch an api branch.

**Fix (2026-05-14):**

- Created `packs/investigation/agents/reviewer/agent.toml` with `scope = "rig"`, `work_dir = ".gc/worktrees/{{.Rig}}/reviewers/{{.AgentBase}}"`, `scale_check = "...cross-rig-scale-check.sh {{.Rig}}/reviewer"` — mirrors the ant pack-scoped pattern.
- Deleted legacy `agents/reviewer/agent.toml`.
- Rewrote `prompts/sw-reviewer.md` to use plain `bd ready --metadata-field gc.routed_to=$GC_TEMPLATE --unassigned` (local rig only — that's where the bead lives now). Cross-rig stanza removed.
- Updated `overlays/crew/.claude/commands/sw-review.md` to route via `ROUTE="${GC_TEMPLATE%%/*}/reviewer"` instead of hardcoded `pringle/reviewer`.
- Added `overlays/crew-api/.claude/commands/sw-review.md` (api-flavored: master branch, AGENTS.md-driven standards, no pringle lessons paths).
- `gc reload` — 9 rig/reviewer instances registered: pringle, bug-sherrif, elements, hypar-connection, hypar-project, hypar-elements, api, suggestions-classroom, corp.

**Why per-rig instead of cross-rig dispatch:** native git semantics. The reviewer worktree's `origin` always matches the bead's rig, so `git fetch origin && git checkout origin/<branch>` just works. No PROJECT IDENTITY MISMATCH, no foreign-remote hacks.

**How to apply:** crew slash commands should route reviews to `${GC_TEMPLATE%%/*}/reviewer`, not a fixed rig. Bare `bd ready` in a per-rig pool worker is fine (and correct) — only cross-rig pools need `cross-rig-find-work.sh`. The earlier 2026-05-14 patch that added cross-rig-find-work to the reviewer was a stopgap; this commit supersedes it.

Related: [[reference_pool_autoscale]], [[project_scale_check_template_bug]], [[project_ant_pools]] (the pack-scoped-pool pattern reviewer now follows).
