---
name: Eric — user profile
description: Eric's role, setup, and how he works with the city. Helps tailor responses and suggestions.
type: user
---

- Runs a GasCity setup (`city_hy`) managing AI coding agents on the `pringle` rig (a web app at hypar-io/pringle)
- GitHub username: `wynged`
- Has 10+ named crew agents (snack-themed: cheeto, lays, herrs, utz, ruffles, kettle, taki, bugle, doritos, frito) — transitioned from Gastown (hypar-gt) to GasCity
- Currently active crew: `utz` and `frito` on pringle
- Thinks in systems — wants infrastructure that self-improves, not just one-off fixes
- Cares about the distillery as a long-term investment in agent quality
