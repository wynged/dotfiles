---
name: Agenda (bead-backed)
description: Eric's daily priority tracker is bead-backed; labels agenda-active/project/infra; lookout pane + /sw-agenda are the surfaces
type: reference
originSessionId: 7d43710a-c941-4a1a-a366-f04d37966e21
---
Eric's agenda lives in beads (city_hy store), surfaced through:

- **Lookout dashboard** — agenda pane shows three sections: Active, Projects, Infra. Keys: `j/k` move, `tab` cycle section, `space` toggle done, `a` toggle active flag, `n` new, `t` rename, `e` edit description, `[/]` move within tier, `p` swap home tier.
- **`/sw-agenda` slash command** — `.claude/commands/sw-agenda.md` shells `bd` directly using the same conventions.
- **`scripts/agenda-snapshot.sh`** — text dump for tools that don't speak bead. `--infra-only`, `--active-only`, and `--json` modes available.

## Storage convention

- One bead per agenda item, `type=task`.
- Home tier label: `agenda-project` OR `agenda-infra` (mutually exclusive).
- Active overlay label: `agenda-active` (added on top of the home tier label; an item appears in both Active and its home section while set).
- Manual sort order: `metadata.agenda.rank` (float between neighbors on insert; integer-renumbered on collision).
- `dispatched_to_epic=<epic-id>` metadata links an agenda bead to a project epic on a rig (set when /sw-agenda dispatches an idea).

## Behavior rules

- Eric drives the list — don't invent items or auto-import from other beads.
- "Active" reflects what Eric is currently moving on. Mayor reads Active first to know what to keep him moving forward on.
- Don't move items between home tiers unprompted; ask if a Project has been lingering many days.
- Don't auto-close completed items.
- Dispatch (sending an idea to a crew agent) adds `agenda-active` to the agenda bead and stamps `dispatched_to_epic`; the bead is *not* closed at dispatch — it closes when the dispatched epic completes.

## What replaced what

The previous markdown file `agenda-state.md` was migrated to beads on
2026-05-07 and removed. Don't read or write it. The migration script is
`scripts/agenda-md-to-beads.py` (idempotent, kept around for reference).
