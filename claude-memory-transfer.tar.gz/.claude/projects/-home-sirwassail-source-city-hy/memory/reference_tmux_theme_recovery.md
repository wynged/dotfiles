---
name: tmux theme recovery — manual per-session run
description: When crew tmux sessions show no theme (default gray status bar), session_setup/session_live didn't apply at start. Recovery is a bash loop running scripts/tmux-theme.sh against every live session — works in seconds.
type: reference
originSessionId: ae36fea7-a493-469f-872b-aa330b889957
---
`scripts/tmux-theme.sh <tmux-session-name> <agent> <city-root>` applies role-based tmux status-bar coloring + icon. Idempotent, ~76ms per session. The script is wired into every agent.toml under both `session_setup` and `session_live`, and the supervisor *should* run it at session start.

Sometimes (observed 2026-05-01) the wiring silently no-ops for `[[named_session]]` crew (utz, bugle, funyun, kettle, …) — `tmux show-options -t pringle--utz status-style` returns empty. Mayor and lookout are usually fine; crew gets gray. Root cause unknown; tracked as ch-d3ay.

**Recovery (2026-05-05+):** the hand-coded bash loop is now wrapped in
`scripts/sw-theme-restore.sh`, exposed as `/sw-theme-restore`. Auto-discovers
every live session on the GC socket and re-applies. Run from the mayor:

```
/sw-theme-restore
```

Or directly: `$GC_CITY/scripts/sw-theme-restore.sh`. Output lists every
themed session and the final count.

Session-name → agent-qualifier mapping the script uses (same convention
as gascity templates):
- `<rig>--<agent>` → `<rig>/<agent>` (per-rig crew like `pringle--utz`)
- `<name>` → `<name>` (city-level: mayor, lookout, scholar, …)

If you ever change role colors or add a new role, edit `scripts/tmux-theme.sh` and re-run the recovery loop; agents pick up the change without restart.
