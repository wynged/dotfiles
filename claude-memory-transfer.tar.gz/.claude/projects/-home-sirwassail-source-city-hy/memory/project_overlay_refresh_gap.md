---
name: overlay-refresh-gap
description: "gc session kill/reset do NOT re-stage overlay onto existing worktree — gascity stages only on initial worktree creation, leaving overlay edits stranded for active crew"
metadata: 
  node_type: memory
  type: project
  originSessionId: bae9e8fa-c8ad-4ce3-b147-a7bc1c0e0223
---

Empirical finding (2026-05-14): when an overlay file (e.g.
`overlays/crew-api/CLAUDE.md`) is edited and `gc session kill` or
`gc session reset` is run on the named session, the worktree's copy
of that file is **not** refreshed. Source diverges from worktree;
agent keeps seeing the stale content.

**Why:** gascity's `StageSessionWorkDir` (internal/runtime/staging.go)
runs `overlay.CopyDir`, which for the `claude` provider would
overwrite via `O_TRUNC` (no preserve-existing list). So if it ran on
restart it would work — but it only runs on initial session
creation. `kill` and `reset` don't invoke the staging pass at all on
existing worktrees. Memory [[reference_overlay_copy_timing]] said
"session-start-only; recovery is `gc session kill`" — that was
imprecise: kill works for the FIRST start when the worktree is being
built, not for subsequent restarts.

**Confirmed not-a-fix:** `gc session kill`, `gc session reset`,
`gc session submit` to an asleep session. None re-stage. Verified
on api/parcel 2026-05-14 — worktree CLAUDE.md mtime 09:31 unchanged
after kill+submit then reset.

**Working recovery (manual):**
```
cp overlays/<template>/<file> .gc/worktrees/<rig>/<agent>/<file>
gc session reset <rig>/<agent>     # so the in-memory CLAUDE.md is reloaded
```
For nested overlay paths (`.claude/settings.json`, etc.) the same
pattern works — just cp the file. Verified on api/parcel: after
cp + reset, parcel read both `@AGENTS.md` and `@/.../crew-operating-procedure.md`
from its CLAUDE.md.

**Why to apply:** any time you edit an overlay file (CLAUDE.md,
.claude/settings.json, slash commands under .claude/commands/) for
a crew that already has a worktree, the change won't reach the
agent without manual sync. Active crew need cp + reset; asleep
crew probably also need cp before next wake (haven't tested that
edge — likely same gap because the worktree pre-existed).

**Open follow-up:** worth a gascity-side fix that adds a `gc session
restage <alias>` verb or makes `gc session reset` re-invoke
`StageSessionWorkDir`. Until then, treat overlay edits as
"requires per-worktree sync" not "edit and it propagates."

Related: [[reference_overlay_copy_timing]] (the memory this corrects).
