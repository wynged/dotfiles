---
name: cross-rig-demand-refresh missed pools when bd ready hit default limit
description: scripts/cross-rig-demand-refresh.sh missed pool demand when dog (or any other high-volume route) had ≥10 ready beads, crowding others out of the bd-ready top-10
type: project
originSessionId: e08dd07f-2cc9-4cea-8b0c-b5adcd25e5ce
---
`scripts/cross-rig-demand-refresh.sh` walks each rig's beads via `bd ready --unassigned --json` (no limit) and aggregates `gc.routed_to` counts into `.gc/runtime/cross-rig-demand.json`. Pool scale_checks read that cache to decide how many sessions to spawn.

**Why:** `bd ready` defaults to `--limit 10`. When one route (dog had 10+ ready beads on 2026-05-05) saturates the top-10, demand for other routes (forager=3 actual, was reported as 1) gets clipped. The pool reconciler then under-scales — observed: 3 forager beads queued, only 1 forager session spawned, the other 2 beads sat unclaimed.

**How to apply:** the fix is `--limit 0` on all three queries (`bd ready`, `bd list --status=in_progress`, `bd list --type=molecule`) in `scripts/cross-rig-demand-refresh.sh`. If any pool seems wedged at min sessions while `bd ready --metadata-field gc.routed_to=<route> --unassigned` shows >0 ready, suspect this and check `cross-rig-demand.json` against ground truth. Latent for any pool when another route fills the top-10. Fixed 2026-05-05.
