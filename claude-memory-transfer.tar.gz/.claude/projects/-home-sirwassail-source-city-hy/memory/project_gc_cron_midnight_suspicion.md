---
name: gc cron midnight suspicion
description: Suspected gc cron evaluator bug — `0 0 * * *` schedule never fires; `5 0 * * *` workaround in place, file upstream if it fixes the issue
type: project
originSessionId: 7b8278eb-9d19-4c4b-b939-4e0aa2bd440f
---
`orders/nightly-bs-sweep.toml` was registered 2026-04-25 with schedule `0 0 * * *` (midnight EDT). It never fired across at least three midnight windows: `gc order history nightly-bs-sweep` was empty and supervisor.log showed 0 `order exec nightly-bs-sweep` lines vs. 4 for the structurally-identical `daily-learning-brief` at `30 5 * * *`. Schedule was the only meaningful difference between the two orders.

Workaround: shifted to `schedule = "5 0 * * *"` on 2026-04-28 (commit follows this memory). Same exec body, same trigger type, same file shape — only the cron string changed (and the bare `cricket` → `bug-sherrif/cricket` alias fix, which was a separate compounding bug).

**Why:** Two compounding bugs were blocking the same order, so each masked the other in early diagnosis. The alias bug would have masked any successful cron fire (exec would fail to find session). Once the alias was fixed, the cron-never-fires symptom became unambiguous.

**How to apply:** After 2026-04-29 00:05 EDT, check `gc order history nightly-bs-sweep` for an entry. If yes — workaround works, the bug is in gc's handling of the `0 0` cron pattern specifically. File upstream against gascity with both data points (the `0 0 * * *` zero-fires and the `5 0 * * *` works comparison). If the new schedule also doesn't fire, look elsewhere (controller-paused at midnight, order loader race, etc.) before blaming the evaluator.
