---
name: reference_crew_overlay_rig_claude_clobber
description: "shared overlays/crew CLAUDE.md is Pringle-specific and clobbers a rig's own CLAUDE.md; non-pringle crew rigs need a per-rig overlay; docs-vault rigs need one with NO CLAUDE.md"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 8b4143ca-a782-45e7-a7c7-2a7659c97a81
---

`overlays/crew/CLAUDE.md` is **Pringle-specific** (Vue reactivity, ESLint, i18n, ai-tool unit audit). The overlay copy writes it to the worktree's `CLAUDE.md` path, so any crew agent on a non-pringle rig that has its **own** `CLAUDE.md` gets it clobbered.

Established pattern: give non-pringle crew rigs a **per-rig overlay** — `overlays/crew-api`, `overlays/crew-bug-sherrif`. Those rigs keep their technical guidance in `AGENTS.md`, leaving `CLAUDE.md` free for a short overlay wrapper that `@`-includes `AGENTS.md` + `_my_city/crew-operating-procedure.md`.

**Docs-vault wrinkle** (hypar-insights): the vault's real docs live *in* `CLAUDE.md` and the agent (oracle) **edits it as a work product**. So its overlay must ship **NO `CLAUDE.md` at all** — you cannot `@`-include the vault content because the overlay would overwrite the editable file. Fix 2026-05-21 (ch-9ikp): `overlays/crew-hypar-insights` = copy of `overlays/crew` minus `CLAUDE.md`; repointed `agents/crew-hypar-insights/agent.toml` `overlay_dir`; `gc supervisor reload` (oracle session survived). To clear a worktree already clobbered before the fix: `git restore CLAUDE.md` in the worktree.

Tradeoff: omitting `CLAUDE.md` drops the codebase-agnostic `crew-operating-procedure.md` `@`-include that rode in via the overlay CLAUDE.md. Slash commands (`/sw-focus`, `/sw-handoff`, `/sw-cleanup`) still carry the flows; to wire the procedure back without clobbering you'd edit the vault's own `CLAUDE.md` (one `@`-include line) — deferred.

Same-pattern watch: `crew-corp` (corp), `crew-classroom` (suggestions-classroom, suspended) also point at `overlays/crew`. corp has **no** own `CLAUDE.md`, so no destructive clobber today — the Pringle CLAUDE.md just becomes irrelevant project context.

**Recipe — add a crew agent to a non-pringle code rig** (gantt/hypar-project, 2026-05-21): clone **`crew-api`, not `starch`**. (1) `cp -r overlays/crew-api overlays/crew-<rig>`, then adapt its `CLAUDE.md` header and **drop the `@AGENTS.md` line if the rig has no `AGENTS.md`** — hypar-project doesn't, so it keeps only the `@_my_city/crew-operating-procedure.md` include + a guidance stub. (2) Create `agents/crew-<rig>/agent.toml` from crew-api's (set `dir`, `work_dir = .gc/worktrees/<rig>/{{.AgentBase}}`, `overlay_dir = overlays/crew-<rig>`; keep `prompt_template = prompts/crew.md`, `wake_mode = fresh`). (3) Add a `[[named_session]]` block (`name = <clever>`, `template = crew-<rig>`, `dir = <rig>`, `mode = on_demand`). (4) `gc supervisor reload`; on_demand won't spawn until `gc session submit`. ⚠️ **`starch` (hypar-elements) is the buggy outlier** — its `agent.toml` still has `overlay_dir = "overlays/crew"`, so cloning it would inject Pringle's CLAUDE.md. hypar-project also has no own CLAUDE.md, so the bug would've been silent-but-wrong (Pringle context), not a destructive overwrite.

Caveat: oracle reported the overlay re-clobbering **mid-session** (≈9 min in, and after a Write), which contradicts [[reference_overlay_copy_timing]] (session-start-only) and [[project_overlay_refresh_gap]] — may mean upstream overlay live-reload has landed. Unverified; check before relying on creation-time-only staging.
