---
name: Dead-pane carcasses block respawn
description: Crashed-on-startup claude leaves a tmux session with a dead pane; supervisor sees session "exists" and won't respawn until the carcass is killed.
type: reference
originSessionId: cc895f64-7a7d-41f9-a989-7e7566f534d3
---
When a claude process crashes during gascity session startup (anything that
exits with status 1 before the supervisor's startup-dialog handshake
completes), tmux retains the session as a dead pane (`Pane is dead (status 1, …)`
when you `capture-pane`). The supervisor sees the tmux session exists and
won't respawn — the bead stays asleep with the tmux name held hostage.

**Symptom:** `gc session submit <crew>` returns "Submitted to <crew>" but
nothing happens. `tmux -L city_hy ls` shows the session. `tmux capture-pane
-t <session> -p` shows "Pane is dead (status 1, …)". `bd show <bead>` says
state=asleep.

**Recovery:**
```bash
tmux -L city_hy kill-session -t <session-name>   # e.g. pringle--dorito
gc session submit <rig>/<crew> "/sw-focus"
```
The next submit spawns cleanly because the tmux name is free again.

**How to apply:** If multiple crew are stuck after a refactor or supervisor
restart cycle, sweep:
```bash
for s in $(tmux -L city_hy ls -F "#{session_name}"); do
  tmux -L city_hy capture-pane -t "$s" -p 2>&1 | grep -q "Pane is dead" \
    && echo "DEAD: $s"
done
```
Lookout's awake-detection trusts `gc session list` (state="active"), so
dead-pane sessions correctly show as not-awake — but the user-facing
mismatch ("I see the tmux session, why isn't the crew alive?") is exactly
this.

**Why this is a recurring shape:** common triggers — supervisor restart
mid-spawn, dolt unreachable during startup-dialog (early exit before
handshake), provider command flag drift (claude CLI rejecting an arg).

**2026-05-27 root cause for kettle/taki/+9-others:** the actual crash was
`claude --resume <session_key>` failing with `No conversation found with
session ID: <uuid>` because the bead's `session_key` pointed at a JSONL
file that's no longer on disk (Eric's note: city stopped retaining
JSONLs, so any session that hasn't woken in days has a stale key). The
supervisor's `post_start_observe` still reported `outcome=success` while
the pane died ~2s later — a separate gc bug.

Recovery shape for "session JSONL gone, --resume hard-fails":
```bash
# 1. kill dead carcass if there is one
tmux -L city_hy kill-session -t <session-name>
# 2. clear stale session_key on the bead
unset BEADS_DIR; bd update <bead-id> --set-metadata session_key=
# 3. submit; gc spawns fresh (no --resume since key is empty)
gc session submit <rig>/<crew> "ping"
```
Sweep across the city by joining `gc session list --json` with
`~/.claude/projects/<wd-slug>/<session_key>.jsonl` existence — the
wd→slug rule is `s/[/_.]/-/g`. Active sessions can have stale keys too
(saw pretzel state=active with missing JSONL on 05-27) — leave those
alone unless they actually die.
