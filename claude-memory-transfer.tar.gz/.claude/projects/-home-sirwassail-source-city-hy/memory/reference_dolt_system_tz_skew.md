---
name: Dolt SYSTEM time-zone skew
description: City dolt server runs @@time_zone=SYSTEM (EDT, UTC-4) but bd writes timestamps as UTC literals — closed_at < NOW() comparisons effectively shift TTL by 4h
type: reference
originSessionId: 1def08a0-7840-4de0-bdcd-32983a30d783
---
City dolt sql-server has `@@session.time_zone = SYSTEM` and `@@global.time_zone = SYSTEM`, which on this box resolves to EDT (UTC-4). bd writes `closed_at`, `created_at`, `updated_at` as UTC literals (e.g. `2026-05-04 20:27:50` for an event that happened at 16:27 EDT). Dolt then interprets those stored literals as local-time values when comparing to `NOW()`.

Net effect: a freshly-closed bead has `closed_at` that appears **4 hours in the future** relative to `NOW()`. A bead must age ~28h before `closed_at < NOW() - INTERVAL 24 HOUR` becomes true.

**How to apply:**
- Any TTL-gated cleanup (e.g. `scripts/cleanup-order-tracking.sh`) effectively runs at TTL+4h, not TTL. Don't panic when "nothing to clean" comes back on a freshly-flipped reaper — wait for the skew to age out.
- Don't try to "fix" by subtracting 4h from queries; the skew is consistent across reads/writes, just shifted. Self-corrects once beads are old enough.
- Verify with `SELECT NOW(), @@session.time_zone;` and compare to `date -u`.
- Real fix would be either (a) set dolt's time_zone to UTC, or (b) have bd write timestamps in local-zone format. Neither is in scope for routine work.
