---
name: forager-drain-mitigation
description: forager/reviewer pool drain (ch-z4xr8) ROOT CAUSE FOUND 2026-05-21 — the unlogged assignee-clearer is the orphan-sweep maintenance order, broken by gc session-list JSON schema drift; fix = correct its jq
metadata:
  node_type: memory
  type: project
  originSessionId: ae90f705-2df2-459a-ac32-bc894b6dab3b
---

## ROOT CAUSE FOUND 2026-05-21 (supersedes the dead-ends below)

The unlogged assignee-clearer is the **`orphan-sweep` maintenance order** (5-min cooldown
exec order, `.gc/system/packs/maintenance/orders/orphan-sweep.toml` →
`assets/scripts/orphan-sweep.sh`), NOT any gascity supervisor path.

`orphan-sweep.sh` resets any `in_progress` bead whose assignee isn't a "known agent" via
`is_known_agent()`, which accepts a live pool-worker assignee only through
`live_session_match()` against `LIVE_SESSION_IDS`. That list is built with
`jq '.[] | select(.Closed==false) | [.ID,.SessionName,.Alias,.AgentName]'` — but
**`gc session list --json` schema drifted** (a gc upgrade): it's now an object
`{filters,schema_version,sessions,summary}` with sessions under `.sessions[]` and
**snake_case** fields (`.id,.session_name,.alias,.agent_name,.closed`). So `.[]` iterates
object values, jq errors, `2>/dev/null` swallows it → `LIVE_SESSION_IDS` is **always empty**
→ every pool worker (claims with `$GC_SESSION_ID` = a bead-id like `ch-yu3s`) is judged
orphaned → `gc bd update <id> --status=open --assignee=""` within ≤5min. The script's own
comment predicts exactly this. **Why the `--claim`→`$GC_SESSION_ID` fix didn't help:** both
shapes fail `is_known_agent` because the session lookup itself is dead; assignee shape was
never the lever. Same mechanism drains `reviewer` (also claims with `$GC_SESSION_ID`).

Evidence trail (all on bead `ch-z4xr8` notes): dolt cell-history shows clear commits with
metadata byte-identical to claim (status+assignee only, no `recovered=true` → rules out the
repo variant + report-and-exit); `released orphaned pool work` never logged for the churned
beads; orphan-sweep's reset stdout isn't captured in supervisor.log (= "unlogged").

**FIX LANDED 2026-05-24** in the gc binary (the deployed `.gc/system/packs` copy is NOT
editable — gc re-materializes it from the maintenance pack **embedded in the gc binary**;
embed source `examples/gastown/packs/maintenance/assets/scripts/orphan-sweep.sh` via
`internal/builtinpacks/registry.go`). Fix: jq `.[]`/PascalCase → `.sessions[] |
select(.closed==false) | [.id,.session_name,.alias,.agent_name]`, fallback `[]`→`{"sessions":[]}`,
+ schema-drift fail-safe. Landed via the patch-stack workflow: branch
`fix/orphan-sweep-session-list-schema` off main → registered in `.gc-update-state.json` →
integrated into `local-integration` (merge a88214513) → `make install`
(installed_version `1.1.1+local-integration@a88214513`). Verified the binary embeds the fix.
**VERIFIED IN PRODUCTION 2026-05-24 — RESOLVED.** After full restart on the new binary
(`gc stop` → `systemctl --user restart gascity-supervisor.service` → `gc start`,
re-materializing the deployed copy with the fix): a real forager (`forager-ch-7us`) claimed
pr-fe1e with `assignee=ch-7us` (the bead-id shape) and held it **~7 min** through an
orphan-sweep that **ran at 13:36:47Z** (events.jsonl `order.completed orphan-sweep`) without
clearing it — the bead now appears in multiple `assignedWorkBeads` snapshots (bug signature
was the opposite), no `Draining … forager-ch-7us`. Fresh manual run of the deployed fixed
script: live-session-assigned bead kept, dead-assignee bead still swept. Fix shipped in gc
binary `local-integration@a88214513`. Optional follow-up: upstream gascity PR (embedded-pack
bug hits every city). See [[reference_dual_location_packs]], [[project_gc_upgrade_clobbers_orders]],
[[reference_gascity_local_integration_combo]].

---

## (historical) The pre-root-cause investigation notes

The `pringle/forager` pool drain bug (`ch-z4xr8`) is NOT fixed as of gc 1.1.1 (the same `orphaned` / `no-wake-reason` drain paths also hit `pringle/reviewer`). A **fresh investigation is starting 2026-05-21** — the detailed forensics live on bead `ch-z4xr8`; this memory captures the confirmed observable, the dead-ends to NOT re-walk, and the working mitigation.

## Confirmed observable (the real symptom)
A forager claims its routed bead and works for minutes, then **the bead's assignee is silently cleared** (`assignee=""`, `in_progress→open`) *while the worker is still alive and working*. Now lacking an assigned-work wake reason, the worker is drained `no-wake-reason` on its next idle tick → the open+routed bead re-queues → a new doomed worker spawns → churn. A worker that stays continuously busy can dodge the idle-moment drain and finish, but that's luck, not reliability.

## DEAD-ENDS — do not re-investigate these (2026-05-21 live test)
- **NOT the claim assignee shape / `--claim`.** Theory was: `bd update <id> --claim` wrote a bad assignee the reconciler couldn't match. DISPROVEN — changed the forager prompt to claim with `--assignee="$GC_SESSION_ID"` (clean bead-id, matches `bead.ID` in `compute_awake_set.go`), verified beads claimed as `pr-fe1e→ch-yu3s` / `pr-03i3→ch-a553`, and **they still drained**. The drain fires because the assignee gets *cleared*, regardless of what shape it was.
- **NOT gascity's logged orphan-release.** `releaseOrphanedPoolAssignments` (pool_session_name.go:278) produces exactly this `assignee=""`/`open` transition, BUT it logs `released orphaned pool work: <id>` (71× historically in supervisor.log) and our drained beads were NEVER in those lines.
- **NOT the worker's own report-and-exit.** That path also sets `kind=forage_result` + `branch` + unsets `gc.routed_to`; the drained beads kept `kind=forage_request`, `gc.routed_to` set, no branch metadata — so the worker never ran it.
- **NOT city orders or bd hooks** (checked check-alias-assignees.sh + .beads/hooks/*).

## Open question for the fresh investigation
What clears the assignee on a live in-progress pool bead, without logging via the known release path? Candidates: an unlogged gascity reconciler/snapshot reset, a cross-store identity-scoping miss (the forager session bead exists in BOTH the city store and the pringle rig store), or a dual-claim-resolution path. Suggested probes: dolt cell-level history on the `assignee` column of a churning bead, or a `GC_TMUX_TRACE`/reconciler trace correlated to the exact clear timestamp.

## Current state of the forager (changed during the failed fix)
`packs/forage/prompts/forager.md.tmpl` now claims with `bd update <id> --assignee="$GC_SESSION_ID" --status=in_progress` and the Step-1 resume check uses `$GC_SESSION_ID` (was `--claim` / `$GC_AGENT`). This is a harmless alignment with the already-migrated `reviewer`/crew claim convention — kept, but it is NOT a fix.

## Working mitigation (still valid)
- Keep `agents/forager/agent.toml` at `max_active_sessions=2`.
- Dispatch batches where **distinct ready beads >= max**; never leave a lone trailing routed bead.
- To stop churn: `bd update <id> --unset-metadata gc.routed_to` (scale_check drops; cross-rig demand cache `.gc/runtime/cross-rig-demand.json` refreshes ~60s, then poolDesired follows). A drained worker's bead reverts to open and the in-session work is lost — but a committed branch survives in pringle `.git` and can be **salvaged**: stamp the bead `kind=forage_result` + `branch` + `head_sha` + `salvaged_from` so it lands in the forage-review queue (done 2026-05-21 for pr-03i3 → `fix/space-type-default-side-effect-undo`).

See also [[reference_forage_kind_metadata]], [[reference_suspend_pack_pool]], [[project_fpextra_drift_persists]], [[project_alias_assignee_spawn_bug]].
