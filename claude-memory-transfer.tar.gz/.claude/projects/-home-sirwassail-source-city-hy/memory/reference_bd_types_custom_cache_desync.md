---
name: reference-bd-types-custom-cache-desync
description: "bd validation cache desyncs from persisted types.custom — re-set the same value to refresh; symptom is \"invalid issue type: <name>\" even though bd config get types.custom lists it"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 2a5db71b-fe99-4ec9-a1fb-279292cd4772
---

bd's runtime validation of `issue_type` can desync from the persisted `types.custom` value: `bd config get types.custom` shows the type in the list AND config.yaml on disk has it, yet `bd create --type=<name>` still fails with `validation failed for issue <id>: invalid issue type: <name>`.

**Fix:** re-set the same value (or shrink+restore). `bd config set types.custom "<full list>"` clears the desync. The config-key namespace itself emits a deprecation-style warning (`"types.custom" is not a recognized config key. Use 'custom.*' for user-defined keys`) but bd's validation still reads `types.custom` — the warning is misleading.

**Discovered 2026-05-28** while clearing doctor's `order-firing-current` failure on city_hy. mol-dog-stale-db had been failing every 4h cron fire since 2026-05-22 with: `creating bead for step "mol-dog-stale-db.cleanup": bd create: exit status 1: invalid issue type: step`. After running `gc order sweep-tracking --include-wisps mol-dog-stale-db` (4 stale wisps closed) AND re-setting `types.custom`, the very next `gc order run mol-dog-stale-db` succeeded — created `wisp ch-7pq` and routed to dog. Pairs with [[order-sweep-missing-include-wisps]] which only handles the wisp side.

The order.fired event log was the diagnostic — every cron tick showed `order.fired` followed by `order.failed` with the schema error, even while `bd config get types.custom` looked correct.
