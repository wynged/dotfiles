---
name: Crew agents must not reply on PR threads
description: When lookout nudges a crew agent about PR comments, the agent should fix the code (so the next push answers via diff) and never post a reply on the PR thread. Eric owns all comment-thread replies. Questionable comments get mailed to mayor for confirmation.
type: feedback
originSessionId: ae36fea7-a493-469f-872b-aa330b889957
---
When a crew agent receives a lookout nudge about a PR comment / review (`COMMENTED`, `CHANGES_REQUESTED`, "Changes requested by X — address review feedback"), the agent must:

1. **Do the work** — fix the code and push so the diff answers the comment.
2. **Never** post on the PR thread itself: no `gh pr comment`, no `gh pr review`, no `gh api .../comments`. Eric replies on GitHub, not the agent.
3. If anything is questionable (ambiguous, scope-expanding, judgment call, unclear ask) — mail the mayor with the PR # and a summary, then wait. Do not guess.

**Why:** Eric watches PR threads and wants to be the human voice on them. Agent replies on GitHub fragment the conversation, look like the agent is speaking for Eric, and short-circuit the human review loop. Agents jumping to reply also tends to mean they're guessing rather than actually understanding the change being asked for. Surfaced 2026-05-01 — agents were posting replies via the lookout-nudge path because the prompt said "address each comment, reply with a question, or flag to Eric" without forbidding GitHub-thread replies.

**How to apply:** Whenever a crew session sees a nudge mentioning a PR review/comment, default to the diff as the reply. Mail the mayor when in doubt. The guidance is encoded in `prompts/crew.md` step 7 and `overlays/crew/CLAUDE.md` "Review Notifications Are Immediate Action Items"; if a future overlay or prompt is added (e.g. `overlays/crew-api/CLAUDE.md` if it ever grows a Review Notifications section), mirror the same rule there.
