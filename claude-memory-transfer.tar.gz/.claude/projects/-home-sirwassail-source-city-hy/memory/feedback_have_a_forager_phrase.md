---
name: "have a forager do <X>" trigger
description: Eric's phrase for one-shot file+dispatch into the forager pool — invoke sw-forage skill's Direct path
type: feedback
originSessionId: 187f1169-b43c-483e-8807-50cfd8383e88
---
When Eric says "have a forager do <X>" / "have a forager <X>" / "have a forager fix/try/look at <X>", invoke the **sw-forage** skill's **Direct path**: file a fresh forage-request bead on pringle (default rig) with X plus inferred files/test context as the body, stamp `metadata.forage_request=ready`, then run `scripts/sw-forage.sh dispatch <id>`. Skip the inbox listing — Eric already knows what he asked for.

**Why:** Eric wants a single phrase that does file+dispatch in one shot, not a two-step "create the bead, then dispatch" dance. The inbox path is for clearing accumulated requests; the direct path is for "do this specific thing now."

**How to apply:** On the trigger phrase, enter sw-forage and follow its Direct path section. If the description is too vague to be a bead body (e.g. "fix the bug" with no context), ask **once** for specifics; otherwise proceed with whatever Eric gave plus best-guess "files likely involved" and "how to test" sections inferred from conversation or a quick grep. Default rig is `pringle` — only confirm rig if the request clearly targets another (`bug-sherrif`, `hypar-connection`, etc.). Worker mails mayor with `forage-result: <id> <summary>` when done.
