---
name: Subagents protect main context during implementation
description: During multi-file implementation work, delegate file-writing and code drafting to subagents so the main session stays lean for orchestration and decisions.
type: feedback
originSessionId: 1b3bd701-13e5-4ce8-b171-c53712dcd2eb
---
When implementing a plan that involves writing multiple large files or reading large amounts of code to produce code, delegate the writing/drafting to subagents rather than doing it in the main session.

**Why:** Eric said "use sub agents during this to protect your context" while approving a multi-file implementation plan (mol-pringle-rl-loop formula + pringle MCP work). The main session's job is orchestration — plan, decide, route, verify — not every keystroke. Large file bodies (200+ line TOML formulas, 200+ line MCP servers) belong in subagent context, not main.

**How to apply:**
- For each large file that needs authoring, spawn a subagent with a complete spec. The subagent does Read + Write/Edit and reports a concise summary.
- Parallelize independent subagents in a single tool-use block.
- Don't re-read files the subagent just wrote unless verifying a specific concern — trust the subagent's summary.
- Distinct from `feedback_subagents_for_scale`: that one is about batch analysis of large data volumes. This one is about implementation output.
