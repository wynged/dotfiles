---
name: Full city restart means supervisor restart
description: When user asks to restart the city, always restart the systemd supervisor too
type: feedback
---

When asked to restart the city, do a full restart: `gc stop`, then `systemctl --user restart gascity-supervisor.service`, then verify with `gc status`.

**Why:** A simple `gc stop && gc start` doesn't replace the supervisor process, so the old binary stays loaded. The user wants the new binary fully in effect.

**How to apply:** Any time the user says "restart" for the city, use the systemd restart approach rather than just gc stop/start.
