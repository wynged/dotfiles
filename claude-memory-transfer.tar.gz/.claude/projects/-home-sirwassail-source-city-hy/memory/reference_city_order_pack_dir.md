---
name: reference_city_order_pack_dir
description: city-owned order wrapping a pack script must repoint GC_PACK_DIR — the order runner sets it to the city root
metadata: 
  node_type: memory
  type: reference
  originSessionId: f51fb74b-ff49-40d3-be40-495dbab68c98
---

A city-owned exec order (`orders/<name>.toml`) runs with `GC_PACK_DIR` set to the **city root**, not a pack directory — city orders have no pack of their own. If such an order wraps/`exec`s a pack script that derives its `PACK_DIR` from `${GC_PACK_DIR:-...}` (e.g. the dolt pack's `mol-dog-doctor.sh`), the script resolves sibling assets (`runtime.sh`, etc.) under the city root and dies with `No such file or directory`.

**Fix:** the wrapper must `export GC_PACK_DIR=<correct pack dir>` before exec.

Working example (2026-05-19): `scripts/sw-dolt-doctor.sh` wraps `.gc/system/packs/dolt/assets/scripts/mol-dog-doctor.sh`, repointing `GC_PACK_DIR` to `$GC_CITY_PATH/.gc/system/packs/dolt`. The `sw-dolt-doctor` order replaces the pack `mol-dog-doctor` order (added to `[orders] skip` in city.toml) to raise the doctor's latency WARN threshold to 2s — the pack script measures probe latency in whole seconds (`date +%s`), so a sub-second probe straddling a clock-second boundary falsely tripped the 1s default. Editing the pack script directly does not stick (`.gc/system/packs/` is re-materialized). See [[reference_orders_wiring]], [[reference_dual_location_packs]].
