---
name: Hall pane uses tmux-only awake detection
description: Session 32 — lookout's Hall sidebar reads tmux list-sessions, NOT gc session list; Hall tick is 5s, no dolt cost. GC_TMUX_SOCKET defaulted in main.go.
type: project
originSessionId: 12f40e1d-58b5-4995-bb7e-b96b09a7e73d
---
As of 2026-05-01 (Session 32), `lookout/internal/hall/hall.go::readAwakeSessions`
delegates entirely to `readAwakeTmux` — it no longer calls `gc session list
--state=all --json`. The dashboard's Hall sidebar consumes only the boolean
"is this alias awake?" and tmux list-sessions answers that locally.

**Why:** The previous `gc session list` call fanned out to a `bd list
--label=gc:session --include-infra --include-gates --limit 0` table scan on
every Hall tick (was the dolt-side hot path from lookout). Hall's `Entry`
struct only stores `Name, Mode, Awake, InHall, Branch, Bucket` — none of
the rich session fields the bd scan was producing. Replacing the call with
the existing tmux read drops Hall's dolt cost to zero and let us bump the
tick from 30s to 5s without measurable load.

**How to apply:**
- If you find code calling `gc session list` on a polling loop "just to
  check what's awake", check whether the consumer needs more than the
  alias-set. If not, replace with `tmux -L $GC_TMUX_SOCKET list-sessions`
  + the `<rig>--<base>` → `<rig>/<base>` translation (template in
  `hall.go:readAwakeTmux`).
- Pool/anonymous workers (`ant-ch-*`) are skipped by that translator;
  they're not in Hall's universe. If you need to detect awake pool
  workers, you DO need bd or gc.
- `GC_TMUX_SOCKET` is the implicit gc↔tmux coupling. gc exports it for
  agent sessions but NOT for tools launched outside that path. lookout's
  `main.go` now defaults it to `basename(--city)` when unset, mirroring
  `lookout-window.sh:26`, `pw-window.sh:21`, `tmux-theme.sh:12`,
  `keybindings.sh:30`. Any new Go tool reading the gc tmux server needs
  the same defensive default.

**Files touched in Session 32:**
- `lookout/main.go:31` — PR refresh default 3min → 1min.
- `lookout/main.go:48-58` — GC_TMUX_SOCKET fallback.
- `lookout/internal/hall/hall.go` — readAwakeSessions tmux-only,
  liveSession struct + encoding/json import removed, package doc updated.
- `lookout/internal/ui/dashboard/dashboard.go:31-39` — hallRefreshInterval
  30s → 5s with new comment.
- `lookout/internal/hall/hall_test.go:132-135` — comment updated.

**Edge cases / regressions:**
- A session "active" in gc but with a dead tmux pane: today shows asleep
  (was: awake, which was wrong).
- One-tick tmux failure: empty awake set, all named sessions flicker to
  asleep until next tick (5s). Tmux on a unix socket basically never
  fails unless the server itself is dead, in which case "asleep" is
  correct anyway.
