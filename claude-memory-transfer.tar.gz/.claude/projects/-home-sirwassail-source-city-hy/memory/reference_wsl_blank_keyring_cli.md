---
name: reference_wsl_blank_keyring_cli
description: "stop Chrome's recurring gnome-keyring 'Unlock Keyring' popup under WSL by making the default collection a blank-password keyring, created purely from the CLI (no seahorse/secret-tool/sudo)"
metadata: 
  node_type: memory
  type: reference
  originSessionId: 7423cfed-f45e-4454-bea9-f9e472b509dd
---

**Symptom (Eric's WSL box, 2026-05-21):** Chrome/Chromium pops "Unlock Keyring" (keyring "Default" is locked) on every launch — including headless agent launches via the chrome-devtools skill. Cause: Chrome keeps its "Safe Storage" cookie-encryption key in the Secret Service (gnome-keyring), and WSL has **no graphical PAM login** to auto-unlock the keyring. The daemon auto-starts three ways (systemd user units, the `org.freedesktop.secrets` D-Bus activation = `gnome-keyring-daemon --start --foreground --components=secrets`, and `/etc/xdg/autostart/gnome-keyring-*`), none feeding a password.

**Fix (CLI-only):** make the default collection a **blank-password (unencrypted)** keyring — it auto-unlocks on access with no prompt.

What does NOT work on this box: no `seahorse`/`secret-tool`, no passwordless sudo, pip is PEP-668 locked. `gnome-keyring-daemon --login` with 0 bytes won't create a keyring; with a NUL byte (`printf '\0'`) it creates one with a *real* 1-char password (stays locked on cold start). `busctl`/`dbus-send` can't do it either — each invocation is a fresh D-Bus connection, which invalidates the `OpenSession` handle that the create call's Secret struct references.

What works: gnome-keyring's internal API `org.gnome.keyring.InternalUnsupportedGuiltRiddenInterface.CreateWithMasterPassword(a{sv} props, (oayays) master)` with an **empty** master Secret, over **one persistent connection**. Use `jeepney` (pure-python; install in a throwaway venv to dodge PEP 668): `OpenSession("plain","")` → `CreateWithMasterPassword({Label:"login"}, (session, b"", b"", "text/plain"))` → `SetAlias("default", collection)`. (`venv → pip install jeepney`; the one-off script was `/tmp/kr_blank.py`.)

**Gotcha — `Collection.Locked == true` is a RED HERRING.** A blank keyring still reports Locked=true, but `Service.Unlock([login])` returns prompt path `/` (no interaction) and Chrome stores its key with no popup even on a cold daemon (`pkill gnome-keyring` then bare `--start`). Verify with that cold start + `google-chrome --headless=new --password-store=gnome --dump-dom about:blank` and watch `~/.local/share/keyrings/login.keyring` grow. (`--password-store=gnome` logs "Unknown password store: gnome" on modern Chrome — renamed `gnome-libsecret` — but still exercises the Secret Service.)

Pre-change keyring dir backed up to `~/.local/share/keyrings.bak.<ts>`; the orphaned old `Default.keyring` can be deleted once happy. To revert: restore the backup over `~/.local/share/keyrings/` and `pkill gnome-keyring`.
