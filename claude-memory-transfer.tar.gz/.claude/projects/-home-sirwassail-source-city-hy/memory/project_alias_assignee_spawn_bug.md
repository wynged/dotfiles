---
name: Alias/stale assignee triggers phantom pool spawns
description: Beads with assignee=<alias> or stale ephemeral session-id cause gascity supervisor to keep respawning pool-ephemeral sessions alongside named beads
type: project
originSessionId: cec8642f-3d76-4acf-8249-836947a33c8f
---
When a bead has `assignee=<alias>` (e.g. `pringle/utz`) or `assignee=<closed-ephemeral-id>` (e.g. `utz-ch-vv3`), the gascity supervisor's `collectOwnershipWorkBeads` sees outstanding demand and sets `poolDesired: pringle/<crew> = 1`, spawning a pool-ephemeral session with alias `<crew>-1` or `<crew>-ch-<newid>` — *in addition to* the named always-on bead (e.g. `ch-9sv`). The ephemeral has `pool_managed=true`, `session_origin=ephemeral`, and a fresh bead-id on each spawn cycle (no conversation continuity).

**Why:** gascity runtime wakes on_demand named sessions by concrete bead-id match. It cannot resolve alias-to-named-bead, so alias-assigned work falls through to the pool-ephemeral path even when the named bead is awake. Also scans every rig's local `.beads/` store — not just the city's — so stale pringle-rig work can drive phantom utz spawns.

**How to apply:** If you see phantom `<crew>-1` or `<crew>-ch-<id>` sessions, or the supervisor log showing `namedWorkReady: N assigned beads, M named specs, ready=map[]` (empty map despite assigned beads), don't just close phantoms — they'll keep coming back. Instead:
1. Check **both** stores: `bd list` (city) AND `cd <rig> && bd list` for each rig.
2. Find non-closed beads with `assignee=<alias>` or `assignee=<session-bead-id>` (e.g. `ch-czfflc`).
3. Reassign to the **agent_name string** (e.g. `bd update <bead> --assignee=pringle/bugle`). The matcher in `cmd/gc/build_desired_state.go:329` only matches when `assignee` literally equals a named-spec identity — it does **not** dereference session-bead-ids to their `agent_name`.
4. `mode=always` does NOT prevent this — the runtime creates the ephemeral regardless. Only fixing the assignees stops it.

**Validated 2026-04-27 incident**: 16 `pr-*` beads in pringle rig had `assignee=ch-czfflc` (the session bead for `pringle/bugle`). Supervisor logged `ready=map[]` every tick and spawned 14 concurrent `bd show/list` children, holding dolt-server at 163% CPU. Fix: reassigned all 16 to `assignee=pringle/bugle`.

Corollary — don't use `--assignee=<alias>` OR `--assignee=<session-bead-id>` for new work targeting named crew. Use the `agent_name` string verbatim, or leave blank and `gc mail send <alias>` / `gc session submit <alias>` for delivery.
