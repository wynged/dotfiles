---
name: gc session reset silent not-found
description: gc session reset prints "session not found" but exits 0 for rig-scoped sessions when given bare name; must use full <dir>/<bare> alias
type: reference
originSessionId: 187f1169-b43c-483e-8807-50cfd8383e88
---
`gc session reset cheezeit` (bare name for a rig-scoped session) prints `gc session reset: session not found: "cheezeit"` to stderr **but exits 0**. This silently breaks `&&` chains — confirmed by `gc session reset zzz-nonexistent` → exit=0.

Rig-scoped sessions (utz, frito, cheezeit, dorito, kettle, combo, bugle, etc. — anything with a `dir = "..."` line in its `[[named_session]]` block) require the full alias `<dir>/<bare>` (e.g. `pringle/cheezeit`). City-level sessions (mayor, witness, scholar — no `dir`) accept the bare name.

`gc session submit` is more permissive about bare names (probably tmux-pattern fallback), so a script calling `reset bare && ... && submit bare` will look like "submit worked" while reset silently no-oped — the runtime is never torn down.

**Why this is load-bearing**: lookout's handoff chain hit this exact bug and lost cycle attempts for the entire pringle named-crew. Patched in 2026-05-05 by capturing `dir` from city.toml and composing the alias before calling reset/submit (see `lookout/internal/handoff/handoff.go::Run`).

**How to apply**: any tooling that wraps `gc session reset` should either (a) pass the alias form, or (b) capture stderr and grep for `session not found` to convert the silent failure into a real one. Prefer (a). If you build a script that uses bare names, treat reset's exit code as untrustworthy.
