---
name: gc session kill vs reset for on_demand
description: kill leaves on_demand beads stuck at sleep_reason=suspended; reset is the right verb for cycling on_demand
type: reference
originSessionId: 1b2fd6e8-23b9-4125-a907-ac036014bd28
---
For `mode = on_demand` named sessions, `gc session kill <name>` is the wrong primitive. Per `gc session kill --help`: "the reconciler will detect the dead process and restart it according to the session's lifecycle rules." For on_demand, that rule is "do not auto-restart" — so the bead lands at `state=asleep, sleep_reason=suspended` and stays there. Subsequent `gc session submit` may eventually unstick it, but slowly and unreliably.

Use `gc session reset <name>` instead. Per its help: "controller stops the current runtime and starts the same session again with fresh provider conversation state. Session identity, alias, mail, and queued work remain attached to the existing session bead." That's what cycling actually wants.

Recovery if a session is already in the kill-suspended state: `gc session submit <name> "ping"` eventually wakes it (verified on taki 2026-04-29). `gc session reset` alone doesn't appear to clear suspended cleanly without a follow-up submit.

Discovered while implementing `lookout handoff` (ch-wn2w) — first impl used kill, taki got stuck. Switched to reset.
