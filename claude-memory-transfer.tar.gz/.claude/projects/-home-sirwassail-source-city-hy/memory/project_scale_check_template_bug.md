---
name: scale_check template expansion bug
description: gascity supervisor doesn't template-expand scale_check command — literal {{.Rig}} breaks rig-scoped pool spawn
type: project
originSessionId: 16048bf0-39f0-45bb-8956-8adf106a43ad
---
gascity's `ScaleCheck` field is NOT run through `resolveTemplate` like `WorkDir`/`Command` are. Agents with `scale_check = ".../foo.sh {{.Rig}}/ant"` get the literal `{{.Rig}}` passed to the script, so `bd ready --metadata-field gc.routed_to={{.Rig}}/ant` matches nothing → pool tick returns 0 → pool never spawns.

**Why:** Discovered 2026-04-17 when sw-investigate mol pours never triggered ant spawns despite ready routed beads. Cricket diagnosed via debug log in the script. Upstream bug tracked as bs-sl5 (bug-sherrif rig).

**How to apply:** Local workaround is in `scripts/cross-rig-scale-check.sh` (commit 2fee026): detects literal `{{.Rig}}` in arg and substitutes `basename $PWD` (supervisor sets cwd to rig root for rig-scoped pool agents — see gascity `agentCommandDir` in `cmd_start.go:850`). Remove the shim once gascity fixes template expansion for scale_check. If writing NEW scale_check scripts, either avoid `{{.Rig}}` in agent.toml or include the same cwd-fallback idiom.
