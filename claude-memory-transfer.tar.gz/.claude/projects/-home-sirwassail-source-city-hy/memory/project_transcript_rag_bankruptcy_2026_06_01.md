---
name: project-transcript-rag-bankruptcy-2026-06-01
description: transcript-rag was reset to a clean slate at public launch (2026-06-01); where the recovery archive lives and how to restore
metadata: 
  node_type: memory
  type: project
  originSessionId: 460ca172-d5c8-43ff-9394-5da719a6640a
---

2026-06-01: Declared "bankruptcy" on the transcript-rag corpus at public
feature launch — full reset to focus on post-launch issues. Wiped local
findings (83), transcripts (1,127), 10 eval_runs, the 47M Chroma index,
topics + handoffs + project_ids; reset the ingest cursor to
`2026-06-01T00:00:00Z` so the next `./ingest.py` builds a fresh post-launch
index. Archived all 61 Notion rows to trash (DB + schema + shared page kept;
next `sync_notion.py` repopulates cleanly).

**Recovery (if Eric asks for old data back):**
- Full local snapshot: `~/transcript-rag-archive/transcript-rag-bankruptcy-2026-06-01.zip`
  (32M, verified). `unzip … -d .claude/skills/transcript-rag/` restores
  `data/` + `chroma_data/` 1:1. MANIFEST.txt inside has details.
- Notion rows: recoverable in Notion trash until ~2026-07-01 (30d); after
  that, restore findings.jsonl from the zip + re-run `sync_notion.py`.
- Coworker triage (only 1 row had any: `f-bulk-door-placement-missing`,
  Eric/P0/resolved) is in `notion-findings-export.json` (loose copy in
  `~/transcript-rag-archive/staging/` and inside the zip).

Tooling added: `.claude/skills/transcript-rag/bankruptcy.py` (export/scrub
subcommands, reuses sync_notion's `notion()`/`load_env()`). Left untracked —
Eric had in-progress edits to the other skill `.py` files; mayor touched none
of them. See [[reference_crew_overlay_rig_claude_clobber]] for the skill's
city-planner-persona context.
