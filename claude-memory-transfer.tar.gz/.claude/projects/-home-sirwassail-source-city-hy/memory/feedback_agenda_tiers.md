---
name: Agenda Project vs Infra tiers
description: Agenda has two tiers — Projects (any tracked item) and Infra (city-down work); Bites and Backlog removed 2026-04-22
type: feedback
originSessionId: 27beb5ca-baa1-47bd-af92-8cb6f90398c0
---
`agenda-state.md` has two tiers as of 2026-04-22:

- **Projects** — anything Eric wants tracked that isn't a closed bead. Multi-session by default; a one-liner is also fine if he wants it held.
- **Infra** — work that should be done **when the city is stopped** (schema migrations, config refactors, restart-scoped hook wiring). `gc-update` reads this section during its shutdown window.

The former **Bites** (quick knock-out tasks) and **Backlog** (rig-scoped ideas) tiers are gone. Open Bites were promoted to Projects; rig-scoped ideas now dispatch immediately to a crew agent (or die), rather than accumulating in a holding pen.

**Why:** Eric collapsed the taxonomy on 2026-04-22 (agenda item "Collapse agenda taxonomy to Projects + Infra only"). Four tiers created triage friction and encouraged hoarding — Bites stayed open for weeks, Backlog items rarely dispatched. Two tiers force a decision: is this something I'm actually going to do, or is it going to a rig?

**How to apply:**
- When Eric adds an item without specifying tier, infer: city-down/restart-scoped → Infra; everything else → Project.
- If he frames something as "a quick thing" or "just a bite", add it to Projects anyway — the size distinction no longer exists.
- If he mentions a rig-scoped idea, prompt to dispatch via `/sw-agenda send X to <agent>` rather than holding it.
- The lookout compose UI (`lookout/internal/ui/inbox.go`) matches — tier toggle is project↔infra, mutually exclusive.
