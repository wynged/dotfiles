---
name: Named agents don't use bead routing OR assignee
description: Don't set gc.routed_to metadata or assignee on focus/closeout/epic beads aimed at named crew — just mail/nudge them to /focus
type: feedback
originSessionId: 60e5c2d9-1a8d-45c4-9096-35687d7f73c9
---
When dispatching work to named crew agents (utz, frito, dorito, combo, cheezeit, kettle, bugle, taki, funyun, cricket, etc.), do NOT use `bd update --set-metadata gc.routed_to=...` and do NOT set `assignee=<crew>` on focus/closeout/epic beads. Use `gc mail send` + `gc session submit` to deliver a pointer to `/sw-focus <epic-id>`.

**Why:** Both `gc.routed_to` and `assignee` feed the dispatch/reconciler loops. For on_demand crew, an in_progress bead with `assignee=pringle/<crew>` keeps respawning the session even after the pane is closed — the reconciler sees outstanding work owed and brings the agent back. Designed for ant pools (ephemeral workers), not named agents who manage their own focus. (Concrete case 2026-05-05: `pr-2q2s.1` closeout was assignee=pringle/kettle — kettle kept respawning every time Eric closed its pane until assignee was cleared.)

**How to apply:** In the `/sw-agenda send` flow and any other named-crew dispatch, use `gc session submit <agent> "msg"` (default intent) rather than `gc session wake + gc session nudge`. Submit handles all three session states transparently. For long-running focus beads (epics, closeouts that span many sessions), keep `assignee` empty — the agent's prompt + worktree branch + hooked-bead UI is the link, not the bead's assignee field. Only use `gc sling` / `gc.routed_to` / pool-shaped assignees for ant pool workers.
