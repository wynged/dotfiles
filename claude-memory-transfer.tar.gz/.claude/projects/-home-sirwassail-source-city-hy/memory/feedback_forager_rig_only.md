---
name: feedback-forager-rig-only
description: "Foragers can only do RIG code work (pringle/parcel/etc app code), not city-level work (scripts, skills, orders, agent config, .claude/ overlays). Don't propose dispatching city-level items to foragers."
metadata: 
  node_type: memory
  type: feedback
  originSessionId: d985a974-6113-4814-b7f7-b5a4b71b3cc3
---

Foragers (the sw-forage pipeline) can only do RIG code work — Hypar app code on pringle, parcel, etc. They cannot do CITY-level work: scripts under city_hy/scripts/, .claude/skills/, orders/*.toml, agent config, gascity wrappers, or anything else that lives in the city repo itself.

**Why:** Forager workers branch off main on their assigned rig (pringle by default), run rig-scoped test plans, and produce PRs targeting that rig. The city repo isn't a rig, isn't in their workspace, and doesn't have the same review/test loop. Discovered 2026-05-26 during agenda triage when I proposed dispatching ch-jejm (start-project.sh fix), ch-d81 (BS scan pull), ch-x9rb (hall pane keybinding), and ch-5hy2 (parcel build/deploy skill defaults) as forager work — Eric flagged that all 4 are city-level even though ch-5hy2 names a rig.

**How to apply:**
- Before proposing forager dispatch, check WHERE the change would land. If the path is under `/home/sirwassail/source/city_hy/`, `/home/sirwassail/source/gascity/`, `~/.claude/`, or `.gc/system/packs/`, it's NOT forager work.
- Skills targeting a rig (e.g., "the parcel build/deploy skill") are still city-level if the skill lives in city_hy/.claude/skills/ or an overlay — the rig name in the title is misleading.
- Forager work = touching the rig's own application code (TypeScript/Go/etc in the rig repo).
- For city-level work, the mayor (or a city-scoped agent like cricket) does it directly, or it stays on the agenda waiting for Eric.

Related: [[reference_pringle_unit_wrappers]] (rig-side fix pattern), [[project_reviewer_pool_per_rig]] (per-rig vs city-scoped distinction).
