---
name: Lookout has its own city.toml parser
description: lookout/internal/hall/hall.go::readConfigured is a hand-rolled state machine — schema changes to [[named_session]] need lookout-side updates too.
type: reference
originSessionId: cc895f64-7a7d-41f9-a989-7e7566f534d3
---
Lookout (`/home/sirwassail/source/city_hy/lookout/`) doesn't use the gascity
config library. `internal/hall/hall.go::readConfigured` is a hand-rolled
key=value state machine that recognizes only specific fields on
`[[named_session]]` blocks. As of post-ch-9b1, it understands:

- `name` (Session 30 — added to support shared-template named_sessions)
- `template`
- `dir`
- `mode`

Anything else gets ignored. So when the city.toml schema for `[[named_session]]`
grows a new field that lookout needs to display or filter on, you have to
patch the parser explicitly.

**How to apply:** When changing `[[named_session]]` shape in city.toml,
search `lookout/internal/hall/hall.go` for `readConfigured` and confirm
the new field is being read. Build with `go build -o lookout .` from
`lookout/`, kill the running lookout pane (`pkill -f
"[l]ookout/lookout --mode=dashboard"`), the `while true; do …` wrapper
restarts it on the new binary within ~2s. Tests at
`internal/hall/hall_test.go`.

**Why:** Lookout is in-tree (not a remote dependency) and intentionally
parser-light to stay snappy. Until that changes, schema drift = manual
parser sync.

Companion: lookout's awake-state source is now `tmux list-sessions` only
(the `gc session list` call was retired in Session 32 — see
[hall-tmux-only-awake-detection](project_hall_tmux_only.md)). `main.go`
defaults `GC_TMUX_SOCKET` to `basename(--city)` when unset so the tmux
read works regardless of launch context.
