---
name: project-focus-link-agent-keyed
description: "2026-05-26 — `.bead-projects/` store re-keyed from branch-slug to agent-id (`<rig>__<crew>`); `link-project.sh --show` is now exit-0-always with structured eval-friendly output; lookout focus cache derives from agent key"
metadata: 
  node_type: memory
  type: project
  originSessionId: 5be2c26b-2f7c-49c9-ab73-7ec6bbb923fd
---

The branch→epic link store at `<city-root>/.bead-projects/` was re-keyed from `<branch-slug>` (e.g. `fix-zoom-extents-hidden-tab`) to `<rig>__<crew>` (e.g. `pringle__taki`). `$GC_AGENT` is the authoritative identity; an agent's focus persists across branch flips.

**Why:** Branch-keying meant agent focus reset on every branch flip and the agent statusline (per-`<rig>__<crew>` cache file) was just a derived view of branch-keyed state — two-layer mental model for one piece of data. Eric preferred a model where focus tracks the agent identity.

**How to apply:**
- `scripts/link-project.sh --show` now always exits 0 with `AGENT=`, `BRANCH=`, and (when linked) `EPIC_ID=` lines. Eval-friendly. Only real errors (no `$GC_AGENT` for link/unlink, unknown flag) are non-zero.
- Caller pattern is `eval "$(... --show)"; if [ -n "${EPIC_ID:-}" ]; then ...`. The old `if LINK=$(... 2>/dev/null); then` exit-code pattern was replaced in `overlays/{crew,crew-hypar-insights}/.claude/commands/{pr.md,sw-review.md}`; the buggy `... | awk '{print $NF}'` pattern in 5 `sw-focus.md` copies was replaced with eval too.
- `lookout/internal/focus/focus.go` reads `<beadProjects>/<rig>__<crew>` directly (no git lookup). Both `/home/sirwassail/source/city_hy/lookout/lookout` and `/home/sirwassail/go/bin/lookout` were rebuilt.
- Migration: 7 active worktrees were migrated via `scripts/migrate-link-project-keys.sh` (one-shot, idempotent). 20 legacy branch-keyed files archived to `.bead-projects/_legacy-branch/`.
- Overlay refresh gap ([[project_overlay_refresh_gap]]) means existing crew worktrees still hold the old slash-command code until session-reset; the new `--show` is backward-compatible enough (exit-0 + same eval output shape for linked agents) that it doesn't break them.
- Multiple agents can point at the same epic — same as before, just keyed differently.
