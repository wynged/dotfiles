---
name: Distillery system — status and next steps
description: Self-improvement pipeline for city_hy. Collectors gather signals, /distill analyzes and proposes changes. Tracks what's built, what's pending, and how to run it.
type: project
---

The distillery (`_distillery/`) is a self-improvement pipeline. The city planner owns it.

## What's built (2026-04-04)

- `collect-conversations.py` — extracts human messages from `~/.claude/projects/` JSONL logs. Filters automated injections. Supports `--rig`, `--since`, `--stats`. Watermarks in `state/conversations.json`.
- `collect-pr-comments.py` — pulls PR review comments via `gh api`. Supports `--mine` (Eric's PRs, deep) vs `--all` (colleagues, skim). Requires `gh auth`. Watermarks in `state/pr-comments.json`.
- `/distill` slash command — reads intake, spawns 3 sonnet subagents for batch analysis if above threshold (200 msgs / 500K chars), synthesizes themes, writes digest to `digests/`.
- Intake is gitignored. State files and digests are committed.

## Current state

- Conversation intake populated: 1,331 messages, 3.3M chars, 362 sessions across all pringle crew (Gastown + GasCity eras).
- PR comment intake: NOT YET RUN — Eric needs to `gh auth login` first.
- No digest produced yet. `/distill` has not been run.

## Next steps

1. Eric runs `gh auth login -h github.com` to fix expired token
2. Run `python3 _distillery/collect-pr-comments.py --repo hypar-io/pringle --since 2026-01-01`
3. Run `/distill` to produce first digest — iterate on quality
4. Future: `collect-ci-failures.py` (CI/lint failure patterns from `gh` check data)
5. Future: expand to non-pringle rigs (bug_sherrif, api, classroom)
6. Future: scheduled distill cycles (weekly?)

**Why:** Agents make the same mistakes repeatedly. Reviewers catch the same issues. Eric gives the same corrections. The distillery closes this loop by mining those signals and proposing prompt/config/tooling changes.

**How to apply:** When Eric says "distill" or asks about self-improvement, this is the system. Run collectors first, then `/distill`. The city planner stays in the driver's seat — never auto-apply changes.
