---
name: PR-watch session management
description: How to start/restart the pw tmux session correctly — use pw-window.sh, not manual tmux commands
type: reference
---

The `pw` (pr-watch) session is managed by `scripts/pw-window.sh`, which is a mayor `session_live` hook.

**To start/restart pw correctly:**
```bash
/home/sirwassail/source/city_hy/scripts/pw-window.sh /home/sirwassail/source/city_hy
```

**Why not manual `tmux new-session`:**
- `pw-window.sh` uses `GC_TMUX_SOCKET` to put pw on the correct tmux server alongside agent sessions
- Manual `tmux` commands may target the wrong server (e.g. `tmux -L gascity` vs default)
- The script is idempotent — safe to re-run, skips if pw already exists

**How it auto-starts:**
- Listed in mayor's `session_live` in `city.toml` (line 56)
- Fires on mayor session start and on config reload
- If pw dies mid-session, it won't come back until mayor restarts or config changes

**Current socket situation:**
- `GC_TMUX_SOCKET` is unset in this city, so all sessions (agents + pw) live on the default tmux server
