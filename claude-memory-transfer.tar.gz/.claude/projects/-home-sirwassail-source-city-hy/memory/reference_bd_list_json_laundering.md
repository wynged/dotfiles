---
name: bd list --json laundering for jq
description: bd list --json embeds raw newlines and tabs inside string fields; pipe through python3 json.loads(strict=False) to launder before jq
type: reference
originSessionId: 31f0bb5d-d624-42d3-af9e-57162c2f753e
---
`bd list --json` (and likely other bd JSON commands) embed raw `\n`, `\t`, and
other low control chars *inside* JSON string values. This is technically invalid
JSON; `jq` rejects it with "Invalid string: control characters from U+0000
through U+001F must be escaped".

**Wrong workarounds:**
- `tr -d '\000-\037'` — strips newlines/tabs that may be inside string content
  (corrupts data) AND keeps the rest, so jq still rejects.
- `tr -d '\000-\010\013\014\016-\037'` — keeps `\t \n \r`, jq still rejects
  because raw `\n` in a string is invalid JSON.

**Right workaround:** Python's lenient parse + strict re-emit:
```bash
bd list --status=open --json \
  | python3 -c "import json,sys; print(json.dumps(json.loads(sys.stdin.read(), strict=False)))" \
  > snapshot.json
```
`json.loads(..., strict=False)` accepts raw control chars in strings;
`json.dumps` re-emits with proper `\\n`/`\\t` escaping. Output is valid JSON
that `jq` parses cleanly.

**Use when:** any bd JSON output is going through jq. Survey scripts that pipe
`bd list --json | jq` silently drop output without this.

**Companion bug:** big JSON in bash `$VAR` round-tripped through `echo` corrupts
backslash escapes. Always have jq read from a temp file, not from `$(jq ...)`
captured into a var. Per-entity jq calls re-reading the same temp file are still
sub-second (29 epics × ~20ms = 0.6s in practice).

Filed upstream-needed: bd should escape control chars in `--json` output.
