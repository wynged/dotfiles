---
name: Formula storage and discovery
description: Where formulas live in city_hy, how gc start propagates to rig bead stores so bd finds them, and troubleshooting checklist when a formula isn't found
type: reference
originSessionId: 8e315603-9af9-4378-925f-f3d61fb42acc
---
**Canonical spot for city-owned formulas:** `city_hy/formulas/` (set by `[formulas] dir = "formulas"` in city.toml). This is the city-local layer in gascity's formula search path.

**The actual gc→bd bridge** (corrected understanding from 2026-04-12 smoketest):

bd has no knowledge of layered search paths. Each rig has its own bd database with its own search path. **`gc start` runs `ResolveFormulas`** (`gascity/cmd/gc/formula_resolve.go:20-82`, called from `cmd/gc/cmd_start.go:449-462`) which walks the gascity layers and **symlinks resolved formulas into EVERY rig's `.beads/formulas/` directory**, with the symlink target pointing back at `city_hy/formulas/<name>.formula.toml`.

So the working flow is:
1. Drop a `.formula.toml` file in `city_hy/formulas/`
2. Run `gc start` (or restart)
3. Symlinks appear at `<rig>/.beads/formulas/<name>.formula.toml` for **every** rig under the city — verified with smoketest at pringle and bug-sherrif
4. Agents on those rigs run `bd mol wisp <name>` and bd finds it via the rig's own search path

**The dead `city_hy/.beads/formulas/` directory:** also gets auto-symlinked by `gc start`, but bd from the city root does NOT read it. bd from `city_hy` looks at `<dbroot>/.beads/formulas/` (e.g. `city_hy/.beads/dolt/ch/.beads/formulas/`) — a path deep inside the dolt store, which is empty in normal operation. The `city_hy/.beads/formulas/` symlinks may be load-bearing for some other gascity component or vestigial. Don't put anything there manually.

**Layer order in gascity** (higher priority wins on name collision):
1. Pack formulas (`packs/*/formulas/`, from `[workspace] includes`)
2. City-local (`city_hy/formulas/`)
3. Rig pack formulas
4. Rig-local `formulas_dir` override

A formula in `city_hy/formulas/` shadows a same-named one in any pack.

**Anti-pattern:** hand-placing real files in `<rig>/.beads/formulas/` or `city_hy/.beads/formulas/`. Real files shadow the auto-symlinks `gc start` would create, don't update when the source changes, and have to be repeated for every rig. The fix is always: put the file in `city_hy/formulas/`, run `gc start`, delete any pre-existing real-file shadows so the new symlinks can take over.

**Troubleshooting checklist:**
1. `gc formula list` — does gascity see it? If yes, the rig propagation is the problem. If no, the file is outside the gascity search path.
2. `ls -la <rig>/.beads/formulas/<name>.formula.toml` — symlink back to `city_hy/formulas/`? If real file, hand-placement is shadowing the auto-symlink. If missing, the formula isn't in any layer that propagates.
3. Did `gc start` run after the file was added? `ResolveFormulas` only fires at start time, not on file change.
4. `gc formula show <name>` to see which file resolves and surface TOML parse errors.
5. `bd mol wisp` doesn't set the top-level `formula` field — set it manually with `--set-metadata formula=<name>` if downstream code needs it.
6. **Wrong bd context:** bd's search path depends on which `.beads` dir is active (cwd or `BEADS_DIR`). Running bd from the city root uses a weird search path deep in the dolt store. Agents tied to a rig get the sane `<rig>/.beads/formulas/` path.

**Smoketest verified 2026-04-12:** dropped `mol-sw-smoketest.formula.toml` in `city_hy/formulas/`, ran `gc start`, verified symlinks appeared in both `pringle/.beads/formulas/` and `bug-sherrif/.beads/formulas/` immediately. The `city_hy/.beads/formulas/` symlink also got created but is unused by bd.

**Full reference:** `_gascity_howto/04-formulas-molecules.md` — updated 2026-04-12 with corrected understanding. Prior version (and prior version of this memory) incorrectly claimed `gc start` symlinks into `city_hy/.beads/formulas/` as the bridge for bd.
