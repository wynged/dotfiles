---
name: project-sw-issue-radar
description: "sw-issue-radar skill — ingests hypar-io/pringle issues, hybrid-triage (batched + deepdive), surfaces a review queue, hands off to sw-forage. State-backed, local-only, hooked into sw-morning-routine step 4."
metadata: 
  node_type: memory
  type: project
  originSessionId: 26565fca-2f29-4133-809e-dee2b1999ded
---

Built 2026-05-15 (ch-nr068). New GitHub-issue input to the [[project-distillery]]
forage pipeline.

Located at `.claude/skills/sw-issue-radar/` in city_hy. Five Python entry
points (`ingest`, `triage`, `deepdive`, `review`, `dispatch`) backed by
JSONL state under `data/` (gitignored).

**Why:** Eric wanted a state-backed issue triage skill modeled on
[[project-distillery]]/transcript-rag — no rescanning, agent-reviewed,
prioritized by both eric_role (assigned/authored = special) and complexity
(easy = forager-ready). Items he promotes become forage-request beads via
the existing `sw-forage` dispatch path. v1 scope is `hypar-io/pringle` only.

**How to apply:**
- Trigger phrases include "issue radar", "what issues should we look at",
  "scan issues", "any easy issues", "show me my open issues".
- Hybrid eval: `triage.py new` builds batches → mayor dispatches parallel
  subagents → `triage.py extract`. Anything tagged `maybe` flows into
  `deepdive.py` (per-issue, reads pringle worktree for tiebreaker).
- Review surface is `review.py` (default tri-section: Mine / Ready /
  Maybe). `dispatch.py send <number>` files a forage-request and routes
  via `scripts/sw-forage.sh dispatch`.
- Morning routine step 4 is **ingest only** — keeps the routine fast.
  Triage fanout is opt-in.
- Local-only by design: never writes back to GitHub. Forage-request bead
  body explicitly tells the forager not to comment on or close the issue.

**Schema:** `issues.jsonl` (one row per known issue, upsert by
`<repo>#<num>`), `evaluations.jsonl` (append-only, one row per verdict per
pass per run; `pass∈{triage,deepdive}`), `decisions.jsonl` (append-only,
one row per Eric action: dispatched/skipped/deferred).

**To expand beyond pringle:** ingest takes `--repo`, but `dispatch.py`
currently assumes `pringle/forager`. Needs a small rig-routing pass for a
multi-rig v2 (e.g. Elements issues → an Elements forager pool, if one
exists).

**First-pass triage 2026-05-15** (143 open pringle issues, 9 parallel
sonnet subagents, batch-size 15): 6 ready, 74 maybe, 32 hard, 22 skip,
11 touching Eric.

Related: [[reference-sw-forage]], [[project-distillery]].
