---
name: gc handoff is the comm channel (on_demand)
description: For on_demand named sessions, gc handoff is just mail-to-self; the cycle is now lookout handoff
type: reference
originSessionId: 1b2fd6e8-23b9-4125-a907-ac036014bd28
---
For `mode = on_demand` named sessions, `gc handoff <subj> <body>` is functionally just `gc mail send $GC_ALIAS <subj> <body>`. The restart side is a deliberate no-op — the controller refuses to kill a user-attended process.

It's still the right verb to use in /sw-handoff because the fresh session reads inbox on wake (wake_mode: fresh) and the handoff mail is what carries state across the cycle.

Pair with `lookout handoff <agent>` (added 2026-04-29, ch-wn2w) which schedules a deferred `gc session kill` so the cycle actually happens. Need both:
- `gc handoff` = message delivered to next session.
- `lookout handoff` = the cycle that lets the next session exist to read it.

For controller-restartable sessions (always), `gc handoff` still also calls `gc runtime request-restart`, so the same line stays correct in the skill regardless of mode.
