---
name: Skills files must be crew-agnostic
description: Files under .claude/skills/ should not name specific crew members (cheezeit, utz, frito, etc.) — skills must work for any crew
type: feedback
originSessionId: a32c23c3-7e12-469f-995f-560f5cde6ea6
---
Skill files under `.claude/skills/` (e.g. `sw-probe-batch/SKILL.md`) must NOT
reference specific crew member names like `cheezeit`, `utz`, `frito`. Skills
are city-level and should work regardless of which crew the city is running.

**Why:** Skills get copied/used across cities and crews. Baking in a name
strands the skill if the crew roster changes or another city wants to adopt
it. Crew identity should come from city.toml / domain lookups, not skill text.

**How to apply:** When editing anything under `.claude/skills/`:
- Replace specific agent names with generic phrasing ("the assigned crew
  member", "the probe assignee", "the agent", etc.)
- Route rig/agent specifics through `domain_defaults` in scripts, not prose
- If you find pre-existing references in a file you're editing, strip them
  in the same pass rather than leaving them

Discovered 2026-04-13 when I added cheezeit references to sw-probe-batch
SKILL.md during the probe-infra refactor and Eric rejected the edit.
