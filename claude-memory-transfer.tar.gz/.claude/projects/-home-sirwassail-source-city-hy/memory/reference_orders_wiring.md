---
name: Wiring city-owned orders
description: Drop flat orders/<name>.toml + scripts/<name>.sh at city_hy root; do not use a pack or gc import (shadow conflict trap)
type: reference
originSessionId: ca68d9cd-4d01-4692-92cc-3d0e3f7538e6
---
City-owned scheduled/event-driven jobs go in **flat files at the city root**:

- `city_hy/orders/<name>.toml` — order definition
- `city_hy/scripts/<name>.sh` — exec script (referenced via `$GC_CITY_PATH/scripts/<name>.sh`)

Auto-discovered by `gc order list` on every invocation — no reload needed for new files. Verify with `gc order show <name>` (prints absolute `Source:` path).

**Schema** (matches `orders/beads-row-compact.toml`, `orders/cleanup-order-tracking.toml`, etc.):

```toml
[order]
description = "..."
gate = "cooldown"           # NOTE: `gate` (NOT `trigger`) for cooldown orders
interval = "1h"
exec = "$GC_CITY_PATH/scripts/<name>.sh"
timeout = "60s"             # optional
```

For cron: `trigger = "cron"` + `schedule = "30 5 * * *"`. Cron and cooldown use different field names (`trigger` vs `gate`) at this layer — easy to confuse.

**To skip a misbehaving upstream order without removing it:** add its name to `[orders] skip = [...]` in city.toml.

## Anti-pattern: do NOT wire orders via a pack

Confirmed dead-end Session 33 (2026-05-03):

- `gc auto-includes only `core`, `maintenance`, `bd` (the binary-embedded packs) by name. New packs in `.gc/system/packs/` are NOT auto-discovered.
- `[imports.<name>] source = "..."` in city pack.toml DOES load orders, but it also pulls in *every* pack found under the source's `packs/` directory and re-registers their agents.
- `gc import add <source> --name X` has the same problem — the `--name` flag only labels the import; it does NOT scope which packs from the source get loaded.
- The shadow conflict that follows (`city agent mayor shadows agent of the same name from import sw-housekeeping`) crashes mayor's reconciler within seconds: reap → respawn → fail → repeat, with `gc event emit bead.created/updated` shellouts piling up at ~70% CPU each.

The flat `orders/` route bypasses the import system entirely.

## Worth filing upstream

`gc import add --name X` should actually scope to pack X — currently it imports the whole pack collection at the source path, which is unsafe when the source is the city repo itself (or anything containing other packs).

## Where else this is documented

- `CLAUDE.md` — Orders section, agent-facing summary
- `_gascity_howto/04-formulas-molecules.md` — Order discovery, both layouts
- `_my_city/session-log.md` — Session 33 narrative with full context
- bead `ch-z9dp` (HQ) — original trigger: upstream wisp-compact bug + city-side replacement
