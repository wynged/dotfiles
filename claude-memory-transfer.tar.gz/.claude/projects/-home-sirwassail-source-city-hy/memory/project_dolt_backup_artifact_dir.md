---
name: dolt-backup-artifact-dir
description: "city_hy per-DB Dolt backups — .dolt-backup/ artifact dir, <db>-backup named backups, why mol-dog-doctor floods advisories when it's missing"
metadata: 
  node_type: memory
  type: project
  originSessionId: 7fd897c8-da1b-4e2e-9ffb-eff9fd5f5735
---

2026-05-19 (ch-hkl): the `mol-dog-doctor` order (5m interval) mails a `Dolt health advisory [MEDIUM]` carrying `[WARN: backup artifact dir missing]` whenever `$GC_CITY/.dolt-backup/` lacks fresh per-DB backups. `mol-dog-doctor.sh` and `mol-dog-backup.sh` both default `BACKUP_ARTIFACT_DIR=$GC_CITY_PATH/.dolt-backup`; the doctor mails on *any* warning, so a missing dir = ~288 advisories/day. The dir was never set up — that scheme just hadn't been wired.

**Fix applied:** for each of the 10 user DBs (api,bs,ch,co,el,hc,he,hp,pr,sc) added a named Dolt backup `<db>-backup` → `file://$GC_CITY/.dolt-backup/<db>`, run from inside `.beads/dolt/<db>/` (`dolt backup add`). The `mol-dog-backup` order (6h) auto-discovers any `<db>-backup`-named backup and syncs it; the doctor's freshness threshold is 12h (2× 6h), so the 6h cadence keeps it quiet. `.dolt-backup/` is gitignored; initial size ~74M.

**Benign morning boot-race (2026-05-25):** if the WSL host is off overnight, backups age past the 12h freshness threshold; the doctor (5m) fires a `Dolt health advisory [MEDIUM]` carrying `[WARN: backup freshness: <db> backup is Nh old ...]` within minutes of boot — *before* the controller dispatches the due 6h `mol-dog-backup`. NOT a broken pipeline. Confirm with `gc order check` (shows `mol-dog-backup ... due ... elapsed Nh >= interval 6h`); it self-heals on the next controller tick, or clear immediately with `gc order run mol-dog-backup` (additive, ~0 risk; synced 11/11 here). Distinguish from a *real* failure: an actual sync failure sends a **separate** `Backup dog: N/N databases failed to sync [MEDIUM]` mail. Also note the supervisor's startup timestamp (`systemctl --user show gascity-supervisor.service -p ExecMainStartTimestamp`) — if it's minutes old, the overnight-shutdown story holds.

Key facts:
- The backup name MUST be exactly `<db>-backup` — that's the literal pattern `mol-dog-backup.sh` greps for during discovery. `ch` also keeps its pre-existing `default` backup (the `bd backup` → `.beads/backup`); the other 9 keep a pre-existing `backup_export`.
- **New rigs/DBs are silently NOT backed up.** `mol-dog-backup` auto-discovers by name only — a fresh DB with no `<db>-backup` remote is skipped without warning, and the doctor's freshness advisory lists only DBs it *already* knows, so a never-backed-up DB never even triggers a WARN. 2026-05-24: caught `hi` (hypar-insights, added ~05-22 with the oracle crew) had only a stray `backup_export` → `hypar-insights/.beads/backup` (rig-local, wrong name+path) and zero `.dolt-backup/hi`. Fix = `cd .beads/dolt/hi && dolt backup add hi-backup file:///home/sirwassail/source/city_hy/.dolt-backup/hi && dolt backup sync hi-backup` (unset DOLT_CLI_PASSWORD first — empty string makes dolt demand a --user). **Whenever a rig is added, add its `<db>-backup` remote** or it sits unprotected.
- This is a *separate* scheme from `bd backup` (`.beads/backup`, one combined `.darc` store). Both now exist; `gc dolt health`'s own `backups` probe still reads neither cleanly — the doctor is the check that matters here.
- CLI `dolt backup sync` is a reader of the source repo — distinct from the `DOLT_BACKUP('sync')` SQL-proc writer-race suspected in [[Dolt journal corruption pattern investigation]]. gascity blesses it live on dolt ≥1.86.2 (city is 1.86.5).
- `dolt backup sync` is append-only; `.dolt-backup/` will bloat over weeks like `.beads/backup` once did. `dolt-backup-rotate` (336h order) currently covers only `.beads/backup` — extending it to `.dolt-backup` is a tracked follow-up bead.

Related: [[Dolt journal corruption pattern investigation]], reference_dolt_recovery.md, reference_beads_backup_bloat.md.
