---
name: Leaked dolt test fixtures from bd test suite
description: bd's TestInitBeadsForDirExecPreventsStrayGitInit test leaks dolt sql-server processes — survive parent exit, re-parent to /init, accumulate over days
type: project
originSessionId: 162c3415-8961-4089-b8c0-449a0cf95868
---
bd's test suite contains `TestInitBeadsForDirExecPreventsStrayGitInit*`
which spawns 2 dolt sql-servers per run (in `002/.beads/dolt` and
`003/frontend/.beads/dolt` under a `/tmp/Test...` temp dir). On test
exit, the temp dir is deleted but the dolt processes are NOT killed —
they get re-parented to /init (PID 1 in WSL, the systemd init in pure
Linux) and survive forever, holding open file descriptors on
deleted temp data files.

**Cost (city_hy 2026-05-03):** 10 leaked instances accumulated over 2 days,
each ~1.7% CPU and ~150 MB RSS = **~17% CPU + 1.46 GB RAM combined**.

**Why:** Don't add it to the runbook diagnostic table — it's already there
(see `/sw-dolt-check` §3.13). Just remember **it's a real failure mode**
that masks itself as "many small dolt servers" — easy to dismiss as
intentional rig-local infra. Real rigs (pringle, bug-sherrif, elements)
all share the city's main dolt at port 40014; they don't run their own
sql-servers. So *any* extra `dolt sql-server` PID with `--loglevel=warning`
on `127.0.0.1:4xxxx` is suspect.

**How to apply:** During any "what's running on this machine" sweep,
run the §3.13 cwd-check one-liner. If they keep recurring after `bd test`
runs, file an upstream bd issue — test cleanup should kill its
sql-servers. Until that lands, manual cleanup is the workaround;
periodic order is overkill if Eric isn't running bd tests regularly.

**Killing them is safe** — orphans, no clients, deleted CWDs.
SIGTERM works (no need to escalate to SIGKILL on the city_hy run).
