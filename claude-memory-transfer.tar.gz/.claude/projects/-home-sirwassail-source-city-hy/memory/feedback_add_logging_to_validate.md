---
name: Add logging before assuming a fix works
description: When patching gascity Go code, add log lines to confirm the code path is hit before declaring success
type: feedback
---

When fixing gc daemon behavior, add `log.Printf` or `fmt.Fprintf(stdout, ...)` lines to confirm the patched code is actually running before testing the fix. This session we applied a filter that was correct but wasn't being hit — the binary wasn't swapped in. Logging caught that immediately.

**Why:** We spent time waiting for a fix to take effect when the new binary wasn't even running. The logging also revealed the actual root cause (message beads, not session beads) which was different from our initial hypothesis.

**How to apply:** For any gc daemon change: (1) add diagnostic logging, (2) rebuild, (3) `systemctl --user stop gascity-supervisor && gc start`, (4) check `~/.gc/supervisor.log` for the new log lines before waiting for behavior change.
