---
name: Overlay copy is session-start-only
description: Adding a slash command or settings file to an agent's overlay_dir does NOT propagate to running sessions; recovery is gc session kill (not reset)
type: reference
originSessionId: 31f0bb5d-d624-42d3-af9e-57162c2f753e
---
`Provider.Start` in `gascity/internal/runtime/tmux/adapter.go:64-97` runs
`overlay.CopyDirForProviders(cfg.OverlayDir, cfg.WorkDir, ...)` — but only on
session start. Pack overlays + agent overlay both copy then. After that, the
worktree's `.claude/` is on its own.

**Symptom:** "Unknown command: /<slash>" in a session whose overlay was edited
mid-life. `gc session peek` shows the agent at correct cwd, but
`.claude/commands/` lacks the new file.

**Recovery:**
1. `gc session kill <name>` — full kill, reconciler respawns fresh. Copies the
   current overlay state.
2. **Not** `gc session reset` — that asks for a runtime restart but doesn't
   trigger a fresh Provider.Start in the way that re-runs the overlay copy
   reliably (verified 2026-04-26 with scholar; reset said "active" but command
   still missing).
3. Resubmit the original prompt/order.

**Use when:** any time you edit a file under `overlays/<name>/` and an existing
session needs the change. Crew with worktrees that are days/weeks old won't see
overlay edits until killed.

Until upstream lands a live-reload, both nightly-bs-sweep and daily-learning-brief
slash commands carry a recovery hint at the top: "if you saw 'Unknown command'
instead of this prompt, kill+respawn." Bake the same hint into any new scheduled
slash command.
