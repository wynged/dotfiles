---
name: reference-gascity-worker-boundary
description: gascity worker-boundary import rule + where provider-aware transcript logic belongs
metadata: 
  node_type: memory
  type: reference
  originSessionId: c8d2a587-6fdc-4662-b670-0ab8202fa4cd
---

gascity enforces a "worker boundary": `cmd/gc` **non-test** .go files must NOT import `internal/sessionlog` directly (nor call `session.NewManager*`, `sp.Start(ctx,`, `worker.SessionHandle`, etc.). Enforced by `cmd/gc/worker_boundary_import_test.go` (TestGCNonTestFilesStayOnWorkerBoundary), which greps the forbidden-needle list; **_test.go files are exempt**. Route through `internal/worker` instead (e.g. `worker.DefaultSearchPaths()` re-exports `sessionlog.DefaultSearchPaths()`). Importing `internal/worker/transcript` from cmd/gc IS allowed (not on the list).

Provider-aware transcript logic lives in the **transcript layer**, not high in the start path:
- `internal/worker/transcript/discovery.go` — `DiscoverKeyedPath` / `DiscoverPath` / `SupportsIDLookup` / (added) `HasKeyedTranscript`. Dispatches per provider via `sessionlog.ProviderFamily` (substring match: codex/gemini/kimi/opencode/pi, else the string as-is → claude is the "default").
- `internal/sessionlog` — actual path readers; `ProjectSlug(abs)` maps `/` and `.` → `-` (NOT `_`). kimi/pi readers self-merge their own default roots (`~/.kimi/sessions`, `~/.pi/agent/sessions`) on top of any passed searchPaths, so passing the claude default root is safe for all providers.

Only claude(+claude-eco)/kimi/pi store a session-id-**keyed** transcript whose absence is a reliable stale-resume signal; codex/gemini/opencode discover by cwd/date.

Context: PR #2688 (fix/fresh-wake-skip-stale-session-id) refactor moved its inline claude-specific stale-resume guard from `buildPreparedStartWithWorkDirResolver` into `transcript.HasKeyedTranscript`. Dev on `local-integration` (see [[reference_gascity_local_integration_combo]]), cherry-pick the split commit to the PR branch, push.
