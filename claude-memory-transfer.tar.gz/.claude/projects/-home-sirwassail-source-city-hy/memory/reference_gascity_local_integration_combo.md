---
name: reference-gascity-local-integration-combo
description: "gascity's `local-integration` branch is the \"combo branch\" — merges multiple in-flight fix/perf branches for running locally; develop on it, then split clean fixes to their own carry branch."
metadata: 
  node_type: memory
  type: reference
  originSessionId: e8debaec-ef81-4090-9df7-4c3c08591208
---

`local-integration` in `/home/sirwassail/source/gascity` is Eric's **combo branch** — the running-locally integration of several in-flight gascity fix/perf branches.

**Why:** Eric runs a locally-built `gc` that includes multiple unmerged improvements simultaneously. The combo branch is where they live together so the local build picks up all of them, without coupling the upstream PRs to each other.

**Convention:**
- Merge commits use the message shape `integrate <source-branch>: <bead-id> <short-description>`.
- As of 2026-05-14, `local-integration` carries `caching-store-no-fetch` (ch-1h95) and `pool-work-query-skip-suspended` (ch-68rm) on top of upstream main.
- New fixes get developed *on* `local-integration` so they run alongside the other carries.
- Once a fix proves out, it gets split to its own branch (typically off `main`) so it can be PR'd / pinned independently — the combo branch then re-integrates from that clean branch.

**How to apply:**
- When Eric says "develop on the combo branch", base work on `local-integration`.
- When splitting a passing fix out, branch from `main`, cherry-pick the fix-only commits, then `git merge` the new branch back into `local-integration` with an `integrate <branch>: ...` merge commit.
- Check the latest commit history on `local-integration` to see which carries are currently active before starting work.

Related: [[project_pringle_rl_loop]] (similar local-only carry pattern).
