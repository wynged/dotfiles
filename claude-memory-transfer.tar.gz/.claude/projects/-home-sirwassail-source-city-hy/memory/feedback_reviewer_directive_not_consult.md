---
name: Reviewer-crew — Eric flagging an issue is a directive, not a consultation
description: When crew operates as reviewer of forager output and Eric says something is wrong, treat it as a work request — fix it directly. Don't ask whether to make the PR or file a follow-up bead.
type: feedback
originSessionId: 432abdc5-c30f-4c05-a51f-526c97b47d90
---
When a crew agent is operating as the reviewer of forager output (e.g. via `/sw-forage-review`) and Eric flags an issue with what the forager produced ("this is wrong", "X doesn't work", "that approach won't fly"), treat it as a directive to do the work. Craft the PR, push the fix, do the follow-up. Do **not** ask "should I make a follow-up bead?" or "do you want me to open a PR?" or otherwise punt the obvious next step back to Eric.

**Why:** The forager pipeline is intentionally designed to keep Eric in the loop *at the right review moments* — well-set-up to review the actual question. Once Eric has spoken, the crew is still expected to craft PRs and execute follow-ups; that's the whole point of the reviewer role. Asking him again whether to act defeats the pipeline's purpose and turns review moments into noise. Eric noticed crew "keeps doing this" — asking for permission on the obvious next step.

**How to apply:** In any reviewer-role flow where Eric points out a problem with the forager's work:
- Treat the comment as a work order, not a triage prompt
- Make the fix on the existing branch (or open the PR if needed)
- Do follow-ups (additional commits, related bead filings) without re-prompting
- Mail the mayor only on completion, or if the ask is genuinely ambiguous
- The bar for "ambiguous enough to ask" is high — if there's an obvious interpretation, just do it
