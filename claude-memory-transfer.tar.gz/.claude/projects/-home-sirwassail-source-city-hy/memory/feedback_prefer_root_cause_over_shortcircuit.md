---
name: Prefer root-cause replacement over layered short-circuit
description: For perf optimizations that have a "fast pre-check + slow main path" shape, prefer replacing the slow path entirely when discriminator gating is clean
type: feedback
originSessionId: 91873b7f-8e7a-40ae-9b8b-25ece5aa8347
---
When optimizing a hot path, prefer collapsing it to one well-discriminated implementation rather than layering a short-circuit pre-check on top of the existing slow path.

**Why:** Short-circuits introduce a second source of truth (the pre-check's view vs the main path's view) which can drift, and they typically need their own correctness gating (e.g. override discriminator, snapshot freshness). When the discriminator is already clean — "user-supplied override = slow shell path, empty = fast in-process path" — splitting at that discriminator once is cleaner than splitting twice (once for the short-circuit, once for the main path). One rule beats two.

**How to apply:** In a staged perf plan with a "Stage 1: short-circuit, low risk" and "Stage 2: replace default path", lean toward going straight to Stage 2 if (a) the discriminator for who gets the fast path is the same in both stages, and (b) the fast path's logic is stable enough that re-implementing it doesn't create a maintenance treadmill. The short-circuit is the right answer only when the slow path itself can't be replaced (external dependency, unknown semantics, etc.). Origin: ch-b9q work_query design 2026-05-01 — Eric: "the short-circuit doesn't feel appropriate."
