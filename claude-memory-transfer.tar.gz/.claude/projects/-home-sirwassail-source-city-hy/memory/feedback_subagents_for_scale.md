---
name: Use subagents for large-scale analysis
description: Eric wants sonnet subagents used for batch processing when data is too large for one context. Planner orchestrates and ensures completion.
type: feedback
---

When analyzing large volumes of data (conversation history, PR comments), use a sensible number of sonnet subagents (~3) to process batches in parallel. The city planner orchestrates — spawns them, waits for all to complete, then synthesizes results.

**Why:** Eric explicitly asked for this pattern. 1,300+ messages / 3.3M chars is too much for one pass. Subagents parallelize the first-pass classification, planner does the synthesis.

**How to apply:** The `/distill` command already implements this. For any future analysis at scale (new collectors, expanded rigs), follow the same pattern: chunk data, parallel subagents, synthesize.
