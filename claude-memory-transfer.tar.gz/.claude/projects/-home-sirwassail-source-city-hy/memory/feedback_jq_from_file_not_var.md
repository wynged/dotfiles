---
name: Read big JSON into jq from file, not a bash variable
description: $(jq …) captured into bash var and echoed back to jq corrupts backslash escapes; always read from temp file
type: feedback
originSessionId: 31f0bb5d-d624-42d3-af9e-57162c2f753e
---
Big JSON stored in a bash `$VAR` and echoed back into jq corrupts backslash
escapes. Symptom: `jq: parse error: Invalid string: control characters …` even
when the file the JSON came from parses fine directly.

Cause: bash echo (and parameter expansion in some contexts) interprets / rewrites
backslash sequences in long strings, especially when the JSON string fields
contain `\n`/`\t` patterns.

**Wrong:**
```bash
CHILDREN=$(jq -c --arg p "$EPIC" '[.[] | select(.parent == $p)]' "$SNAP")
OPEN=$(echo "$CHILDREN" | jq '[.[] | select(.status == "open")] | length')
```

**Right:** have each jq call read the snapshot file directly. Even with N epics,
that's N × ~20ms = sub-second:
```bash
while read EPIC; do
  jq -r --arg p "$EPIC" '
    [.[] | select(.parent == $p)] as $kids
    | …
  ' "$SNAP"
done < <(jq -r '.[] | select(...) | .id' "$SNAP")
```

**Why:** Discovered 2026-04-26 while rewriting `/sw-nightly-sweep` Phase 4. Spent
a full debug cycle on "jq says control chars at line 201" before realizing the
file was 1 line and the corruption happened during shell variable round-trip.

**How to apply:** when filtering big JSON across N entities, write the snapshot
to a temp file and have each filter call read the file. Don't optimize by
caching jq output in a var.
