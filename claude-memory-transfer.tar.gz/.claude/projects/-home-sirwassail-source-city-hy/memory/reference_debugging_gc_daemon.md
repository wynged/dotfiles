---
name: Debugging the gc daemon
description: Where gc daemon logs go, how to validate code changes are running, and restart gotchas
type: reference
originSessionId: b8556ed8-f455-47ec-a857-9894b7cd9ed0
---
- **Supervisor log**: `~/.gc/supervisor.log` — all daemon stdout/stderr goes here (not journalctl). Search for specific prefixes like `idle-nudge:`, `namedWorkReady:`, `poolDesired:`.
- **Validating a rebuilt binary is active**: `strings /home/sirwassail/go/bin/gc | grep "your log string"` confirms the binary contains your changes. But the daemon may still be running the old binary.
- **Restart gotcha**: `gc stop && gc start` doesn't always kill the old supervisor process. Systemd may keep it alive or restart it before the new `gc start` runs. Use `systemctl --user stop gascity-supervisor` then `gc start` for a clean swap.
- **bd list vs daemon view**: `bd list` from the city directory may not show all beads the daemon sees. The daemon queries multiple stores (city + rigs) via `collectAssignedWorkBeads`. Whisper/message beads (`ch-wisp-*`) show up there but not always in local `bd list`.
- **Soft circuit breaker (gc ≥ v0.14.1)**: `gc halt` writes `.gc/runtime/halt`; the reconciler tick checks this flag at the very start of every iteration and skips tick work when present. `gc resume` removes it. Idempotent. `gc status` reports `Halted: yes|no`. Verified working 2026-04-13. Use this for *investigation* (stop the reconciler without killing the process so you can inspect state). For *recovery from real corruption*, still do a full stop — `gc stop && systemctl --user stop gascity-supervisor && gc start` — because halt only pauses the tick, not any in-flight dolt handles.
