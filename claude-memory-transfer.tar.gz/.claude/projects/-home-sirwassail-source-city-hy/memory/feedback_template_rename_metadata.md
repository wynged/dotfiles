---
name: Template-rename leaves stale bead metadata
description: When a gascity agent template gets renamed/replaced, existing session beads carry stale `template:` metadata across — patch in place, don't try `bd close` to reset.
type: feedback
originSessionId: cc895f64-7a7d-41f9-a989-7e7566f534d3
---
When you rename or collapse gascity agent templates (e.g. ch-9b1 collapsing
14 per-crew templates onto a shared `crew` template), pre-existing session
beads keep their old `template:` metadata indefinitely. The supervisor's
canonical-bead matcher (`internal/session/named_config.go::FindCanonicalNamedSessionBead`)
keys on `configured_named_identity`, NOT `template`, so wake/dispatch keep
working — but `gc session list`'s TEMPLATE column shows the dead name and
will mislead future debugging.

**Why:** session bead metadata is stamped at create time. The `template`
field is informational on revived beads.

**How to apply:**

- Don't try `bd close <id>` to "reset" the bead — supervisor's
  `findClosedNamedSessionBead` (`cmd/gc/named_sessions.go:69`) revives it
  for continuity, preserving the stale metadata.
- The clean fix is in-place: `bd update <id> --set-metadata template=<new>`
  for each affected bead. Loop over the stale ones once after the refactor.
- Newly-minted beads (no prior bead for that named_session) stamp correctly
  on first creation, so only beads that survived the refactor need patching.
- Verification: `bd show <id> | grep template:` should show the new name;
  `gc session list` will reflect it within one reconcile cycle.

**Affects work_dir too, not just template (2026-05-04):**
Same pattern hit `pringle/cheezeit` (ch-bhet) — bead's `work_dir` metadata
was baked when the alias was still `pringle/crew` (pre-rename), pointed at
`.gc/worktrees/pringle/crew` (a stale legacy worktree on `gc-crew-*` branch).
The named session kept spawning Claude in the wrong dir even though the
template's `work_dir = ".gc/worktrees/{{.Rig}}/{{.AgentBase}}"` would have
expanded correctly. `alias_history: pringle/crew` on the bead is the tell.

Recovery, in order:
1. `bd update <id> --set-metadata work_dir=<correct path>` — but this
   commonly trips config-drift detection and the patrol auto-closes the
   bead with `close_reason: stale-session` within ~1 minute. The tmux pane
   is killed; whatever Claude was doing in there is gone.
2. After auto-close, the bead still owns the `session_name` slot
   (e.g. `pringle--cheezeit`), blocking respawn. Clear it:
   `bd update <id> --set-metadata session_name=`
3. `gc session submit <alias> "<msg>"` — supervisor mints a fresh bead
   from current template (correct work_dir) and spawns the pane.
4. If a stale `gc-<old-alias>-*` worktree+branch was the path target, clean
   up: `git -C <rig> worktree remove --force <path>` then
   `git -C <rig> branch -D gc-<old-alias>-*`. Worktree-setup auto-generated
   files like `.mcp.json` are why `worktree remove` (without --force) refuses.

Warn the user before step 1 — they lose any in-flight work in that pane.
