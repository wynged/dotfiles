---
name: Dolt journal corruption pattern investigation
description: Recurring dolt chunk journal corruption — hex-signature analysis confirms concurrent-writer race. Wait-and-see mitigation posture as of 2026-04-12.
type: project
originSessionId: 8e315603-9af9-4378-925f-f3d61fb42acc
---

## 2026-04-12 (Session 20) — hex signature confirms concurrent-writer race

**Smoking gun finding.** Hex dumps of both corrupt journals around their corruption offsets show an **identical structural signature**:

- A 40-byte journal record (header `0x00000028 01010400 00000000 69...`) written **3–4 times consecutively**
- A ~40-byte zero-padded gap between some of the duplicate copies
- Then a new valid record resumes

2026-04-11 offset 22339161: record appears 3× back-to-back, then 40 bytes of 0x00, then valid record.
2026-04-12 offset 1275708894: record appears 2×, then 40 bytes of 0x00, then SAME record 2× more, then valid record.

**This is the fingerprint of a non-atomic concurrent write race.** Multiple writers issuing `write()` at overlapping or past-EOF offsets, with the zero gap characteristic of `seek()` beyond EOF followed by a retried write. Same failure mode in both incidents → one bug, not multiple causes. Rules out random bit-rot, storage damage, and size thresholds. Strongly supports the pre-existing `DOLT_BACKUP('sync')` race hypothesis (hypothesis #3 below).

**Red herring corrected:** handoff claimed a "13× size delta" (1.4G vs 19G corrupt dirs) was a datapoint. It's not — almost all of the 19G is `.dolt_dropped_databases` trash. Actual `ch` databases are 1.3G vs 3.1G, consistent with normal journal growth between incidents.

**Mitigation decision (Eric, 2026-04-12):** Wait-and-see. Do NOT disable auto-sync, do NOT patch bd source, do NOT install lock wrappers yet. Two incidents (plus one earlier on hypar_gt) is suggestive but not urgent given that `bd backup restore` works cleanly each time. Revisit if a 4th incident occurs.

**2026-04-13 update:** gascity PR #567 adds btrfs NOCOW to `.gc/runtime/` to eliminate btrfs-compressed CoW thrash. **Not applicable here** — `stat -f -c %T .gc` reports `ext2/ext3` (WSL2 ext4). The concurrent-writer hypothesis for dolt corruption is independent of filesystem choice; #567 does not address it. City_hy upgraded to gc 0.14.1 + bd 1.0.0 + dolt 1.86.1 without applying any NOCOW retrofit.

**If/when we revisit, mitigation options (ordered cheapest → most invasive):**
1. Disable auto-sync, run manual `bd backup sync` from an off-hours cron. Needs a config key we haven't confirmed exists in bd 0.63.3 — `backup.enabled` exists in the binary strings but behavior unverified.
2. Widen auto-sync interval from 15m to 1h+. Reduces exposure but doesn't eliminate.
3. Wrap `bd` invocations in `flock .beads/bd-write.lock` — serializes cmd-to-cmd but NOT the in-process 15-min timer.
4. Clone `github.com/wynged/beads`, patch `DOLT_BACKUP('sync')` to take a mutex, rebuild. Real fix, ~1-2 hours.
5. File upstream dolt issue with the hex signature — it's distinctive enough that the dolt team will recognize it fast.

**Forensic dirs deleted 2026-04-12** (after signature extraction, reclaimed 20.4 GB). The hex dumps captured below are the persistent record — if a 4th corruption occurs, preserve the new `.beads/dolt.corrupt.*` dir before recovery and run the same `dd | xxd` pattern at the reported offset to compare against these fingerprints.

**Reproducer template for future corruptions:**
```bash
# Save the corrupt dir before running bd backup restore:
mv .beads/dolt .beads/dolt.corrupt.$(date -u +%Y%m%dT%H%M%SZ)
# After recovery, hex-dump around the offset reported in the error:
dd if=.beads/dolt.corrupt.<TS>/ch/.dolt/noms/vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv bs=1 skip=$((OFFSET-128)) count=384 2>/dev/null | xxd
# Look for the signature: 40-byte record (header 0x00000028 01010400 00000000 69...)
# repeated 3-4x back-to-back with ~40 bytes of 0x00 padding between copies.
```

**Captured hex signatures from deleted forensic dirs (for reference):**

```
2026-04-11 journal offset 22339161 (bytes 0x00-0xff around offset 22339033):
00000000: ee98 9c32 f5f4 04a0 0000 0028 0101 0400  ...2.......(....
00000010: 0000 0069 d972 d502 903f ede0 8adc 3179  ...i.r...?....1y
00000020: 7aad 9174 eeaa 4510 4654 07db 570e a39e  z..t..E.FT..W...
00000030: 0000 0028 0101 0400 0000 0069 d972 d502  ...(.......i.r..
00000040: 903f ede0 8adc 3179 7aad 9174 eeaa 4510  .?....1yz..t..E.
00000050: 4654 07db 570e a39e 0000 0028 0101 0400  FT..W......(....
00000060: 0000 0069 d972 d502 903f ede0 8adc 3179  ...i.r...?....1y
00000070: 7aad 9174 eeaa 4510 4654 07db 570e a39e  z..t..E.FT..W...
00000080: 0000 0000 0000 0000 0000 0000 0000 0000  ................
00000090: 0000 0000 0000 0000 0000 0000 0000 0000  ................
000000a0: 0000 0000 0000 0000 0000 04a2 0102 0279  ...............y
→ record 0x00000028 01010400 00000000 69d972d5... appears 3x, zeros, new record.

2026-04-12 journal offset 1275708894 (bytes 0x00-0xff around offset 1275708766):
00000000: 6d65 7372 6f75 7465 7377 6973 705f 11ad  mesrouteswisp_..
00000010: 050d 2e98 0005 1109 8605 0b2c 6c61 6265  ...........,labe
00000020: 6c73 7769 7370 7300 e03f 96e5 50a9 3dd2  lswisps..?..P.=.
00000030: 0000 0028 0101 0400 0000 0069 db4f cf02  ...(.......i.O..
00000040: 2457 c617 f380 c941 3187 4208 73c9 bf30  $W.....A1.B.s..0
00000050: b6f6 2b5b 5aeb aca8 0000 0028 0101 0400  ..+[Z......(....
00000060: 0000 0069 db4f cf02 2457 c617 f380 c941  ...i.O..$W.....A
00000070: 3187 4208 73c9 bf30 b6f6 2b5b 5aeb aca8  1.B.s..0..+[Z...
00000080: 0000 0000 0000 0000 0000 0000 0000 0000  ................
00000090: 0000 0000 0000 0000 0000 0000 0000 0000  ................
000000a0: 0000 0000 0000 0000 0000 0028 0101 0400  ...........(....
000000b0: 0000 0069 db4f cf02 2457 c617 f380 c941  ...i.O..$W.....A
000000c0: 3187 4208 73c9 bf30 b6f6 2b5b 5aeb aca8  1.B.s..0..+[Z...
000000d0: 0000 0028 0101 0400 0000 0069 db4f cf02  ...(.......i.O..
000000e0: 2457 c617 f380 c941 3187 4208 73c9 bf30  $W.....A1.B.s..0
000000f0: b6f6 2b5b 5aeb aca8 0000 03c9 0102 024b  ..+[Z..........K
→ record 0x00000028 01010400 00000000 69db4fcf... appears 2x, zeros, same record 2x more, new record.
```

---

## Original investigation notes (2026-04-11/12)

**CORRECTION 2026-04-12 (post-recovery):** my initial "1.2 GB threshold" hypothesis was wrong — I was comparing yesterday's *total journal size* against today's *corruption offset* (different things). After running `dolt backup -v` against the older corrupt dir, yesterday's actual corruption offset is **22,339,161 bytes (21 MB)**, not 1.2 GB. Updated table below.

**Two data points so far:**

| Date | Journal file size | Corruption offset | Notes |
|---|---|---|---|
| 2026-04-11 | 1,250,266,365 bytes (1192 MB) | **22,339,161 (21 MB)** — very early in file | Would have been written shortly after recovery |
| 2026-04-12 | 2,259,020,062 bytes (2154 MB) | 1,275,708,894 (1216 MB) — mid file | Linear growth estimate puts write time at ~Apr 11 23:00 |

The two corruptions are at very different offsets. **No size-threshold pattern.** Possibly two unrelated incidents, or possibly a common trigger that fires at unpredictable points in the journal.

**Failure mode (from 2026-04-12 dolt.log around line 65650):**

```
Starting server with Config HP="0.0.0.0:40014"
error bootstrapping chunk journal: journal index is malformed
Starting server with Config HP="0.0.0.0:40014"
possible data loss detected in journal file at offset 1275708894: corrupted journal
```

The "journal index is malformed" error shows up on the **first** cold restart attempt, then on subsequent attempts it reports the offset-based corruption message. Suggests two things:
1. The index file (`journal.idx`, ~25 MB) gets rebuilt or invalidated on startup failure
2. The rebuild scan then detects mismatch at the specific journal data offset

**Critical behavior:** the **running sql-server doesn't detect the corruption** because its in-memory state has advanced past the bad offset. Corruption is only visible on cold restart. This means `gc stop` doesn't *cause* corruption — it *reveals* pre-existing corruption. By the time you notice, the byte was written some unknown time ago.

**What's NOT in play:**
- No disk/fs errors in dmesg (only WSL2 `dxg` noise and `tsc` drift warnings)
- No OOM kills, crashes, or panics in `journalctl --user -u gascity-supervisor`
- Not a shutdown-time write truncation — server was serving queries fine up to the stop moment

**Hypotheses (unranked, after offset correction):**

1. **~~Size-threshold bug~~** — RULED OUT after correcting yesterday's offset. Yesterday's was at 21 MB (very early), today's at 1.2 GB (mid-file). Not a size pattern.

2. **Journal.idx vs journal data race.** The index file and data file are separate. If they get out of sync (e.g., index flushed before data, or vice versa, and then a process dies mid-write), a cold restart sees malformed index. Concurrent writers could cause this. **Now the leading hypothesis** since the size pattern is gone — the failure mode "journal index is malformed" before the offset error supports this.

3. **bd auto-sync racing with sql-server.** bd auto-sync calls `DOLT_BACKUP('sync')` via an **in-process** dolt client every 15 min. If that in-process client acquires the journal in a way that races with the running sql-server (or with its own previous invocation), it could interleave bad bytes. Worth checking: does `.bd-dolt-ok` sentinel or any auto-sync log correlate with corruption time?

4. **WSL2 filesystem semantics.** WSL2 uses a virtualized ext4 on a VHDX. Host sleep/hibernate or Hyper-V suspensions could cause unusual fsync behavior. But dmesg shows no errors and the pattern is too specific for a generic flaky-disk story.

**Next investigation steps (when we revisit):**

1. **Compare byte content at offset 1275708894 in today's corrupt journal** with same offset in yesterday's corrupt journal — are they similar kinds of garbage? (hex dump both)
2. **Correlate corruption time with bd auto-sync.** Check `backup_state.json` history for 2026-04-12 around when offset 1.2 GB would have been written. Rough extrapolation: if the journal grew from ~0 to 2.1 GB in 32 hours, 1.2 GB was written at ~hour 18 = Apr 12 ~03:30 AM.
3. **File a dolt upstream issue** with the two data points. dolthub/dolt is actively maintained; this pattern might be known.
4. **Mitigation:** trigger journal compaction more often (lower threshold), or schedule a periodic planned restart (nightly) to catch corruption earlier when the journal is small and the backup is fresh.
5. **Preserve today's corrupt dir** as `dolt.corrupt.20260412T<ts>Z` before running recovery — gives us a second forensic sample.

**Running servers at time of investigation:**
- `gc stop` completed cleanly at 2026-04-12 16:43
- `systemctl --user stop gascity-supervisor.service` done to halt retry loop
- LOCK file in `.beads/dolt/ch/.dolt/noms/` was being churned by supervisor retries (now stopped)

**Related memory:** `reference_dolt_recovery.md` (the recovery procedure), `project_deacon_status.md` (mentions `gc dolt health` latent O(history) bug — possibly related if dolt health scans stress the journal).

**Bug to file after recovery:** create a beads bead like "dolt chunk journal corrupts near 1.2 GB mark — pattern from 2 incidents" linked to this memory and the two forensic dirs.
