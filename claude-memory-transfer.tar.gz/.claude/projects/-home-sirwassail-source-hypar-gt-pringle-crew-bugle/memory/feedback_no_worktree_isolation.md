---
name: No worktree isolation for subagents
description: User wants all subagent work committed directly to the current branch, not in isolated worktrees
type: feedback
---

All subagent work should be committed directly to the current branch in this clone. Do NOT use `isolation: "worktree"` when dispatching Agent subagents.

**Why:** The user expects all work to land on the active branch. Worktree isolation caused confusion — some agents' work was lost or required manual merging. The user said "everything should be committed to this branch you are on for all beads all work."

**How to apply:** When using bd-do or dispatching implementation subagents, never set `isolation: "worktree"`. Let subagents work directly in the main clone. If parallel agents would conflict on files, run them sequentially instead.
