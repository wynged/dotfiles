---
name: Git remote layout for gascity
description: origin is wynged/gascity (fork), upstream is gastownhall/gascity (source of truth)
type: reference
---

- `origin` = https://github.com/wynged/gascity.git (user's fork)
- `upstream` = https://github.com/gastownhall/gascity.git (source of truth)

PRs should be created against `gastownhall/gascity` upstream.
