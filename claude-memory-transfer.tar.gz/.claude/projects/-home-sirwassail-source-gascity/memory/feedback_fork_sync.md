---
name: Always sync fork with upstream before any work
description: The gascity repo is a fork (origin=wynged/gascity) of upstream (gastownhall/gascity). Always sync before branching or PRing.
type: feedback
---

Always sync origin/main with upstream/main before creating branches or PRs.

**Why:** The fork fell 212 commits behind upstream, causing a painful rebase with many conflicts and a PR that targeted the wrong base. The user's local main diverged silently from the upstream source of truth.

**How to apply:** At the start of any contribution workflow:
1. `git fetch upstream && git fetch origin`
2. `git checkout main && git reset --hard upstream/main && git push origin main`
3. Only then create feature branches from main
4. PRs target `gastownhall/gascity` (upstream), not the fork
