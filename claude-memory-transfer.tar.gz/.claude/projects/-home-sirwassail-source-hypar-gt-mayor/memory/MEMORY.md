# Mayor Memory

## Dispatch Rules — Learned

### Polecats cannot swarm on feature branches (2026-03-09)
`gt sling --base-branch` does NOT propagate to PR creation. Polecats always
target `main` when creating PRs. Do NOT use polecats for convoy work that
should land on a single feature branch.

**Use crew for**: All work. User prefers crew over polecats.
**Polecats**: User doesn't want to use these. They lack coordination wiring
(--base-branch doesn't propagate to PRs, no feature-branch swarming support).
Just add more crew members if parallelism is needed.

Bug filed: hq-k4v0. Until fixed, polecats + feature branches = manual cleanup.

## Statusline
- Config: `~/.claude/statusline-command.sh`
- Rate limit cache: `/tmp/.claude-ratelimit-cache` (pipe-separated: util_5h|util_7d|reset_5h_epoch|reset_7d_epoch)
- Cache interval: 300s (5 min)
- 5h display: 10-char bar with time-position marker, pace-based coloring (grey/yellow +10%/red +25%)
- 7d display: raw percent + reset countdown
- ctx%: grey < 50%, yellow 50-70%, red >= 70%
