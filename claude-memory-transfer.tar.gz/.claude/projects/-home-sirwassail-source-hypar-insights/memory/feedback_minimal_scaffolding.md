---
name: Keep structure minimal
description: Grow folders, templates, and tools only when a second instance appears — never preemptively
originSessionId: 34c196e1-f963-4eab-8c67-1a4a04165e84
---
Do not preemptively scaffold folders, templates, or shared tooling in this vault. Add structure only when a second instance of the thing appears.

**Why:** The prior vault became "too noisy" because it set up the full Evidence/Insights/Actions/Templates taxonomy before there was work to fill it. The user wants the inverse discipline here — structure follows use. Also: every document is expected to be a folder, because documents accrue bespoke sibling artifacts (data pulls, scripts, exports) that belong next to the doc, not in global buckets.

**How to apply:**
- When tempted to create a `templates/`, `tools/`, or `scripts/` folder at the root, don't — wait until a second project needs the same thing.
- When creating a new document, make it a folder (`<slug>/<slug>.md`) so siblings have a home.
- If asked "should we also add X?", default to "not yet — let's add it when we hit the case that needs it."
