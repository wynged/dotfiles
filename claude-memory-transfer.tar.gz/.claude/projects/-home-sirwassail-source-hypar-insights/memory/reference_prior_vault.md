---
name: Prior vault reference
description: Location of the prior Obsidian-based insights vault — reference-only, do not copy from
type: reference
originSessionId: 34c196e1-f963-4eab-8c67-1a4a04165e84
---
The user's prior insights vault lives at `/mnt/c/Users/SirWassail/hypar-insights` (Windows: `G:\My Drive\EW Machine Setup\hypar-insights`, synced via Google Drive to the local C: path).

It contains an Obsidian vault with a full product-learning taxonomy: `Evidence/`, `Insights/`, `Actions/Design/`, `Actions/Launch/`, `Musing/`, `Templates/` (including Landing Doc, Launch Doc, Design Doc, Insight, Observation templates), plus a detailed `README.md` describing the Observation → Insight → Design → Launch → Landing cycle.

**Use it for:** understanding what the user has tried before, what shapes of docs have existed, and what vocabulary feels natural to them.

**Do not:** copy files from it, reference it by path in vault docs, or suggest adopting its structure wholesale. The user explicitly wants the new vault to be the next iteration, not a fork.
