---
name: Exclude Hypar's own usage from external adoption analysis
description: hypar.io and any hypar-owned email domains are dogfooding — exclude from external adoption numbers in landing/launch docs
type: feedback
originSessionId: 34c196e1-f963-4eab-8c67-1a4a04165e84
---
When analyzing product usage for Hypar features, **exclude `hypar.io`** (and any other hypar-owned email domains) from external-adoption numbers, org counts, and headline tables. We are the Hypar org — our own usage is dogfooding, not market signal.

**Why:** Including Hypar in adoption tables overstates real customer uptake and mixes internal validation with external signal. User caught this in the first landing-doc draft and explicitly called for it to be removed.

**How to apply:**
- Filter out `properties.emailDomain IN ('hypar.io', ...)` or equivalent in any org-level rollup query intended for adoption reporting.
- Keep Hypar's numbers available for reference/context ("for reference: …") but not in headline tables or counts.
- When exclusion changes a headline count (e.g., "29 orgs" → "28 external orgs"), update the narrative too, not just the tables.
- This applies across all landing/launch docs, not just this one.
