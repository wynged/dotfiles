---
name: Data and output systems
description: PostHog is the primary data source; Notion is the publishing destination
type: reference
originSessionId: 34c196e1-f963-4eab-8c67-1a4a04165e84
---
**Data in: PostHog.** Most product logging lives in PostHog. Bespoke dashboards can be built there, but analysis in this vault tends to work closer to the raw data (event exports, SQL-style queries) rather than dashboard screenshots. When pulling numbers for a doc, default to raw PostHog queries and save the query alongside the doc for reproducibility.

**Output: Notion.** The user iterates on docs here, then copies the finished markdown into the team's Notion. Keep markdown CommonMark-portable: no Obsidian wikilinks, no callout syntax, no frontmatter the reader shouldn't see. Standard headings, lists, fenced code blocks, and pipe tables all survive the paste.
