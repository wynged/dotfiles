---
name: Project overview
description: Purpose of the hypar-insights vault and its relationship to the prior Obsidian vault
type: project
originSessionId: 34c196e1-f963-4eab-8c67-1a4a04165e84
---
`/home/sirwassail/source/hypar-insights` is the user's working vault for business analysis of Hypar features — landing docs, launch decisions, and related thinking. The user drafts here and ports finished artifacts to the team's Notion.

**Why:** It's the next iteration of a prior Obsidian-based vault that grew too noisy with upfront scaffolding (Evidence/Insights/Actions taxonomy, many templates). The user wants to build up structure iteratively instead.

**How to apply:** Treat this vault as the canonical workspace for this kind of work. When suggesting structure, favor "add it when a second instance appears" over "scaffold it in case we need it."
