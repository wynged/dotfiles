---
name: Scripting preference
description: User prefers TypeScript with the Bun runtime for scripting
type: user
originSessionId: 34c196e1-f963-4eab-8c67-1a4a04165e84
---
When scripting is needed (data pulls, transforms, small tools), the user prefers **TypeScript run with Bun**. Bun is the runtime, test runner, and package manager of choice — reach for `bun run`, `bun test`, `bun install` rather than Node/npm/pnpm unless there's a specific reason.

Applies across the user's projects, carried over from the prior vault's `AGENTS.md`.
