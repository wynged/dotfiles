---
name: Document vocabulary
description: Local meanings of "launch doc" and "landing doc" in this vault
type: project
originSessionId: 34c196e1-f963-4eab-8c67-1a4a04165e84
---
In this vault, the two doc kinds have specific meanings tied to feature-flag lifecycle:

- **Launch doc** — written when deciding to release a gated/experimental feature to the entire user base.
- **Landing doc** — written *after* a launch, when deciding whether to **remove the feature flag entirely**. It looks back: did the feature hit its initial goals, and did it avoid hurting critical business metrics (retention, adoption)?

**Why:** The user anchors these doc kinds to concrete decision points in the release process, not generic product-management labels. A landing doc's job is to produce a flag-removal decision.

**How to apply:** When drafting a landing doc, structure it around answering (1) were launch goals met, (2) are guardrail metrics unharmed, (3) what's the recommendation — remove flag / keep gated / iterate / roll back. Don't default to generic post-mortem shape.
