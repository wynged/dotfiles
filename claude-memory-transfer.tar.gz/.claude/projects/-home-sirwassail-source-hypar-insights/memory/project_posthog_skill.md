---
name: PostHog skill is set up
description: Project-scoped posthog skill exists at .claude/skills/posthog with creds in vault-root .env
type: project
originSessionId: 34c196e1-f963-4eab-8c67-1a4a04165e84
---
The hypar-insights vault has a ready-to-use PostHog integration:

- Creds in `/home/sirwassail/source/hypar-insights/.env` (gitignored): `POSTHOG_HOST=https://app.posthog.com`, `POSTHOG_PROJECT_ID=51345`, `POSTHOG_API_KEY=phx_...`.
- Project-scoped skill at `.claude/skills/posthog/SKILL.md` documents usage and includes a HogQL cheatsheet.
- Query runner at `.claude/skills/posthog/query.ts` — run `bun .claude/skills/posthog/query.ts "<HogQL>"` or `-f <file.sql>`. Outputs JSON (default) or CSV (`--csv`). Works from the vault root; loads `.env` via an explicit path so cwd doesn't matter.

**How to apply:** When the user asks for any data pull from PostHog in this vault, reach for this skill rather than building new tooling or hitting the API ad-hoc. Save project-specific queries as `.sql` files next to the doc they support (per HOW-WE-WORK.md).

**Known gotchas discovered during setup:**
- Event name `library-move` exists in PostHog despite the Named Libraries launch doc saying "no direct move between libraries" — investigate semantics before trusting it.
- No `library-load` or `library-activate` event surfaced in initial probe; the launch doc treats "load into project" as the key adoption signal, so the actual event name needs discovery before the first real pull.
