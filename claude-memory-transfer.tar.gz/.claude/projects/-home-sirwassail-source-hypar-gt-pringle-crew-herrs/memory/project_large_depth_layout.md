---
name: Large depth / oversized building layout — multi_row shipped
description: Multi-row packing implemented for wide edges; remaining work is smarter AI building sizing and depth warnings
type: project
---

**multi_row corridor mode shipped** (0a35d77ed, 2026-03-16). When corridorWidth > 12m, the AI can now use `multi_row` mode to auto-pack N rows of spaces with corridors between them. This addresses the wasted floor plate problem for oversized buildings.

**Remaining work:**

1. **Smarter AI building sizing**: Haiku still creates oversized buildings (1,849 m² for 620 m² program). The guidance says target ~65% but weaker models ignore it. Consider making the building creation tool enforce a max area relative to program, or adding a warning to the response.

2. **Algorithm depth warnings**: When maxDepth is unreasonably large relative to typical space sizes, surface this as a warning in the capacity estimate response so the AI knows something is off.

3. **Opposite-side row placement**: Current multi_row places all rows from the same edge inward. Could also support placing rows from both edges inward (like a bidirectional double_loaded), meeting in the middle.

**Why:** The bank transcript (2026-03-13) showed a 20,000 sq ft bank where the oversized building led to 30-40m corridorWidth and terrible layouts. Multi_row solves the depth-utilization problem; building sizing solves the root cause.

**How to apply:** When working on layout quality, focus on AI guidance improvements and building sizing enforcement. The geometric algorithm is now capable of handling large depths.
