---
name: Feature branch discipline
description: Only commit changes relevant to the feature branch — don't bundle unrelated changes like AGENTS.md edits
type: feedback
---

Keep commits scoped to the feature branch's purpose. Unrelated changes (e.g., AGENTS.md guideline updates on a spatial-placement fix branch) should be skipped or saved for a separate commit on main.

**Why:** Mixing unrelated changes into feature branches pollutes the PR diff and makes review harder.

**How to apply:** Before staging files, check whether each change is relevant to the branch's purpose. Skip or defer anything that isn't.
