# Memory Index

- [feedback_no_gating.md](feedback_no_gating.md) — User prefers debug logging enabled unconditionally, not behind feature gates
- [project_large_depth_layout.md](project_large_depth_layout.md) — Next priority: smarter handling of oversized buildings and large-depth regions (interior circulation, multi-row packing, better AI guidance)
- [project_edge_pattern_linear_array.md](project_edge_pattern_linear_array.md) — Refactored create_linear_array to use edge:{from,to,pStart,pEnd} pattern with auto-containment heuristic; user will provide failing transcript next
- [feedback_branch_discipline.md](feedback_branch_discipline.md) — Only commit changes relevant to the feature branch; don't bundle unrelated edits
