---
name: no-gating-debug-logging
description: User prefers debug logging enabled unconditionally, not behind localStorage flags or feature gates
type: feedback
---

Don't put debug logging behind localStorage flags or feature gates — just turn it on.

**Why:** User wants to see the output immediately without extra steps. Gating adds friction.

**How to apply:** When adding temporary debug logging, use plain `console.warn` calls. Only gate logging if specifically asked to.
