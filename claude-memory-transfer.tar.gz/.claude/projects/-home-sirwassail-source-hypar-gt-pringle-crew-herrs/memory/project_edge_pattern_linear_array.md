---
name: Edge pattern refactor for create_linear_array
description: Refactored create_linear_array to use edge:{from,to,pStart,pEnd} pattern from fix-ai-space-positioning branch, with auto-containment heuristic
type: project
---

Refactored `create_linear_array` on branch `fix/spatial-placement-building-containment-guidance` to adopt the edge referencing pattern from `fix-ai-space-positioning`.

**What changed:**
- `LabelRegistry` now stores `elementId` and `kind` ('building'|'space'|'furniture'|'image') alongside coordinates
- Replaced `alignToEdge`/`anchor`/`containingBoundaryId`/`edge` params with `edge: { from, to, pStart?, pEnd? }` (parametric or length-based)
- Auto-containment heuristic: building edge labels → spaces inside, space edge labels → spaces outside
- Simplified LLM guidance from ~30 lines to 6 lines

**Why:** The edge pattern from `fix-ai-space-positioning` is more expressive (supports arbitrary spans along edges) and the auto-containment removes the need for verbose LLM instructions about inside/outside placement.

**How to apply:** User mentioned they will provide a failing transcript next — these changes may need adjustment based on eval results. The code compiles clean (no new type errors).

**Files changed:** `labelRegistry.ts`, `visualizeLayers.ts`, `DesignApi.ts`, `designTools.ts`
