---
name: registerNewStaticFile permission-grant gap
description: Some file registration paths skip createPermissions:true, leaving no workflow→file grant in the permissions table. Causes cascading bugs: collaborators rejected, conversion caches never warm.
type: project
---

`registerNewStaticFile` in `packages/realtime-dependencies/src/staticFiles.ts` only writes a workflow→file permission grant when called with `createPermissions: true`. Several upload pathways skip this flag, leaving file ownership expressed only in DynamoDB metadata (`workflow_id`/`owningRecord`) but not in the permissions table.

Known affected paths (as of 2026-04-22 investigation, bug surfaced via the `cannot-access-file-with-context` PostHog pattern):
- Revit add-in elements-record uploads (purpose=`Component`, `Identity.source: 'elements-record'`)
- Direct web user-content uploads (purpose=`user_content`, e.g. `Base_Building_Hypar_*.glb`)
- CAD upload (purpose=`CAD upload`, .dwg)
- Image upload (purpose=`Image upload`, .pdf)

**Why:** The permission-grant gap creates a self-reinforcing cache-miss loop. Pre-#1854, the single-file `getFile` endpoint's context branch chased the permissions chain and failed for any non-uploader. The batch `getFiles` endpoint had a `metadata.workflow_id` fast-path that worked, but it punts conversions (GLB optimize, PDF→PNG, DWG→DXF) to the single-file endpoint via `not-converted-needs-individual-fetch`. So collaborators got rejected at the ACL gate, the conversion code never ran, the converted artifact never landed in S3, and every subsequent collaborator hit the same un-warmed cache.

**How to apply:** PR #1854 (merged or pending) makes the single-file ACL match the batch endpoint, breaking the loop for *fetches*. The underlying registration inconsistency is still there — file ownership lives in two stores that disagree. Worth a follow-up audit of every `registerNewStaticFile` caller to decide whether each path should set `createPermissions: true`. Until then, treat any code that reads from the permissions table to determine file ownership as unreliable; prefer `metadata.owningRecord ?? metadata.workflow_id` (the batch endpoint's pattern).
