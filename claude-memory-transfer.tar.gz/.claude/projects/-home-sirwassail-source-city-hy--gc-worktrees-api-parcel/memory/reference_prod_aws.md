---
name: prod AWS resources for file-fetch debugging
description: CloudWatch log groups, S3 bucket, DynamoDB table, and a known-missing GSI in account 501396736796 / us-west-2.
type: reference
---

Prod resources used while debugging the GetFile ACL bug (2026-04-22):

- **AWS account**: 501396736796 (`AWSAdministratorAccess` SSO role works for read access — `aws sts get-caller-identity` confirms).
- **Region**: us-west-2 for the Realtime stack.
- **CloudWatch log groups**:
  - `/aws/lambda/prod-Realtime-1HLSHIMI8UIYR-GetFileFunction-FT86vunCZczq` — single-file endpoint
  - `/aws/lambda/prod-Realtime-1HLSHIMI8UIYR-GetFilesFunction-7SYyWq2JVTsf` — batch endpoint
  - Filter pattern `"User does not have access to file"` lands the strict-branch ACL rejections; same string appears in the legacy no-context branch too (logs distinguish by presence of `Context: { ... }` line).
- **S3 bucket** `hypar-static`: original file at `<key>`, optimized GLB at `<key-without-ext>_optimized.glb`, PDF→PNG at `<key-without-ext>_converted_<page>.png`, DWG→DXF at `<key-without-ext>_converted.dxf`. All converters use `getConvertedStaticFileKey` from `@hypar/realtime-dependencies/staticFiles`.
- **DynamoDB table** `hypar`: file records have `id` + `type='file'` as PK. **No GSI on `workflow_id`** — querying all files in a workflow requires a Scan with filter (hundreds of MB per workflow, not cheap). GSIs available: `sort_key-created-index`, `type-sort_key-index`, `type-domain-index`.
- **Sandbox stack for testing**: `eric-api-prod` in same account/region, deployed via `/build-n-deploy`. Uses `aws-sam-cli-api-sandbox-us-west-2` S3 bucket for SAM artifacts.

For ad-hoc cross-workflow analysis, CloudWatch Logs Insights is more efficient than `filter-log-events` for aggregations. The rejected-file set is a usable proxy for "files actually being fetched in this window" when the table's lack of a workflow_id GSI makes the full denominator impractical.
