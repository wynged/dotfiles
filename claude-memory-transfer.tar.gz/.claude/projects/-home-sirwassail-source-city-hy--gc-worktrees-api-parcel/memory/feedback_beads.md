---
name: ignore beads and never mention in PRs
description: For this project, do not use beads for task tracking and never reference beads (IDs, routing, investigation docs) in PR descriptions or commit messages.
type: feedback
---

Do not engage with the beads tracking system on this project, and never reference beads in any user-visible artifact (PR titles, PR descriptions, commit messages).

**Why:** Eric explicitly disavowed the beads workflow here. The startup hook and global guidance still push beads, but his project-level preference overrides them. Surfacing bead IDs or the beads folder in PRs leaks internal tracking noise into the public review record.

**How to apply:**
- Don't run `bd` commands, don't browse `.beads/`, don't create/update/close beads.
- When writing PR titles/descriptions/commit messages, scrub any mention of bead IDs (e.g. `api-123`, `bs-p2bj`), rig/agent routing (`bug-sherrif`, `cricket`, `parcel`), or "routed from"/"Closes <bead>" phrasing.
- Technical context from a bead/mail (root cause, metrics, evidence) is fine to include — just don't name the tracking source.
- If the startup hook reinjects beads context, treat it as informational only; still follow this rule for outputs.
