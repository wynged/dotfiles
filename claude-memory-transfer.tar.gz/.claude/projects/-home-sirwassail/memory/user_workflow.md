---
name: Eric's multi-agent workflow
description: How Eric works with Gastown/GasCity — PR-driven crew, parallel projects, backlog curation
type: user
---

Eric uses multi-agent coding orchestration (Gastown → migrating to GasCity). Key traits:

- **PR-driven workflow**: every piece of work goes through a feature branch and PR. Never push to main.
- **Named crew members**: each crew agent owns a branch/PR end-to-end across sessions.
- **Parallel projects**: many rigs registered, ~3 active, wants background workers doing useful work.
- **Wants to stay in the loop**: automated feedback (PR Watch) alerts him, he presses enter to forward. Not fully autonomous.
- **Values easy agent setup**: spinning up new crew should be trivial, worktree isolation automatic.
- **Web app developer**: needs dev server management (pringle is a web app with Vite).
- **Keyboard shortcut oriented**: uses tmux keybindings for cycling sessions, sleep/wake, etc.
