---
name: city_hy GasCity migration
description: Active project migrating Eric's Gastown setup to GasCity with custom config (no gastown pack agents)
type: project
---

Eric is migrating from Gastown (`hypar_gt/`) to GasCity (`city_hy/`). Custom setup, NOT using the gastown pack's agents — only borrowing its worktree-setup.sh script.

**Why:** GasCity is the lower-level SDK that Gastown is built on. Eric wants a custom config tailored to his PR-driven crew workflow rather than gastown's opinionated role taxonomy.

**Current state (as of 2026-04-01):** Phase 1 verified and stable. City boots, mayor + utz running, worktree created, overlay applied. Phase 2 (crew lifecycle) is next. 8-phase progressive plan in `sw_learning/07-workflow-analysis.md`.

**How to apply:** When working in city_hy, read CLAUDE.md first, then `sw_learning/session-log.md` for latest state. All learnings are in `sw_learning/` — don't duplicate them in memory.
