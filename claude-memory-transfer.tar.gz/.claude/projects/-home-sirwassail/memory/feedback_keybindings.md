---
name: Alt+h/l keybinding preference
description: Eric prefers Alt+h and Alt+l for cycling tmux sessions, not Prefix+n/p
type: feedback
---

Use Alt+h / Alt+l (root table, no prefix) for cycling between agent sessions.
**Why:** Eric's preference for keyboard-shortcut navigation — faster than prefix-based bindings.
**How to apply:** When wiring tmux navigation keybindings in GasCity, use root-table Alt bindings, not prefix-table.
