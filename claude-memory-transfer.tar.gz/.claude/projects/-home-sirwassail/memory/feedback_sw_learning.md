---
name: Use sw_learning for project notes
description: Eric prefers project learnings and progress notes in sw_learning/ folder, not in Claude's persistent memory
type: feedback
---

Save project learnings, session progress, and analysis to `sw_learning/` in the project directory (e.g., `city_hy/sw_learning/`), not to Claude's persistent memory system.

**Why:** Eric considers `sw_learning/` "the usual spot" for documenting what we learn. It's version-controlled, visible to all agents, and organized with numbered files.

**How to apply:** Use persistent memory only for cross-project user preferences and high-level project pointers. Detailed analysis, session logs, and technical learnings go in `sw_learning/`.
