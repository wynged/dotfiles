---
name: GasCity tmux socket location
description: GC sessions run on a dedicated tmux socket, not the default one — use tmux -L city_hy to interact with them
type: feedback
---

GasCity uses a dedicated tmux socket, not the default tmux server. `tmux list-sessions` only shows the user's own sessions.

**Why:** GC isolates its tmux sessions per city. The socket name matches the workspace name from city.toml.

**How to apply:** To inspect GC-managed tmux sessions:
- Socket location: `/tmp/tmux-1000/city_hy`
- List sessions: `tmux -L city_hy list-sessions`
- Kill a session: `tmux -L city_hy kill-session -t <name>`
- Attach: `tmux -L city_hy attach -t <name>`

Never use bare `tmux` commands when debugging GC sessions — always pass `-L city_hy`.
